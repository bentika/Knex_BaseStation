#include "pcf8575.h"
#include <stddef.h>

fw_err_t pcf8575_init(pcf8575_t *dev) {
    if (dev == NULL || dev->i2c == NULL ||
        dev->i2c->probe == NULL || dev->i2c->write == NULL || dev->i2c->read == NULL) {
        return FW_ERR_INVALID_PARAM;
    }

    if (dev->i2c_addr < PCF8575_MIN_I2C_ADDR || dev->i2c_addr > PCF8575_MAX_I2C_ADDR) {
        return FW_ERR_INVALID_PARAM;
    }

    dev->initialized = false;

    fw_err_t ret = dev->i2c->probe(dev->i2c_addr);
    if (ret != FW_OK) {
        return ret;
    }

    ret = pcf8575_write_port(dev, PCF8575_ALL_INPUT_MASK);
    if (ret != FW_OK) {
        return ret;
    }

    dev->initialized = true;
    return FW_OK;
}

fw_err_t pcf8575_read_port(pcf8575_t *dev, uint16_t *out_mask) {
    if (dev == NULL || out_mask == NULL) {
        return FW_ERR_INVALID_PARAM;
    }
    if (!dev->initialized || dev->i2c == NULL || dev->i2c->read == NULL) {
        return FW_ERR_NOT_INITIALIZED;
    }

    uint8_t rx_buf[PCF8575_PORT_BYTE_COUNT] = {0xFFU, 0xFFU};
    fw_err_t ret = dev->i2c->read(dev->i2c_addr, rx_buf, PCF8575_PORT_BYTE_COUNT);
    if (ret != FW_OK) {
        return ret;
    }

    *out_mask = (uint16_t)rx_buf[0] | ((uint16_t)rx_buf[1] << 8U);
    return FW_OK;
}

fw_err_t pcf8575_write_port(pcf8575_t *dev, uint16_t mask) {
    if (dev == NULL || dev->i2c == NULL || dev->i2c->write == NULL) {
        return FW_ERR_INVALID_PARAM;
    }

    const uint8_t tx_buf[PCF8575_PORT_BYTE_COUNT] = {
        (uint8_t)(mask & 0xFFU),
        (uint8_t)((mask >> 8U) & 0xFFU)
    };

    fw_err_t ret = dev->i2c->write(dev->i2c_addr, tx_buf, PCF8575_PORT_BYTE_COUNT);
    if (ret == FW_OK) {
        dev->port_latch = mask;
    }
    return ret;
}

