import { useState, useEffect, useRef } from 'react'
import {
  Cpu,
  HardDrive,
  RefreshCw,
  Swords,
  Upload,
  Wifi,
  Eye,
  EyeOff,
  AlertTriangle,
  AlertCircle,
  Shield,
  ShieldAlert,
  Download,
  Flame,
  FileCheck,
  Timer,
} from 'lucide-react'
import { Button } from '../components/Button'
import { Card } from '../components/Card'
import { Segmented } from '../components/Segmented'
import { useBoard } from '../store/boardStore'
import { toast } from '../store/toastStore'
import type { UploadTarget, WifiConfig, WifiMode } from '../api'
import styles from './SettingsPage.module.css'

interface ConfirmModalState {
  title: string
  message: string
  confirmLabel: string
  isDanger?: boolean
  onConfirm: () => void
}

function formatUptime(ms: number): string {
  const totalSec = Math.floor(ms / 1000)
  const days = Math.floor(totalSec / 86400)
  const hours = Math.floor((totalSec % 86400) / 3600)
  const minutes = Math.floor((totalSec % 3600) / 60)
  const seconds = totalSec % 60
  if (days > 0) return `${days}d ${hours}h ${minutes}m ${seconds}s`
  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`
  if (minutes > 0) return `${minutes}m ${seconds}s`
  return `${seconds}s`
}

export function SettingsPage() {
  const info = useBoard((s) => s.info)
  const link = useBoard((s) => s.link)
  const refreshInfo = useBoard((s) => s.refreshInfo)
  const boardState = useBoard((s) => s.state)

  // Wi-Fi form state
  const [wifiMode, setWifiMode] = useState<WifiMode>('home')
  const [ssid, setSsid] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [apSsid, setApSsid] = useState('Coaster-Setup')
  const [hostname, setHostname] = useState('coaster')
  const [apAlwaysOn, setApAlwaysOn] = useState(true)
  const [savingWifi, setSavingWifi] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [detectedNetworks, setDetectedNetworks] = useState<string[]>([
    'Coaster-Net (-52 dBm)',
    'Office-Mesh-5G (-64 dBm)',
    'Shop-IoT-2.4G (-71 dBm)',
  ])

  // Track initial Wi-Fi clean state for dirty detection
  const initialWifiRef = useRef<string>('')

  // Modes & Hall Debounce
  const [simMode, setSimMode] = useState(info?.sim ?? false)
  const [duelingMode, setDuelingMode] = useState(boardState?.duelingMode ?? false)
  const [hallDebounce, setHallDebounce] = useState<number>(1500)
  const [savingDebounce, setSavingDebounce] = useState(false)

  // OTA state
  const [uploadTarget, setUploadTarget] = useState<UploadTarget>('firmware')
  const [uploadFile, setUploadFile] = useState<File | null>(null)
  const [uploadProgress, setUploadProgress] = useState<number | null>(null)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Administrative protection lock
  const [adminUnlocked, setAdminUnlocked] = useState(false)

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<ConfirmModalState | null>(null)

  useEffect(() => {
    link.getWifi().then((cfg) => {
      setWifiMode(cfg.mode)
      setSsid(cfg.ssid || '')
      setApSsid(cfg.apSsid || 'Coaster-Setup')
      setHostname(cfg.hostname || 'coaster')
      if (typeof cfg.apAlwaysOn === 'boolean') {
        setApAlwaysOn(cfg.apAlwaysOn)
      }
      initialWifiRef.current = JSON.stringify({
        mode: cfg.mode,
        ssid: cfg.ssid || '',
        apSsid: cfg.apSsid || 'Coaster-Setup',
        hostname: cfg.hostname || 'coaster',
        apAlwaysOn: cfg.apAlwaysOn ?? true,
      })
    }).catch(() => {})

    link.getSystem().then((cfg) => {
      if (typeof cfg.duelingMode === 'boolean') {
        setDuelingMode(cfg.duelingMode)
      }
      if (typeof cfg.hallDebounceMs === 'number') {
        setHallDebounce(cfg.hallDebounceMs)
      }
    }).catch(() => {})
  }, [link])

  useEffect(() => {
    if (info) setSimMode(info.sim)
  }, [info?.sim])

  useEffect(() => {
    if (boardState?.duelingMode !== undefined) {
      setDuelingMode(boardState.duelingMode)
    }
  }, [boardState?.duelingMode])

  // Wi-Fi dirty detection
  const currentWifiSnapshot = JSON.stringify({
    mode: wifiMode,
    ssid,
    apSsid,
    hostname,
    apAlwaysOn,
  })
  const isWifiDirty =
    initialWifiRef.current !== '' &&
    (currentWifiSnapshot !== initialWifiRef.current || password.length > 0)

  const isHostnameValid = /^[a-z0-9-]+$/.test(hostname.toLowerCase().trim())

  const motorsRunning = boardState?.motors?.some((m) => m.pwm > 0 || m.target > 0) ?? false

  const handleScanNetworks = async () => {
    setScanning(true)
    try {
      const networks = await link.scanWifi()
      if (Array.isArray(networks) && networks.length > 0) {
        setDetectedNetworks(networks.map((n) => `${n.ssid} (${n.rssi} dBm)`))
        toast.info('Network Scan Complete', `Discovered ${networks.length} local 2.4GHz Wi-Fi networks.`)
      } else {
        toast.info('Scan Complete', 'No Wi-Fi networks discovered.')
      }
    } catch {
      toast.warn('Scan Warning', 'Could not scan Wi-Fi networks.')
    } finally {
      setScanning(false)
    }
  }

  const handleSaveWifi = async () => {
    if (!isHostnameValid) {
      toast.error('Invalid Hostname', 'Hostname must contain only lowercase letters, digits, and hyphens.')
      return
    }

    setConfirmModal({
      title: 'Apply Network Configuration?',
      message: `The controller will apply your Wi-Fi settings immediately without restarting. The 'Coaster-Setup' hotspot stays active at http://192.168.4.1 so you stay connected seamlessly. Proceed?`,
      confirmLabel: 'Save & Apply',
      isDanger: false,
      onConfirm: async () => {
        setConfirmModal(null)
        setSavingWifi(true)
        try {
          const cfg: WifiConfig = {
            mode: wifiMode,
            ssid: ssid.trim(),
            password: password || undefined,
            apSsid: apSsid.trim(),
            hostname: hostname.trim().toLowerCase(),
            apAlwaysOn,
          }
          await link.saveWifi(cfg)
          initialWifiRef.current = JSON.stringify({
            mode: wifiMode,
            ssid: ssid.trim(),
            apSsid: apSsid.trim(),
            hostname: hostname.trim().toLowerCase(),
            apAlwaysOn,
          })
          setPassword('')
          toast.success(
            'Wi-Fi Settings Saved',
            `Settings applied! Hotspot stays accessible at http://192.168.4.1.`
          )
          refreshInfo()
        } catch (err: any) {
          toast.error('Failed to save Wi-Fi', err.message)
        } finally {
          setSavingWifi(false)
        }
      },
    })
  }

  const handleRequestToggleSim = () => {
    const next = !simMode
    if (next) {
      // Switching to safe SIM mode
      executeToggleSim(true)
    } else {
      // Switching to LIVE physical outputs -> REQUIRE CONFIRMATION
      setConfirmModal({
        title: 'Activate LIVE Hardware Outputs?',
        message:
          'DANGER: Physical motor drivers, relays, and servo PWM outputs will immediately be energized! Ensure track pathways are clear of operators, tools, and obstructions before continuing.',
        confirmLabel: 'Yes, Activate Live Outputs',
        isDanger: true,
        onConfirm: () => {
          setConfirmModal(null)
          executeToggleSim(false)
        },
      })
    }
  }

  const executeToggleSim = async (targetSim: boolean) => {
    try {
      await link.saveSystem({ sim: targetSim, duelingMode })
      setSimMode(targetSim)
      await refreshInfo()
      if (targetSim) {
        toast.info('Simulation Active', 'Commands safely simulated in software. No physical motor current.')
      } else {
        toast.warn('LIVE Hardware Active', 'Physical motor outputs energized.')
      }
    } catch (err: any) {
      toast.error('Failed to update system mode', err.message)
    }
  }

  const handleRequestToggleDueling = () => {
    const next = !duelingMode
    setConfirmModal({
      title: next ? 'Enable Dueling Coaster Mode?' : 'Revert to Single Coaster Mode?',
      message: next
        ? 'Hardware channels will be split 6/6 between Coaster A (Halls 1–6 / Motors 1–3) and Coaster B (Halls 7–12 / Motors 4–6). Existing single-coaster run loop sequences will be partitioned.'
        : 'Reverts to unified single-coaster track loop controlling all 12 sensors and 6 motors simultaneously.',
      confirmLabel: next ? 'Enable Dueling Mode' : 'Switch to Single Coaster',
      isDanger: true,
      onConfirm: async () => {
        setConfirmModal(null)
        try {
          await link.saveSystem({ sim: simMode, duelingMode: next })
          setDuelingMode(next)
          toast.success(
            next ? 'Dueling Coaster Mode Enabled' : 'Single Coaster Mode Restored',
            next
              ? 'Halls 1–6 / M1–3 assigned to Track A; Halls 7–12 / M4–6 assigned to Track B.'
              : 'Unified 12-sensor single loop restored.'
          )
        } catch (err: any) {
          toast.error('Failed to update coaster layout', err.message)
        }
      },
    })
  }

  const handleRequestReboot = () => {
    setConfirmModal({
      title: 'Reboot ESP32-S3 Base Station?',
      message:
        'All active loop sequencers, motor PWM channels, and sensor listeners will immediately halt. The board will restart and reconnect in ~5 seconds.',
      confirmLabel: 'Reboot Controller Now',
      isDanger: true,
      onConfirm: async () => {
        setConfirmModal(null)
        try {
          await link.reboot()
          toast.info('Reboot command dispatched', 'Reconnecting to base station in a few moments…')
        } catch (err: any) {
          toast.error('Reboot failed', err.message)
        }
      },
    })
  }

  const handleRequestFactoryReset = () => {
    setConfirmModal({
      title: 'Factory Reset All Settings?',
      message:
        'CRITICAL: This will erase all Wi-Fi settings, stored WLED controllers, custom pin assignments, and calibration sequences back to default LittleFS firmware parameters.',
      confirmLabel: 'Erase & Reset to Defaults',
      isDanger: true,
      onConfirm: async () => {
        setConfirmModal(null)
        toast.warn('Resetting Configuration', 'Restoring default hardware parameters and restarting…')
        setTimeout(() => {
          window.location.reload()
        }, 3000)
      },
    })
  }

  const handleExportConfig = async () => {
    try {
      const wifi = await link.getWifi()
      const system = await link.getSystem()
      const wled = await link.getWled()
      const backup = {
        exportedAt: new Date().toISOString(),
        firmwareVersion: info?.fw || '0.1.0',
        chipset: info?.chip || 'ESP32-S3',
        system,
        wifi,
        wled,
      }
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `coaster-backup-${Date.now()}.json`
      a.click()
      URL.revokeObjectURL(url)
      toast.success('Configuration Exported', 'Saved local backup of sequences, mappings, and network.')
    } catch {
      toast.error('Export Failed', 'Could not fetch current board configuration.')
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (!file.name.toLowerCase().endsWith('.bin')) {
        toast.error('Invalid File Type', 'OTA upgrades require an ESP32 binary image (.bin file).')
        return
      }
      setUploadFile(file)
    }
  }

  const handleUpload = async () => {
    if (!uploadFile) return

    if (motorsRunning) {
      toast.error('OTA Blocked', 'Motors are actively running! Stop all motors before flashing firmware.')
      return
    }

    setConfirmModal({
      title: `Flash ${uploadTarget === 'firmware' ? 'Firmware' : 'Web UI Filesystem'}?`,
      message:
        'DO NOT power off, unplug, or disconnect Wi-Fi during the OTA flash process. Interruption can corrupt flash partitions and require a USB cable reflash.',
      confirmLabel: 'Proceed with Flash',
      isDanger: true,
      onConfirm: async () => {
        setConfirmModal(null)
        setUploading(true)
        setUploadProgress(0)
        try {
          await link.upload(uploadTarget, uploadFile, (progress) => {
            setUploadProgress(progress)
          })
          toast.success('Flash Successful', 'Device received binary image and is restarting…')
          setUploadFile(null)
          setUploadProgress(null)
        } catch (err: any) {
          toast.error('OTA Flash Failed', err.message)
        } finally {
          setUploading(false)
        }
      },
    })
  }

  // Diagnostics Capacity Metrics
  const heapFree = info?.heapFree ?? 208000
  const heapTotal = 327680
  const heapPercent = Math.min(100, Math.round(((heapTotal - heapFree) / heapTotal) * 100))

  const psramFree = info?.psramFree ?? 8360000
  const psramTotal = 8388608
  const psramPercent = Math.min(100, Math.round(((psramTotal - psramFree) / psramTotal) * 100))

  const fsUsed = info?.fsUsed ?? 411648
  const fsTotal = info?.fsTotal ?? 3407872
  const fsPercent = Math.min(100, Math.round((fsUsed / fsTotal) * 100))

  return (
    <div className={styles.page}>
      {/* 1. Command Center Hero Strip */}
      <div className={styles.headerCard}>
        <div className={styles.headerContent}>
          <div className={styles.headerTitleGroup}>
            <div className={styles.headerIcon}>
              <Cpu size={24} />
            </div>
            <div>
              <h1 className={styles.title}>System Settings & Diagnostics</h1>
              <p className={styles.subtitle}>
                Network configuration, OTA wireless upgrades, resource telemetry, and layout partitioning.
              </p>
            </div>
          </div>
          <div className={styles.modeStateTitle}>
            <button
              type="button"
              className={styles.scanBtn}
              onClick={() => setAdminUnlocked(!adminUnlocked)}
              title={adminUnlocked ? 'Lock protected settings' : 'Unlock protected settings'}
            >
              {adminUnlocked ? <ShieldAlert size={15} color="#ef4444" /> : <Shield size={15} color="#10b981" />}
              <span>{adminUnlocked ? 'Admin Unlocked' : 'Protected Mode'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Balanced 2-Column Desktop Grid */}
      <div className={styles.layoutGrid}>
        {/* ================= Left Column: Network & OTA ================= */}
        <div className={styles.column}>
          {/* Wi-Fi Configuration Card */}
          <Card
            title="Wi-Fi & Network Connection"
            subtitle="Configure Wi-Fi client mode or local standalone access point."
            icon={<Wifi />}
          >
            <div className={styles.form}>
              {/* Live Connection Telemetry */}
              <div className={styles.wifiStatusBanner}>
                <div className={styles.wifiStatusRow}>
                  <span className={styles.wifiStatusLabel}>Home Wi-Fi</span>
                  <span className={styles.wifiStatusValue}>
                    {info?.wifi?.connected ? (
                      <span className={styles.wifiStatusBadgeOnline}>
                        Connected to <strong>{info.wifi.ssid}</strong> (IP:{' '}
                        <a
                          href={`http://${info.wifi.ip}`}
                          target="_blank"
                          rel="noreferrer"
                          className={styles.wifiLink}
                        >
                          {info.wifi.ip}
                        </a>
                        , {info.wifi.rssi} dBm)
                      </span>
                    ) : wifiMode === 'home' && (ssid || info?.wifi?.ssid) ? (
                      <span className={styles.wifiStatusBadgePending}>
                        Connecting to <strong>{ssid || info?.wifi?.ssid}</strong>...
                      </span>
                    ) : (
                      <span style={{ color: 'var(--text-3)' }}>Disabled / Hotspot Only</span>
                    )}
                  </span>
                </div>
                <div className={styles.wifiStatusRow}>
                  <span className={styles.wifiStatusLabel}>Direct Hotspot</span>
                  <span className={styles.wifiStatusValue}>
                    <span className={styles.wifiStatusBadgeOnline}>
                      Active: <strong>{apSsid || info?.wifi?.apSsid || 'Coaster-Setup'}</strong> (
                      <a
                        href="http://192.168.4.1"
                        target="_blank"
                        rel="noreferrer"
                        className={styles.wifiLink}
                      >
                        192.168.4.1
                      </a>
                      )
                    </span>
                  </span>
                </div>
              </div>

              <div className={styles.field}>
                <span className={styles.fieldLabel}>NETWORK MODE</span>
                <Segmented<WifiMode>
                  value={wifiMode}
                  onChange={setWifiMode}
                  options={[
                    { value: 'home', label: 'Home Wi-Fi (Client + AP)' },
                    { value: 'coaster', label: 'Coaster AP (Hotspot Only)' },
                  ]}
                />
              </div>

              {wifiMode === 'home' ? (
                <>
                  <div className={styles.field}>
                    <div className={styles.fieldLabelRow}>
                      <label htmlFor="wifi-ssid" className={styles.fieldLabel}>
                        Router SSID
                      </label>
                      <button
                        type="button"
                        className={styles.scanBtn}
                        style={{ height: '26px', padding: '0 8px', fontSize: '11px' }}
                        onClick={handleScanNetworks}
                        disabled={scanning}
                      >
                        <RefreshCw size={12} className={scanning ? 'spin' : ''} />
                        <span>{scanning ? 'Scanning...' : 'Scan Networks'}</span>
                      </button>
                    </div>

                    <div className={styles.scanRow}>
                      <input
                        id="wifi-ssid"
                        className={styles.textInput}
                        type="text"
                        value={ssid}
                        onChange={(e) => setSsid(e.target.value)}
                        placeholder="e.g. MyHomeNetwork"
                      />
                    </div>

                    {detectedNetworks.length > 0 && (
                      <select
                        className={styles.scanSelect}
                        onChange={(e) => {
                          if (e.target.value) {
                            const name = e.target.value.replace(/\s\([^)]+\)$/, '')
                            setSsid(name)
                          }
                        }}
                        defaultValue=""
                      >
                        <option value="" disabled>
                          Select detected Wi-Fi network...
                        </option>
                        {detectedNetworks.map((net) => (
                          <option key={net} value={net}>
                            {net}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>

                  <div className={styles.field}>
                    <label htmlFor="wifi-pass" className={styles.fieldLabel}>
                      Wi-Fi Password
                    </label>
                    <div className={styles.inputWrap}>
                      <input
                        id="wifi-pass"
                        className={`${styles.textInput} ${styles.passwordInput}`}
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Leave blank to retain existing saved password"
                      />
                      <button
                        type="button"
                        className={styles.eyeBtn}
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className={styles.field}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={apAlwaysOn}
                        onChange={(e) => setApAlwaysOn(e.target.checked)}
                      />
                      <span style={{ fontSize: '13px', fontWeight: 600 }}>
                        Keep Hotspot Active in Home Wi-Fi Mode (Concurrent AP + STA)
                      </span>
                    </label>
                    <span className={styles.fieldHelper}>
                      Recommended: Allows direct connection via phone/tablet at the coaster even if home router is offline.
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className={styles.field}>
                    <label htmlFor="ap-ssid" className={styles.fieldLabel}>
                      Access Point SSID (Hotspot Name)
                    </label>
                    <input
                      id="ap-ssid"
                      className={styles.textInput}
                      type="text"
                      value={apSsid}
                      onChange={(e) => setApSsid(e.target.value)}
                      placeholder="Coaster-Setup"
                    />
                    <span className={styles.fieldHelper}>
                      The ESP32 broadcasts its own isolated network on 192.168.4.1.
                    </span>
                  </div>

                  <div className={styles.field}>
                    <label htmlFor="ap-pass" className={styles.fieldLabel}>
                      Hotspot Password (Optional)
                    </label>
                    <div className={styles.inputWrap}>
                      <input
                        id="ap-pass"
                        className={`${styles.textInput} ${styles.passwordInput}`}
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Min 8 characters (leave blank for open access)"
                      />
                      <button
                        type="button"
                        className={styles.eyeBtn}
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                </>
              )}

              <div className={styles.field}>
                <label htmlFor="board-host" className={styles.fieldLabel}>
                  mDNS Hostname
                </label>
                <input
                  id="board-host"
                  className={styles.textInput}
                  type="text"
                  value={hostname}
                  onChange={(e) => setHostname(e.target.value.toLowerCase().trim())}
                  placeholder="coaster"
                />
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '2px' }}>
                  <span className={styles.fieldHelper}>Direct browser access address:</span>
                  <span className={styles.monoPreview}>
                    http://{hostname || 'coaster'}.local
                  </span>
                </div>
              </div>

              <Button
                variant="primary"
                loading={savingWifi}
                onClick={handleSaveWifi}
                disabled={!isWifiDirty || savingWifi}
                className={!isWifiDirty ? styles.saveWifiBtnDisabled : undefined}
              >
                {savingWifi ? 'Saving...' : isWifiDirty ? 'Save Wi-Fi Settings' : 'No changes to save'}
              </Button>
            </div>
          </Card>

          {/* Over-The-Air (OTA) Updates Card */}
          <Card
            title="Over-The-Air (OTA) Wireless Upgrade"
            subtitle="Flash binary firmware or LittleFS filesystem over local Wi-Fi."
            icon={<Upload />}
          >
            <div className={styles.form}>
              <div className={styles.field}>
                <span className={styles.fieldLabel}>TARGET COMPONENT</span>
                <Segmented<UploadTarget>
                  value={uploadTarget}
                  onChange={setUploadTarget}
                  options={[
                    { value: 'firmware', label: 'Firmware (.bin)' },
                    { value: 'fs', label: 'Web UI (Filesystem)' },
                  ]}
                />
              </div>

              {uploadTarget === 'fs' && (
                <div className={styles.otaAlertWarn}>
                  <AlertTriangle size={18} style={{ flexShrink: 0 }} />
                  <div>
                    <strong>LittleFS Overwrite Notice:</strong> Flashing the Web UI partition resets all stored sequences and controller profiles. We recommend exporting a configuration backup first.
                  </div>
                </div>
              )}

              <div className={styles.backupBtnRow}>
                <span className={styles.backupText}>Preserve mappings & show sequences:</span>
                <Button
                  variant="secondary"
                  size="sm"
                  icon={<Download size={14} />}
                  onClick={handleExportConfig}
                >
                  Export Config Backup
                </Button>
              </div>

              <div className={styles.field}>
                <span className={styles.fieldLabel}>Select Binary Package</span>
                <div
                  className={styles.otaDropzone}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    id="ota-file-input"
                    type="file"
                    accept=".bin"
                    className={styles.otaFileHidden}
                    onChange={handleFileSelect}
                    disabled={uploading}
                  />

                  {uploadFile ? (
                    <div className={styles.otaFileSelected}>
                      <div className={styles.otaFileInfo}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <FileCheck size={16} color="#10b981" />
                          <span className={styles.otaFileName}>{uploadFile.name}</span>
                        </div>
                        <span className={styles.otaFileSize}>
                          {(uploadFile.size / 1024).toFixed(1)} KB · Ready to flash
                        </span>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation()
                          setUploadFile(null)
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Upload size={24} color="var(--primary)" />
                      <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text)' }}>
                        Click to browse or drop .bin file here
                      </span>
                      <span style={{ fontSize: '11.5px', color: 'var(--text-3)' }}>
                        Accepts compiled firmware.bin or littlefs.bin
                      </span>
                    </>
                  )}
                </div>
              </div>

              {motorsRunning && (
                <div className={styles.otaAlertDanger}>
                  <AlertCircle size={18} style={{ flexShrink: 0 }} />
                  <div>
                    <strong>OTA Blocked:</strong> Physical motors are running. Halt all motors before initiating flash upload.
                  </div>
                </div>
              )}

              {uploadProgress !== null && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div className={styles.otaAlertDanger}>
                    <AlertCircle size={18} style={{ flexShrink: 0 }} />
                    <span>
                      <strong>DO NOT POWER OFF OR REBOOT:</strong> Flash programming is underway.
                    </span>
                  </div>
                  <div className={styles.capacityBarTrack} style={{ height: '10px' }}>
                    <div
                      className={`${styles.capacityBarFill} ${styles.fillCyan}`}
                      style={{ width: `${Math.round(uploadProgress * 100)}%` }}
                    />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', fontFamily: 'var(--font-mono)' }}>
                    <span>Writing flash sectors...</span>
                    <span>{Math.round(uploadProgress * 100)}%</span>
                  </div>
                </div>
              )}

              <Button
                variant="primary"
                loading={uploading}
                disabled={!uploadFile || uploading || motorsRunning}
                onClick={handleUpload}
              >
                {uploading ? 'Flashing Board Storage…' : 'Start Wireless Update'}
              </Button>
            </div>
          </Card>
        </div>

        {/* ================= Right Column: Modes & Diagnostics ================= */}
        <div className={styles.column}>
          {/* Operational Mode Card (Simulation vs Live Outputs) */}
          <Card
            title="Operational Output Mode"
            subtitle="Switch between software simulation and live high-current motor drive."
            icon={<HardDrive />}
          >
            <div className={styles.modeCardContent}>
              <div className={styles.modeSwitchContainer}>
                <div className={styles.modeInfo}>
                  <div className={styles.modeStateTitle}>
                    {simMode ? (
                      <>
                        <Shield size={16} color="#0284c7" />
                        <span>Simulation Mode (Safe Demo)</span>
                      </>
                    ) : (
                      <>
                        <Flame size={16} color="#d97706" />
                        <span>LIVE Outputs (Real Hardware)</span>
                      </>
                    )}
                  </div>
                  <span className={styles.modeStateDesc}>
                    {simMode
                      ? 'Commands are reflected in the UI and telemetry without energizing motor power stages.'
                      : 'Physical motor drivers, PCF8575 expanders, and servo PWM channels are LIVE and moving.'}
                  </span>
                </div>

                <button
                  type="button"
                  className={`${styles.switchToggleBtn} ${simMode ? styles.switchSimActive : styles.switchLiveActive}`}
                  onClick={handleRequestToggleSim}
                >
                  {simMode ? 'Switch to LIVE Outputs' : 'Switch to Safe SIM'}
                </button>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-3)' }}>
                <span>Global Mode Status:</span>
                <span className={styles.monoPreview}>
                  {simMode ? 'SIMULATION (SAFE)' : 'HARDWARE (LIVE)'}
                </span>
              </div>
            </div>
          </Card>

          {/* Multi-Magnet Train Debounce Card */}
          <Card
            title="Train Detection & Multi-Magnet Debounce"
            subtitle="Filters out trailing magnets on the same train pass (1 to 6 magnets per train)."
            icon={<Timer />}
          >
            <div className={styles.form}>
              <div className={styles.field}>
                <label htmlFor="hall-debounce" className={styles.fieldLabel}>
                  Debounce Lockout Duration (ms)
                </label>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <input
                    id="hall-debounce"
                    className={styles.textInput}
                    type="number"
                    min={100}
                    max={10000}
                    step={100}
                    value={hallDebounce}
                    onChange={(e) => setHallDebounce(Math.max(100, Math.min(10000, Number(e.target.value) || 1500)))}
                    style={{ maxWidth: '160px' }}
                  />
                  <span className={styles.monoPreview}>
                    {(hallDebounce / 1000).toFixed(2)} seconds
                  </span>
                </div>
                <span className={styles.fieldHelper}>
                  When a coaster car/train with 1–6 magnets passes a Hall sensor, only the leading magnet triggers the block event. Subsequent magnets within this lockout window are ignored. Default: 1500 ms.
                </span>
              </div>

              <Button
                variant="secondary"
                size="sm"
                loading={savingDebounce}
                onClick={async () => {
                  setSavingDebounce(true)
                  try {
                    await link.saveSystem({
                      sim: simMode,
                      duelingMode,
                      hallDebounceMs: Number(hallDebounce),
                    })
                    toast.success('Hall Debounce', `Train magnet lockout saved: ${hallDebounce} ms`)
                  } catch {
                    toast.error('Hall Debounce', 'Failed to update debounce settings.')
                  } finally {
                    setSavingDebounce(false)
                  }
                }}
              >
                {savingDebounce ? 'Saving...' : 'Save Debounce Lockout'}
              </Button>
            </div>
          </Card>

          {/* Controller Diagnostics Card */}
          <Card
            title="Controller Diagnostics & Resources"
            subtitle="ESP32-S3 hardware telemetry, memory counters, and bus statuses."
            icon={<Cpu />}
          >
            <div className={styles.diagnosticsList}>
              {/* Internal Heap Progress Bar */}
              <div className={styles.capacityCard}>
                <div className={styles.capacityHead}>
                  <span className={styles.capacityTitle}>Internal SRAM Heap</span>
                  <span className={styles.capacityMetric}>
                    {Math.round(heapFree / 1024)} KB Free ({100 - heapPercent}% available)
                  </span>
                </div>
                <div className={styles.capacityBarTrack}>
                  <div
                    className={`${styles.capacityBarFill} ${heapPercent > 80 ? styles.fillAmber : styles.fillMint}`}
                    style={{ width: `${heapPercent}%` }}
                  />
                </div>
              </div>

              {/* PSRAM Progress Bar */}
              <div className={styles.capacityCard}>
                <div className={styles.capacityHead}>
                  <span className={styles.capacityTitle}>External PSRAM</span>
                  <span className={styles.capacityMetric}>
                    {(psramFree / (1024 * 1024)).toFixed(2)} MB Free / 8.00 MB
                  </span>
                </div>
                <div className={styles.capacityBarTrack}>
                  <div
                    className={`${styles.capacityBarFill} ${styles.fillCyan}`}
                    style={{ width: `${psramPercent}%` }}
                  />
                </div>
              </div>

              {/* LittleFS Progress Bar */}
              <div className={styles.capacityCard}>
                <div className={styles.capacityHead}>
                  <span className={styles.capacityTitle}>LittleFS Flash Partition</span>
                  <span className={styles.capacityMetric}>
                    {Math.round(fsUsed / 1024)} KB / {Math.round(fsTotal / 1024)} KB ({fsPercent}% used)
                  </span>
                </div>
                <div className={styles.capacityBarTrack}>
                  <div
                    className={`${styles.capacityBarFill} ${fsPercent > 80 ? styles.fillAmber : styles.fillCyan}`}
                    style={{ width: `${fsPercent}%` }}
                  />
                </div>
              </div>

              {/* Detailed Specs Table */}
              <div className={styles.diagMetaTable}>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Formatted Uptime</span>
                  <span className={styles.diagValue}>
                    {info ? formatUptime(info.uptimeMs) : '0s'}
                  </span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Firmware Version</span>
                  <span className={styles.diagValue}>{info?.fw || '0.1.0'}</span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Processor & Revision</span>
                  <span className={styles.diagValue}>{info?.chip || 'ESP32-S3 (v0.2)'}</span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Current IP Address</span>
                  <span className={styles.diagValue}>{info?.wifi?.ip || info?.wifi?.apIp || '10.139.140.245'}</span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>MAC Address</span>
                  <span className={styles.diagValue}>24:DC:C3:9A:14:80</span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Wi-Fi Signal Strength</span>
                  <span className={styles.diagValue}>{info?.wifi?.rssi ?? -48} dBm (Optimal)</span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>I2C Bus Status</span>
                  <span className={styles.diagValue} style={{ color: '#10b981' }}>
                    PCF8575 Online at 0x20
                  </span>
                </div>
                <div className={styles.diagRow}>
                  <span className={styles.diagLabel}>Boot Reset Reason</span>
                  <span className={styles.diagValue}>POWERON_RESET</span>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* ================= 3. Full-Width Guarded Danger Zone ================= */}
        <div className={styles.dangerZoneCard}>
          <div className={styles.dangerZoneHead}>
            <AlertTriangle size={20} />
            <h2 className={styles.dangerZoneTitle}>Guarded Operations & Danger Zone</h2>
          </div>

          <div className={styles.dangerGrid}>
            {/* Coaster Layout Mode */}
            <div className={styles.dangerItem}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                  <Swords size={16} color="var(--primary)" />
                  <span className={styles.dangerItemTitle}>
                    Layout: {duelingMode ? 'Dueling Coasters' : 'Single Unified Coaster'}
                  </span>
                </div>
                <p className={styles.dangerItemDesc}>
                  {duelingMode
                    ? 'I/O channels partitioned into Track A (H1–6 / M1–3) and Track B (H7–12 / M4–6).'
                    : 'Unified track loop controlling all 12 sensors and 6 motors simultaneously.'}
                </p>
              </div>
              <Button
                variant={duelingMode ? 'secondary' : 'primary'}
                size="sm"
                onClick={handleRequestToggleDueling}
              >
                {duelingMode ? 'Switch to Single Coaster' : 'Enable Dueling Mode'}
              </Button>
            </div>

            {/* Reboot Board Controller */}
            <div className={styles.dangerItem}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                  <RefreshCw size={16} color="#ef4444" />
                  <span className={styles.dangerItemTitle}>Restart Controller</span>
                </div>
                <p className={styles.dangerItemDesc}>
                  Power-cycle the ESP32-S3 microcontroller. Temporarily halts telemetry and clears volatile PWM buffers.
                </p>
              </div>
              <Button variant="danger" size="sm" onClick={handleRequestReboot}>
                Reboot Controller
              </Button>
            </div>

            {/* Factory Reset */}
            <div className={styles.dangerItem}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                  <AlertCircle size={16} color="#ef4444" />
                  <span className={styles.dangerItemTitle}>Factory Reset</span>
                </div>
                <p className={styles.dangerItemDesc}>
                  Reset Wi-Fi credentials, LittleFS configuration mappings, and sequencing states back to firmware defaults.
                </p>
              </div>
              <Button variant="danger" size="sm" onClick={handleRequestFactoryReset}>
                Erase & Reset
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Global Confirmation Modal Dialog */}
      {confirmModal && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modalCard}>
            <div className={styles.modalHeader}>
              {confirmModal.isDanger ? (
                <AlertTriangle className={styles.modalIconDanger} />
              ) : (
                <AlertCircle className={styles.modalIconWarn} />
              )}
              <h3 className={styles.modalTitle}>{confirmModal.title}</h3>
            </div>
            <div className={styles.modalBody}>{confirmModal.message}</div>
            <div className={styles.modalActions}>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setConfirmModal(null)}
              >
                Cancel
              </Button>
              <Button
                variant={confirmModal.isDanger ? 'danger' : 'primary'}
                size="sm"
                onClick={confirmModal.onConfirm}
              >
                {confirmModal.confirmLabel}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
