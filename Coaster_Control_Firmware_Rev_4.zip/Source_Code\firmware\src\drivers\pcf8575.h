#ifndef DRIVER_PCF8575_H
#define DRIVER_PCF8575_H

#include <stdint.h>
#include <stdbool.h>
#include "../interface/error.h"
#include "../interface/i2c_if.h"
#include "pcf8575_reg.h"

/**
 * @brief Device context structure for a PCF8575 16-bit I2C I/O expander instance.
 *
 * Encapsulates all state per device instance (no global state), enabling
 * multiple expanders on the same or different I2C buses.
 */
typedef struct {
    const i2c_if_t *i2c;
    uint8_t         i2c_addr;
    uint16_t        port_latch;
    bool            initialized;
} pcf8575_t;

/**
 * @brief Initialize a PCF8575 device instance and configure all 16 quasi-bidirectional
 *        pins as weak pull-up inputs (0xFFFF).
 *
 * @param dev Pointer to PCF8575 device context
 * @return fw_err_t FW_OK on success, FW_ERR_INVALID_PARAM or FW_ERR_COMMUNICATION on failure
 */
fw_err_t pcf8575_init(pcf8575_t *dev);

/**
 * @brief Read all 16 input pins from the PCF8575 port.
 *
 * @param dev      Pointer to initialized PCF8575 device context
 * @param out_mask Output pointer receiving the 16-bit pin state (bit = 0 when active-low pressed)
 * @return fw_err_t FW_OK on success
 */
fw_err_t pcf8575_read_port(pcf8575_t *dev, uint16_t *out_mask);

/**
 * @brief Write a 16-bit output/pull-up mask to the PCF8575 port.
 *
 * @param dev  Pointer to initialized PCF8575 device context
 * @param mask 16-bit value to write (1 = input / weak pull-up, 0 = driven low)
 * @return fw_err_t FW_OK on success
 */
fw_err_t pcf8575_write_port(pcf8575_t *dev, uint16_t mask);

#endif /* DRIVER_PCF8575_H */

