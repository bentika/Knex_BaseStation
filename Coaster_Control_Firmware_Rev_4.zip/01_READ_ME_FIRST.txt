================================================================================
K'NEX ROLLER COASTER BASE STATION - REVISION 4 CLIENT DELIVERY PACKAGE
Firmware v0.2.0 (Rev 4) | ESP32-S3-DevKitC-1 N16R8 | Dual-Track RunLoop & Web Dashboard
================================================================================

Dear Client,

Here is your Revision 4 delivery package for the K'NEX Roller Coaster Base
Station! This update incorporates all of your testing feedback from the physical
Rev 3 boards, along with major hardware optimizations, enhanced real-time control,
and new interactive software features.

--------------------------------------------------------------------------------
WHAT'S NEW IN REVISION 4
--------------------------------------------------------------------------------
1. 100% DEFAULT MOTOR PWM:
   All motor outputs and UI sliders now start at 100% PWM power by default
   (instead of 50%/80%), ensuring reliable starting torque for all motor types.

2. CLEAN, NEUTRAL SENSOR & MOTOR LABELS:
   Removed confusing pre-named labels ("Station Approach", "Station Stop & Dispatch",
   "Lift Chain", etc.). All channels now default cleanly to "Hall 1".."Hall 12",
   "Motor 1".."Motor 6", and "Servo 1".."Servo 6". The UI also accurately displays
   the true hardware GPIO numbers from pins.h.

3. NO PHANTOM RUN LOOP TRIGGERS IN MANUAL TEST:
   Opening the Manual page automatically pauses the Run Loop sequencer, and
   triggering Hall sensors in Manual Test mode no longer triggers unintended
   servo or motor sequences.

4. COMPLETE 6-SERVO HARDWARE SUPPORT (SERVOS 3-6 FIXED):
   Resolved the Rev 3 hardware limitation where Servos 3-6 did not respond due to
   ESP32-S3 LEDC channel exhaustion. Servos are now driven via the ESP32-S3
   dedicated MCPWM Group 0 hardware peripheral (50 Hz / 20,000 us period), giving
   all 6 servos completely independent hardware pulse generation without any
   motor PWM conflicts.

5. PROGRAMMABLE DISPATCH INTRO BLOCK:
   The Dispatch button is now fully integrated into the Run Loop sequencer as a
   programmable intro block (id = 0) feeding into Hall 1 -> Hall 2 -> etc., with
   its own timed motor, servo, delay, and WLED action stages.

6. ONE-CLICK MOTOR & SERVO QUICK TOGGLES:
   Added instantaneous On/Off toggle buttons for all 6 motors (toggles between
   100% PWM and Stop) and all 6 servos (toggles between 0 deg and 180 deg) in both
   the Web Dashboard and the physical 16-button PCF8575 arcade control panel.

7. CUSTOMIZABLE DELAYS FOR TIMED STAGES:
   Added an interactive delay duration picker (+0.5s, +1s, +2s, +3s, +5s, or
   custom input) to the "Add Timed Stage" button in the Run Loop sequencer,
   with inline editing for every timed step.

8. INTERACTIVE TRACK SCHEMATIC VECTOR EDITOR:
   The track diagram in the Run Loop page now features a drag-and-drop vector
   editor allowing you to position sensor and dispatch nodes to match your physical
   layout (with presets like Loop Shape, Oval, and Figure-8). Inactive Hall sensors
   automatically disappear from the schematic view.

9. EMBEDDED ARCHITECTURE & 500 HZ REAL-TIME CONTROL:
   The firmware has been upgraded to a strict layered architecture:
   - Dedicated 500 Hz drift-free ControlTask on Core 1 for motor ramping and
     sub-millisecond Hall timing.
   - Hardware IRAM falling-edge GPIO ISRs (< 1.5 us) with deferred multi-magnet
     train debouncing.
   - Hot-plug support and automatic fault recovery for the PCF8575 control panel.
   - Liveness watchdog monitoring and thread-safe recursive mutexes.

--------------------------------------------------------------------------------
1. QUICK START: HOW TO FLASH YOUR ESP32-S3 (2 MINUTES)
--------------------------------------------------------------------------------
On Windows:
  1. Plug your ESP32-S3 into your PC via USB.
  2. Double-click "flash_firmware_windows.bat".
  3. Enter your COM port (e.g. COM3, COM5).
  4. The script flashes the complete Rev 4 firmware and LittleFS web partition.

On macOS / Linux:
  1. Open Terminal in this folder.
  2. Run: chmod +x flash_firmware_mac_linux.sh && ./flash_firmware_mac_linux.sh
  3. Enter your serial device port (e.g. /dev/ttyUSB0).

--------------------------------------------------------------------------------
2. CONNECTING TO THE CONTROLLER
--------------------------------------------------------------------------------
Once flashed:
  1. Connect to the controller's Wi-Fi hotspot:
       SSID:     Coaster-Setup
       Password: (Open access by default)
  2. Open any web browser and navigate to:
       http://192.168.4.1
  3. (Optional) Connect to your home Wi-Fi:
       Go to Settings -> Network Mode -> "Home Wi-Fi (Client + AP)".
       Enter your SSID & password. The board connects to your home network while
       keeping the "Coaster-Setup" hotspot active as a backup.
       Access via LAN at: http://coaster.local

--------------------------------------------------------------------------------
3. PACKAGE CONTENTS
--------------------------------------------------------------------------------
- Binaries/
    * firmware.factory.bin  - Complete single-image flash file (0x0)
    * firmware.bin          - Production ESP32-S3 Rev 4 firmware (0x10000)
    * littlefs.bin          - Web Dashboard LittleFS partition (0xC90000)
    * bootloader.bin        - ESP32-S3 second-stage bootloader (0x0)
    * partitions.bin        - 16MB custom partition map (0x8000)
    * boot_app0.bin         - OTA boot descriptor (0xe000)

- Documentation_PDF/
    * 1_Project_Overview.pdf
    * 2_Hardware_Pinout_and_Wiring.pdf
    * 3_Fresh_PC_Flashing_Guide.pdf
    * 4_Web_Dashboard_Operator_Guide.pdf
    * 5_REST_and_WebSocket_API_Reference.pdf

- Source_Code/
    * firmware/ - PlatformIO C++ firmware project with Arduino core 3.x
    * web/      - React 19 / TypeScript / Vite responsive dashboard source
    * docs/     - Complete L1-L5 embedded engineering documentation suite

================================================================================

