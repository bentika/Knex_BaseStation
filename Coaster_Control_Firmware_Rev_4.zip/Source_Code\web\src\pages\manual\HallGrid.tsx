import { RotateCcw, Zap } from 'lucide-react'
import styles from './HallGrid.module.css'

interface Props {
  halls: boolean[]
  hallCounts: number[]
  hallFlash: number[]
  onSimulate: (id: number) => void
  onResetCounts: () => void
  disabled?: boolean
}

const HALL_PINS: Record<number, string> = {
  1: 'GPIO 13',
  2: 'GPIO 47',
  3: 'GPIO 41',
  4: 'GPIO 2',
  5: 'GPIO 1',
  6: 'GPIO 44',
  7: 'GPIO 14',
  8: 'GPIO 21',
  9: 'GPIO 40',
  10: 'GPIO 42',
  11: 'GPIO 17',
  12: 'GPIO 16',
}

export function HallGrid({
  halls,
  hallCounts,
  hallFlash,
  onSimulate,
  onResetCounts,
  disabled,
}: Props) {
  const now = performance.now()

  return (
    <div className={styles.container}>
      {/* Legend & Reset Button Bar */}
      <div className={styles.toolbar}>
        <div className={styles.legend}>
          <span className={styles.legendDetected}>
            <span className={styles.legendBeaconActive} />
            DETECTED (LOW)
          </span>
          <span className={styles.legendDivider}>|</span>
          <span className={styles.legendNormal}>
            <span className={styles.legendBeaconInactive} />
            NORMAL (HIGH)
          </span>
        </div>

        <button
          type="button"
          className={styles.resetBtn}
          onClick={onResetCounts}
          disabled={disabled}
        >
          <RotateCcw className={styles.resetIcon} />
          <span>Reset Counters</span>
        </button>
      </div>

      {/* 12 Hall Effect Sensors Grid */}
      <div className={styles.grid}>
        {halls.map((active, i) => {
          const id = i + 1
          const isFlashing = now - (hallFlash[i] ?? 0) < 450
          const count = hallCounts[i] ?? 0
          const isTriggered = active || isFlashing
          const pin = HALL_PINS[id] || `PIN ${id}`

          return (
            <div
              key={id}
              className={`${styles.card} ${isTriggered ? styles.cardActive : ''}`}
              data-id={id}
            >
              <div className={styles.cardHeader}>
                <div className={styles.idGroup}>
                  <span className={styles.cardId}>H{id < 10 ? `0${id}` : id}</span>
                  <span className={styles.pinTag}>{pin}</span>
                </div>
                <span
                  className={`${styles.beacon} ${isTriggered ? styles.beaconActive : ''}`}
                />
              </div>

              <div className={styles.countGroup}>
                <span className={styles.countLabel}>TRIGGERS</span>
                <span className={`${styles.countVal} mono`}>{count}</span>
              </div>

              <button
                type="button"
                className={styles.simBtn}
                onClick={() => onSimulate(id)}
                disabled={disabled}
                title={`Simulate magnet passing sensor H${id}`}
              >
                <Zap className={styles.simIcon} />
                <span>Simulate</span>
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
