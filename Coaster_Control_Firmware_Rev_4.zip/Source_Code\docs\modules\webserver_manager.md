# WebServerManager Module (`docs/modules/webserver_manager.md`)

## Purpose

[`WebServerManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/net/WebServerManager.h) manages Wi-Fi networking (`AP` + `STA` concurrent mode, mDNS `coaster.local`, Captive Portal DNS), the asynchronous HTTP REST API (`/api/v1/*`), real-time WebSocket telemetry (`/ws`), and OTA firmware/LittleFS updates.

## Responsibilities

- Broadcasts live hardware state (`motors`, `servos`, `halls`, `hallCounts`, `runloop`, `panel`, `estop`) over `/ws` at 5–16 Hz.
- Processes real-time WebSocket commands (`motor`, `motorStop`, `allStop`, `servo`, `simHall`, `dispatch`, `startLoop`, `stopLoop`, `testHall`, `estop`, `reset`).
- Serves gzipped single-page React dashboard assets from LittleFS (`/`).
- Defers system reboot requests (`_scheduledReboot`) to `WebServerManager::update()` so AsyncTCP callbacks never block.

