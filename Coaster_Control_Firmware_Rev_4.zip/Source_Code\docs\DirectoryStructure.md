# Directory Structure

```text
rollor-coster-esp32-hall-effects-project-12/
├── README.md                            — Top-level project overview, quick start & pinout
├── firmware/                            — ESP32-S3 PlatformIO firmware project
│   ├── platformio.ini                   — Build targets (s3, s3-bench, s3-sim, s3-ota, esp32-sim)
│   ├── data/                            — Gzipped LittleFS web UI image assets
│   └── src/
│       ├── main.cpp                     — App startup, ControlTask (500 Hz) & Watchdog monitor
│       ├── pins.h                       — Rev 3 PCB GPIO mapping & Wi-Fi pre-flash macros
│       ├── interface/                   — Hardware-independent contracts
│       │   ├── error.h                  — Unified fw_err_t enumeration
│       │   └── i2c_if.h                 — Abstract I2C bus interface (i2c_if_t)
│       ├── io/                          — Actuation & sensor hardware abstraction
│       │   ├── IOInterface.h            — Abstract motor, servo, hall & E-Stop interface
│       │   ├── RealIO.h                 — ESP32-S3 LEDC + MCPWM + GPIO ISR driver header
│       │   └── RealIO.cpp               — ESP32-S3 hardware driver & ISR implementation
│       ├── drivers/                     — External peripheral device drivers & panel service
│       │   ├── pcf8575_reg.h            — PCF8575 register/address constants
│       │   ├── pcf8575.h                — PCF8575 context struct (pcf8575_t) & driver API
│       │   ├── pcf8575.cpp              — Bus-independent PCF8575 implementation
│       │   ├── PanelManager.h           — 16-button arcade panel service header
│       │   └── PanelManager.cpp         — BSP I2C adapter, debounce & button dispatch
│       ├── engine/                      — Coaster automation business logic
│       │   ├── RunLoopEngine.h          — Block-zone & timed-stage sequencer header
│       │   └── RunLoopEngine.cpp        — Sequencer state machine & JSON persistence
│       ├── config/                      — System configuration persistence
│       │   ├── ConfigManager.h          — AppConfig model & manager header
│       │   └── ConfigManager.cpp        — LittleFS /config.json loader/saver
│       └── net/                         — Networking, HTTP REST, WebSocket & WLED
│           ├── WebServerManager.h       — AsyncWebServer, WebSocket & AP+STA manager
│           ├── WebServerManager.cpp     — REST endpoints, WS telemetry & captive portal
│           ├── WledManager.h            — Async WLED HTTP trigger queue & Core 0 worker
│           └── WledManager.cpp          — Non-blocking WLED preset dispatcher
├── web/                                 — React 19 + TypeScript + Vite Web Dashboard
│   ├── package.json                     — Scripts (dev, dev:mock, build)
│   └── src/
│       ├── api/                         — WebSocket/REST client, types & mockBoard simulator
│       ├── components/                  — AppShell navigation, status bar & E-Stop controls
│       ├── config/                      — Hardware metadata defaults (hardware.ts)
│       └── pages/                       — RunLoopPage, ManualPage, PanelPage, WledPage, SettingsPage
├── docs/                                — Embedded engineering documentation (L1–L5)
│   ├── Architecture.md                  — Layered architecture & dependency rules
│   ├── Build.md                         — Build & flash instructions
│   ├── Hardware.md                      — Complete ESP32-S3 Rev 3 peripheral & pinout table
│   ├── DirectoryStructure.md            — Repository structure reference
│   ├── TaskDesign.md                    — FreeRTOS task architecture, WCET & watchdog design
│   ├── ISRDesign.md                     — Hall GPIO ISR latency & deferred processing design
│   ├── StateMachine.md                  — RunLoopEngine & Wi-Fi state machines
│   ├── interfaces/                      — L3 Interface specifications
│   │   ├── io_interface.md
│   │   └── i2c_interface.md
│   └── modules/                         — L2 Module design documents
│       ├── io_driver.md
│       ├── runloop_engine.md
│       ├── panel_manager.md
│       ├── wled_manager.md
│       └── webserver_manager.md
└── dilivered/                           — Synchronized client delivery package
```

