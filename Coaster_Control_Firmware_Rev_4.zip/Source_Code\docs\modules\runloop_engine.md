# RunLoopEngine Module (`docs/modules/runloop_engine.md`)

## Purpose

[`RunLoopEngine`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/engine/RunLoopEngine.h) executes block-zone and time-staged coaster automation sequences for Single Coaster Mode (`instanceA`) and Dueling Coaster Mode (`instanceA` + `instanceB`).

## Responsibilities

- Manages programmable sequences for **Dispatch (`hallId = 0`)** and **Hall 1 – Hall 12 (`hallId = 1..12`)**.
- Executes multi-action timed stages (`RunStep` with configurable `delayMs`), supporting:
  - `ActionType::MOTOR` (`start`, `stop`, `runTime` with automatic timer shutoff, default `100%` PWM)
  - `ActionType::SERVO` (`0–180°` positioning)
  - `ActionType::DELAY` (timed wait)
  - `ActionType::WAIT_DISPATCH` (holds stage until operator presses Dispatch or timeout expires)
  - `ActionType::WLED` (triggers network WLED preset)
- Enforces per-sensor multi-magnet train lockout (`lockoutMs`, default `1500 ms`) so multi-car coaster trains only trigger a block sequence on the leading car.
- Persists programs to LittleFS (`/runloop.json`, `/runloop_a.json`, `/runloop_b.json`).

## Dependencies

- [`IOInterface`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/IOInterface.h)
- [`WledManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/net/WledManager.h)
- [`ConfigManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/config/ConfigManager.h)

