#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>
#include "pins.h"
#include "config/ConfigManager.h"
#include "io/RealIO.h"
#include "net/WebServerManager.h"
#include "net/WledManager.h"
#include "engine/RunLoopEngine.h"
#include "drivers/PanelManager.h"

#ifdef ENABLE_TEMP_SERIAL
  #define DEBUG_PRINT(...)   Serial.print(__VA_ARGS__)
  #define DEBUG_PRINTLN(...) Serial.println(__VA_ARGS__)
  #define DEBUG_PRINTF(...)  Serial.printf(__VA_ARGS__)
#else
  #define DEBUG_PRINT(...)   ((void)0)
  #define DEBUG_PRINTLN(...) ((void)0)
  #define DEBUG_PRINTF(...)  ((void)0)
#endif

#define SERIAL_BAUD_RATE                (115200UL)
#define BOOT_SETTLE_DELAY_MS            (500UL)
#define DUELING_TRACK_A_MAX_HALL        (6U)

#define CONTROL_TASK_PERIOD_MS          (2U)
#define CONTROL_TASK_PRIORITY           (5U)
#define CONTROL_TASK_STACK_BYTES        (8192U)
#define CONTROL_TASK_CORE               (1)

#define COMM_TASK_PERIOD_MS             (5U)
#define HEALTH_MONITOR_INTERVAL_MS      (5000UL)
#define WATCHDOG_CONTROL_TIMEOUT_MS     (500UL)

static RealIO s_realIO;
static TaskHandle_t s_controlTaskHandle = nullptr;
static volatile uint32_t s_controlTaskHeartbeatMs = 0U;

/**
 * @brief Dedicated 500 Hz Real-Time Control & I/O Task (`embedded-rtos-design`).
 *
 * Uses drift-free `vTaskDelayUntil` scheduling so motor PWM ramping, servo trajectory
 * interpolation, deferred Hall ISR edge processing, and RunLoop block-zone timing
 * remain completely isolated from HTTP/WebSocket/Wi-Fi communication jitter.
 */
static void control_task_entry(void* param) {
    (void)param;
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xPeriodTicks = pdMS_TO_TICKS(CONTROL_TASK_PERIOD_MS);

    for (;;) {
        s_controlTaskHeartbeatMs = (uint32_t)millis();

        s_realIO.update();
        RunLoopEngine::instanceA().update();
        if (ConfigManager::instance().config().duelingMode) {
            RunLoopEngine::instanceB().update();
        }

        vTaskDelayUntil(&xLastWakeTime, xPeriodTicks);
    }
}

/**
 * @brief RTOS Health & Watchdog Monitor (`embedded-rtos-design`).
 *
 * Verifies periodic task liveness (`ControlTask` and `WledWorker`), monitors
 * queue fill levels and stack high-water marks, and forces Emergency Stop safe
 * state if the real-time control task ever stalls.
 */
static void health_monitor_check(uint32_t nowMs) {
    static uint32_t s_lastHealthLogMs = 0U;

    // 1. Hard real-time ControlTask liveness watchdog check (every loop pass)
    uint32_t controlAgeMs = nowMs - s_controlTaskHeartbeatMs;
    if (s_controlTaskHandle != nullptr && controlAgeMs > WATCHDOG_CONTROL_TIMEOUT_MS) {
        if (!s_realIO.isEstop()) {
            s_realIO.setEstop(true);
            WebServerManager::instance().logEvent("error", "WATCHDOG FAULT: ControlTask stalled — Emergency Stop engaged!");
        }
    }

    // 2. Periodic telemetry & stack/queue health check (every 5000 ms)
    if ((nowMs - s_lastHealthLogMs) >= HEALTH_MONITOR_INTERVAL_MS) {
        s_lastHealthLogMs = nowMs;

        uint32_t ctrlStackFree = (s_controlTaskHandle != nullptr)
                                     ? (uint32_t)uxTaskGetStackHighWaterMark(s_controlTaskHandle)
                                     : 0U;
        uint32_t wledQueueDepth = WledManager::instance().getQueueDepth();
        uint32_t wledStackFree = WledManager::instance().getStackHighWaterMark();

        (void)ctrlStackFree;
        (void)wledQueueDepth;
        (void)wledStackFree;

        DEBUG_PRINTF(
            "[HEARTBEAT] Uptime: %lu s | Heap: %u B | CtrlStackFree: %u B | WledQ: %u/%u (Stack: %u B) | WS: %u | AP: %u\r\n",
            (unsigned long)(nowMs / 1000UL),
            ESP.getFreeHeap(),
            ctrlStackFree,
            wledQueueDepth,
            WLED_QUEUE_DEPTH,
            wledStackFree,
            WebServerManager::instance().wsClientCount(),
            WiFi.softAPgetStationNum()
        );
    }
}

void setup() {
#ifdef ENABLE_TEMP_SERIAL
    // Bench testing only: UART0 uses GPIO 43 (TX) and GPIO 44 (RX).
    // In production, GPIO 43 is Servo 5 and GPIO 44 is Hall 6.
    Serial.begin(SERIAL_BAUD_RATE);
    delay(BOOT_SETTLE_DELAY_MS);
    DEBUG_PRINTLN("\r\n\r\n==================================================");
    DEBUG_PRINTLN("  K'nex Roller Coaster Base Station Starting (BENCH DEBUG)...");
    DEBUG_PRINTLN("  ESP32-S3 Firmware Version: 0.1.0");
    DEBUG_PRINTLN("==================================================");
#endif

    // 1. Initialize Configuration & LittleFS
    DEBUG_PRINTLN("[INIT] Mounting LittleFS & loading config...");
    (void)ConfigManager::instance().begin();
    DEBUG_PRINTF("[INIT] LittleFS Total: %u bytes, Used: %u bytes\r\n", LittleFS.totalBytes(), LittleFS.usedBytes());

    // 2. Initialize Hardware I/O
    DEBUG_PRINTLN("[INIT] Initializing Hardware I/O...");
    s_realIO.begin();
#ifdef COASTER_DEFAULT_SIM
    s_realIO.setSimMode(true);
#else
    s_realIO.setSimMode(ConfigManager::instance().config().simMode);
#endif
    s_realIO.setHallDebounceMs(ConfigManager::instance().config().hallDebounceMs);
    DEBUG_PRINTF("[INIT] I/O Mode: %s | Hall Train Debounce: %u ms\r\n",
        s_realIO.isSimMode() ? "SIMULATION" : "HARDWARE",
        ConfigManager::instance().config().hallDebounceMs);

    // 3. Connect Deferred Hall Trigger Callback (invoked in ControlTask context)
    s_realIO.setHallCallback([](uint8_t hallId) {
        DEBUG_PRINTF("[HALL] Deferred ISR Event: Hall Sensor %u triggered!\r\n", hallId);
        if (ConfigManager::instance().config().duelingMode) {
            if (hallId <= DUELING_TRACK_A_MAX_HALL) {
                RunLoopEngine::instanceA().onHallTriggered(hallId);
            } else {
                RunLoopEngine::instanceB().onHallTriggered((uint8_t)(hallId - DUELING_TRACK_A_MAX_HALL));
            }
        } else {
            RunLoopEngine::instanceA().onHallTriggered(hallId);
        }
    });

    // 4. Initialize Subsystems
    DEBUG_PRINTLN("[INIT] Initializing WLED & RunLoop Engines...");
    (void)WledManager::instance().begin();
    RunLoopEngine::instanceA().begin(&s_realIO, 'A');
    RunLoopEngine::instanceB().begin(&s_realIO, 'B');
    (void)PanelManager::instance().begin(&s_realIO);
    DEBUG_PRINTF("[INIT] Panel Expander (PCF8575): %s\r\n",
        PanelManager::instance().isDetected() ? "DETECTED (0x20)" : "NOT DETECTED (no panel plugged in)");

    // 5. Initialize Web Server, WebSocket, and Network Services
    DEBUG_PRINTLN("[INIT] Starting Web Server & Wi-Fi...");
    WebServerManager::instance().begin(&s_realIO);

    // 6. Spawn High-Priority Drift-Free Real-Time Control Task on Core 1
    s_controlTaskHeartbeatMs = (uint32_t)millis();
    (void)xTaskCreatePinnedToCore(
        control_task_entry,
        "ControlTask",
        CONTROL_TASK_STACK_BYTES,
        nullptr,
        CONTROL_TASK_PRIORITY,
        &s_controlTaskHandle,
        CONTROL_TASK_CORE
    );

    DEBUG_PRINTLN("\r\n[READY] System initialized successfully!");
    DEBUG_PRINTLN("--------------------------------------------------");
    const AppConfig& cfg = ConfigManager::instance().config();
    DEBUG_PRINTF("Wi-Fi Mode:        %s\r\n", cfg.wifiMode.c_str());
    DEBUG_PRINTF("Access Point SSID: %s\r\n", cfg.apSsid.c_str());
    DEBUG_PRINTF("Access Point IP:   http://%s\r\n", WiFi.softAPIP().toString().c_str());
    if (WiFi.status() == WL_CONNECTED) {
        DEBUG_PRINTF("Connected to:      %s\r\n", WiFi.SSID().c_str());
        DEBUG_PRINTF("Local IP Address:  http://%s\r\n", WiFi.localIP().toString().c_str());
    }
    DEBUG_PRINTF("mDNS URL:          http://%s.local\r\n", cfg.hostname.c_str());
    DEBUG_PRINTLN("Web Server Port:   80");
    DEBUG_PRINTLN("WebSocket Path:    /ws");
    DEBUG_PRINTLN("==================================================\r\n");
}

void loop() {
    static TickType_t s_commLastWakeTime = 0U;
    static bool s_wakeInitialized = false;
    if (!s_wakeInitialized) {
        s_commLastWakeTime = xTaskGetTickCount();
        s_wakeInitialized = true;
    }

    // Communication, I2C Panel Service, and Health/Watchdog Monitoring
    PanelManager::instance().update();
    WebServerManager::instance().update();
    health_monitor_check((uint32_t)millis());

    vTaskDelayUntil(&s_commLastWakeTime, pdMS_TO_TICKS(COMM_TASK_PERIOD_MS));
}
