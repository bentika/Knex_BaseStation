import { OctagonAlert } from 'lucide-react'
import { useBoard } from '../store/boardStore'
import styles from './EstopButton.module.css'

export function EstopButton() {
  const estop = useBoard((s) => s.state?.estop ?? false)
  const send = useBoard((s) => s.send)

  return (
    <button
      id="estop-btn"
      type="button"
      className={`${styles.estop} ${estop ? styles.active : ''}`}
      onClick={() => send({ c: estop ? 'reset' : 'estop' })}
      aria-label={estop ? 'Reset Emergency Stop' : 'Emergency Stop'}
      title={estop ? 'Click to reset E-STOP' : 'Emergency Stop – halts all outputs'}
    >
      <OctagonAlert className={styles.icon} />
      <span className={styles.label}>{estop ? 'RESET' : 'E-STOP'}</span>
    </button>
  )
}
