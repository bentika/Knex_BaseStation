# State Machine Design (`embedded-documentation` L5)

## 1. Coaster Run Loop Sequencer State Machine (`RunLoopEngine`)

Each `RunLoopEngine` instance (`instanceA` for Single/Track A, `instanceB` for Track B in Dueling Mode) implements a deterministic event- and timer-driven state machine.

### State Diagram

```text
                    +------------------------+
                    |       DISARMED         |
                    | (_engineActive=false)  |
                    +-----------+------------+
                                |
           startEngine() /      |
           dispatch() /         |
           testFireHall()       ▼
                    +------------------------+
       +----------->|       IDLE_ARMED       |<-----------+
       |            |  (_engineActive=true,  |            |
       |            |   _activeHall = -1)    |            |
       |            +---+----------------+---+            |
       |                |                |                |
       |   dispatch()   |                | onHallTriggered(1..12)
       |   (hallId = 0) |                | (lockout passed)
       |                ▼                ▼                |
       |            +------------------------+            |
       |            |     STAGE_EXECUTING    |            |
       |            | (_activeHall = 0..12,  |<-------+   |
       |            |  _activeStep = 0..N-1) |        |   |
       |            +---+--------+-------+---+        |   |
       |                |        |       |            |   |
       |     Final step |        |       | Step has   |   | Next step
       |     completed  |        |       | WAIT_      |   | elapsed or
       |                |        |       | DISPATCH   |   | dispatch()
       |                |        |       ▼            |   |
       |                |        |   +--------------------+
       |                |        |   |  WAITING_DISPATCH  |
       |                |        |   | (_waitingDispatch) |
       |                |        |   +--------------------+
       +----------------+        |
                                 | isEstop() == true
                                 ▼
                    +------------------------+
                    |      ESTOP_FAULT       |
                    | (All motors = 0% PWM)  |
                    +------------------------+
```

### State Transition Table

| Transition | From State | To State | Trigger / Condition | Actions Executed |
|---|---|---|---|---|
| `arm` | `DISARMED` | `IDLE_ARMED` | `startEngine()` called | `_engineActive = true` |
| `dispatch_intro` | `DISARMED` / `IDLE_ARMED` | `STAGE_EXECUTING` (`_activeHall = 0`) | `dispatch()` called when not waiting on a `WAIT_DISPATCH` action | Fires Dispatch WLED preset (if `> 0`) and starts Step `0` of `Dispatch` (`id = 0`) program |
| `hall_trigger` | `IDLE_ARMED` / `STAGE_EXECUTING` | `STAGE_EXECUTING` (`_activeHall = 1..12`) | `onHallTriggered(h)` where `now - _lastHallTriggerMs[h-1] >= lockoutMs` | Preempts previous Hall sequence, fires Hall WLED preset, starts Step `0` of Hall `h` |
| `step_advance` | `STAGE_EXECUTING` | `STAGE_EXECUTING` (`_activeStep + 1`) | `(now - _stepStartMs) >= _stepDurationMs` and `_activeStep + 1 < steps.size()` | Executes all concurrent `MOTOR`, `SERVO`, `DELAY`, `WLED`, `WAIT_DISPATCH` actions in next stage |
| `wait_operator` | `STAGE_EXECUTING` | `WAITING_DISPATCH` | Stage contains `ActionType::WAIT_DISPATCH` | Pauses sequence timer; arms `_dispatchTimeoutMs` |
| `operator_release` | `WAITING_DISPATCH` | `STAGE_EXECUTING` (`_activeStep + 1`) | Operator presses Dispatch button (`dispatch()`) OR `(now - _dispatchWaitStartMs) >= _dispatchTimeoutMs` | Clears `_waitingDispatch` and advances immediately to `_activeStep + 1` |
| `sequence_done` | `STAGE_EXECUTING` | `IDLE_ARMED` | `_activeStep + 1 >= steps.size()` | `finishCurrentProgram()` resets `_activeHall = -1`, `_activeStep = -1` |
| `estop` | `ANY` | `ESTOP_FAULT` | `_io->isEstop() == true` or `stopEngine()` | Stops all track motors immediately (`0%` PWM) and aborts active sequence |

