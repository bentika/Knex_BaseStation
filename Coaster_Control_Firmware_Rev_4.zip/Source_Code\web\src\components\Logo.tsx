/**
 * Brand Logo: Precision Roller Coaster Mark
 * High-contrast, fail-safe SVG rendering across Light and Dark themes.
 * Uses solid primary branding with bold track loop and vibrant coaster car.
 */
export function Logo({ size = 36 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      style={{ flexShrink: 0, display: 'block' }}
    >
      {/* Vibrant Rounded Brand Tile */}
      <rect
        x="2"
        y="2"
        width="44"
        height="44"
        rx="11"
        fill="#0284c7"
      />

      {/* Subtle Inner Highlight Gradient / Ring */}
      <rect
        x="3"
        y="3"
        width="42"
        height="42"
        rx="10"
        stroke="#38bdf8"
        strokeWidth="1.2"
        strokeOpacity="0.4"
      />

      {/* Roller Coaster Loop Track (Thick, High-Contrast Pure White) */}
      <path
        d="M 8 36 C 14 36, 17 28, 20 20 C 23 12, 30 7, 34 13 C 38 19, 31 26, 25 24 C 19 22, 23 11, 31 12 C 36 13, 39 18, 41 27"
        stroke="#ffffff"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Track Cross-Ties (Visual Roller Coaster Cues) */}
      <line x1="16" y1="28" x2="19" y2="25" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.8" />
      <line x1="28" y1="10" x2="31" y2="13" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.8" />
      <line x1="33" y1="20" x2="36" y2="18" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.8" />

      {/* Coaster Train Car (Vibrant Amber / Gold with Headlight) */}
      <g transform="rotate(-24 22 15)">
        <rect
          x="18"
          y="12.5"
          width="8"
          height="5.5"
          rx="1.5"
          fill="#f59e0b"
          stroke="#ffffff"
          strokeWidth="1.2"
        />
        {/* Headlight */}
        <circle cx="25.5" cy="15.25" r="1" fill="#ffffff" />
      </g>

      {/* Station Track Terminal Anchor */}
      <circle cx="8" cy="36" r="3" fill="#ffffff" />
      <circle cx="8" cy="36" r="1.5" fill="#0284c7" />
    </svg>
  )
}
