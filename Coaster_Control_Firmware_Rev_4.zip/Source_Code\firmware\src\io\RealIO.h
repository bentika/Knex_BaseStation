#pragma once

#include "IOInterface.h"
#include "../pins.h"
#ifndef COASTER_FORCE_SIM
#include <driver/mcpwm_prelude.h>
#endif

#define MOTOR_PWM_FREQ_HZ           (20000U)
#define MOTOR_PWM_RES_BITS          (8U)
#define MOTOR_PWM_MAX_DUTY          (255)
#define MOTOR_PWM_MAX_PCT           (100)
#define PIN_UNUSED                  (255U)

#define SERVO_MCPWM_GROUP_ID        (0)
#define SERVO_MCPWM_OPERATORS       (3U)
#define SERVO_MCPWM_RES_HZ          (1000000UL)
#define SERVO_MCPWM_PERIOD_TICKS    (20000UL)
#define SERVO_PULSE_MIN_US          (500UL)
#define SERVO_PULSE_SPAN_US         (2000UL)
#define SERVO_ANGLE_MIN_DEG         (0)
#define SERVO_ANGLE_MAX_DEG         (180)

#define HALL_SIM_DEBOUNCE_MS        (250UL)
#define HALL_VISUAL_PULSE_MS        (350UL)
#define HALL_TRAIN_HOLD_PULSE_MS    (200UL)
#define HALL_BURST_SAMPLES          (5U)
#define HALL_BURST_DELAY_US         (7U)
#define HALL_BURST_QUORUM           (4U)
#define HALL_FILTER_LOW_TICKS       (5U)
#define HALL_FILTER_HIGH_TICKS      (10U)
#define IO_MAX_TICK_DELTA_MS        (200UL)

/**
 * @brief ESP32-S3 Hardware Implementation of `IOInterface`.
 *
 * - Motors 1..6: Driven via ESP32-S3 LEDC peripheral (20 kHz, 8-bit resolution).
 *   Motors 1 & 2 use 2 LEDC channels each (DRV8833 H-Bridge FWD/REV); Motors 3..6 use
 *   1 LEDC channel each (MOSFET switch/PWM), totaling 8 LEDC channels.
 * - Servos 1..6: Driven via ESP32-S3 MCPWM Group 0 hardware peripheral (3 operators,
 *   6 comparators/generators at 1 MHz / 50 Hz = 20,000 us period) so zero LEDC channels
 *   are consumed by servos.
 * - Hall Sensors 1..12: A3144 active-LOW inputs captured via `IRAM_ATTR` falling-edge
 *   GPIO ISRs (Fast In, Fast Out) and debounced in task context (`RealIO::update()`).
 */
class RealIO : public IOInterface {
public:
    RealIO();
    virtual ~RealIO() override = default;

    virtual void begin() override;
    virtual void update() override;

    virtual void setMotor(uint8_t id, int pwm, MotorDir dir = MotorDir::FWD, int rampMs = 0) override;
    virtual void stopMotor(uint8_t id) override;
    virtual void stopAllMotors() override;

    virtual void setServo(uint8_t id, int angle, int speed = 0) override;

    virtual MotorStatus getMotorStatus(uint8_t id) const override;
    virtual ServoStatus getServoStatus(uint8_t id) const override;

    virtual bool getHallActive(uint8_t id) const override;
    virtual uint32_t getHallCount(uint8_t id) const override;
    virtual void resetHallCounts() override;
    virtual void syncHallBaseline() override;
    virtual void simulateHall(uint8_t id) override;

    virtual void setEstop(bool active) override;
    virtual bool isEstop() const override { return _estop; }

    virtual void setSimMode(bool sim) override { _simMode = sim; }
    virtual bool isSimMode() const override { return _simMode; }

private:
    void applyMotorHardware(uint8_t idx);
    void applyServoHardware(uint8_t idx);

    bool _estop;
    bool _simMode;

    struct MotorInternal {
        float currentPwm;
        int32_t targetPwm;
        MotorDir currentDir;
        MotorDir targetDir;
        float rampStepPerMs;
        uint32_t lastUpdateMs;
    } _motors[NUM_MOTORS];

    struct ServoInternal {
        float currentAngle;
        int32_t targetAngle;
        int32_t speed;
        uint32_t lastUpdateMs;
    } _servos[NUM_SERVOS];

#ifndef COASTER_FORCE_SIM
    mcpwm_timer_handle_t _mcpwmTimer = nullptr;
    mcpwm_oper_handle_t _mcpwmOpers[SERVO_MCPWM_OPERATORS] = {nullptr, nullptr, nullptr};
    mcpwm_cmpr_handle_t _servoCmprs[NUM_SERVOS] = {nullptr};
    mcpwm_gen_handle_t _servoGens[NUM_SERVOS] = {nullptr};
#endif

    struct HallInternal {
        uint32_t count;
        uint32_t lastTriggerMs;
        uint32_t lockoutUntilMs;
        uint32_t activeUntilMs;
        uint8_t lowTickCount;
        uint8_t highTickCount;
        bool rawState;
        bool debouncedActive;
        bool wasActive;
    } _halls[NUM_HALLS];

    uint32_t _lastTickMs;
};
