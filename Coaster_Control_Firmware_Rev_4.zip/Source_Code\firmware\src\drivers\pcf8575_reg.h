#ifndef DRIVER_PCF8575_REG_H
#define DRIVER_PCF8575_REG_H

/**
 * @brief PCF8575 16-Bit I2C I/O Expander Hardware Constants & Register Definitions.
 */
#define PCF8575_DEFAULT_I2C_ADDR    (0x20U)
#define PCF8575_MIN_I2C_ADDR        (0x20U)
#define PCF8575_MAX_I2C_ADDR        (0x27U)
#define PCF8575_PORT_BYTE_COUNT     (2U)
#define PCF8575_NUM_PINS            (16U)
#define PCF8575_ALL_INPUT_MASK      (0xFFFFU)

#endif /* DRIVER_PCF8575_REG_H */

