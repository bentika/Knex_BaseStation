#include "RealIO.h"
#ifndef COASTER_FORCE_SIM
#include <driver/gpio.h>
#endif

#ifndef COASTER_FORCE_SIM
/**
 * @brief ISR-shared bitmask of Hall sensors (bits 0..11) that experienced a falling edge.
 *
 * Follows `embedded-isr-design` ("Fast In, Fast Out"):
 * - ISR executes in < 2 us in IRAM, sets bit in `s_isrHallEdgeMask`, and exits immediately.
 * - Zero `printf`, zero heap allocation, zero float math, and zero business logic in ISR.
 * - Deferred processing, PWM/EMI glitch rejection, and multi-magnet train debounce
 *   occur in task context (`RealIO::update()`).
 */
static portMUX_TYPE s_hallIsrMux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint16_t s_isrHallEdgeMask = 0U;

static void IRAM_ATTR hall_gpio_isr_handler(void* arg) {
    uint32_t hallIdx = (uint32_t)(uintptr_t)arg;
    if (hallIdx < (uint32_t)NUM_HALLS) {
        portENTER_CRITICAL_ISR(&s_hallIsrMux);
        s_isrHallEdgeMask |= (uint16_t)(1U << hallIdx);
        portEXIT_CRITICAL_ISR(&s_hallIsrMux);
    }
}

/**
 * @brief Sample all 12 Hall GPIO pins simultaneously across a 28 us burst
 *        (5 samples spaced by 7 us, spanning >50% of a 20 kHz / 50 us motor PWM period).
 *        Rejects capacitive crosstalk from adjacent motor PWM traces (such as GPIO 12
 *        M2_IN1 coupling onto GPIO 13 HALL_1) in only 28 us total for all 12 channels.
 */
static void sample_all_halls_low_counts(uint8_t lowCounts[NUM_HALLS]) {
    for (uint8_t i = 0U; i < NUM_HALLS; i++) {
        lowCounts[i] = 0U;
    }
    for (uint8_t s = 0U; s < HALL_BURST_SAMPLES; s++) {
        for (uint8_t i = 0U; i < NUM_HALLS; i++) {
#ifdef ENABLE_TEMP_SERIAL
            if (HALL_PINS[i] == 44U) continue;
#endif
            if (digitalRead(HALL_PINS[i]) == LOW) {
                lowCounts[i]++;
            }
        }
        if ((s + 1U) < HALL_BURST_SAMPLES) {
            delayMicroseconds(HALL_BURST_DELAY_US);
        }
    }
}
#endif

RealIO::RealIO()
    : _estop(false),
      _simMode(false),
      _lastTickMs(0U) {
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        _motors[i].currentPwm = 0.0f;
        _motors[i].targetPwm = 0;
        _motors[i].currentDir = MotorDir::FWD;
        _motors[i].targetDir = MotorDir::FWD;
        _motors[i].rampStepPerMs = 0.0f;
        _motors[i].lastUpdateMs = 0U;
    }

    for (uint8_t i = 0U; i < NUM_SERVOS; i++) {
        _servos[i].currentAngle = 0.0f;
        _servos[i].targetAngle = 0;
        _servos[i].speed = 0;
        _servos[i].lastUpdateMs = 0U;
    }

    for (uint8_t i = 0U; i < NUM_HALLS; i++) {
        _halls[i].count = 0U;
        _halls[i].lastTriggerMs = 0U;
        _halls[i].lockoutUntilMs = 0U;
        _halls[i].activeUntilMs = 0U;
        _halls[i].lowTickCount = 0U;
        _halls[i].highTickCount = HALL_FILTER_HIGH_TICKS;
        _halls[i].rawState = false;
        _halls[i].debouncedActive = false;
        _halls[i].wasActive = false;
    }
}

void RealIO::begin() {
#ifndef COASTER_FORCE_SIM
    // 1. Initialize Motors (LEDC channels 0..7 at 20 kHz, 8-bit resolution)
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        uint8_t pin1 = MOTOR_PINS[i][0];
        uint8_t pin2 = MOTOR_PINS[i][1];

        (void)ledcAttach(pin1, MOTOR_PWM_FREQ_HZ, MOTOR_PWM_RES_BITS);
        (void)ledcWrite(pin1, 0U);

        if (pin2 != PIN_UNUSED) {
            (void)ledcAttach(pin2, MOTOR_PWM_FREQ_HZ, MOTOR_PWM_RES_BITS);
            (void)ledcWrite(pin2, 0U);
        }
    }

    // 2. Initialize Servos (50 Hz / 20,000 us period, 500 - 2500 us pulse width)
    // Driven via ESP32-S3 MCPWM Group 0 hardware peripheral so all 8 LEDC channels
    // remain dedicated to the 6 Motor outputs (M1-M6) without channel exhaustion.
    mcpwm_timer_config_t timer_config = {};
    timer_config.group_id = SERVO_MCPWM_GROUP_ID;
    timer_config.clk_src = MCPWM_TIMER_CLK_SRC_DEFAULT;
    timer_config.resolution_hz = SERVO_MCPWM_RES_HZ;
    timer_config.count_mode = MCPWM_TIMER_COUNT_MODE_UP;
    timer_config.period_ticks = SERVO_MCPWM_PERIOD_TICKS;
    if (mcpwm_new_timer(&timer_config, &_mcpwmTimer) == ESP_OK) {
        for (uint8_t op = 0U; op < SERVO_MCPWM_OPERATORS; op++) {
            mcpwm_operator_config_t oper_config = {};
            oper_config.group_id = SERVO_MCPWM_GROUP_ID;
            if (mcpwm_new_operator(&oper_config, &_mcpwmOpers[op]) == ESP_OK) {
                (void)mcpwm_operator_connect_timer(_mcpwmOpers[op], _mcpwmTimer);
            }
        }

        for (uint8_t i = 0U; i < NUM_SERVOS; i++) {
#ifdef ENABLE_TEMP_SERIAL
            if (SERVO_PINS[i] == 43U) continue; // Keep GPIO 43 for UART0 TX in bench debug mode
#endif
            uint8_t opIdx = i / 2U;
            if (_mcpwmOpers[opIdx] == nullptr) continue;

            mcpwm_comparator_config_t cmpr_config = {};
            cmpr_config.flags.update_cmp_on_tez = true;
            if (mcpwm_new_comparator(_mcpwmOpers[opIdx], &cmpr_config, &_servoCmprs[i]) == ESP_OK) {
                (void)mcpwm_comparator_set_compare_value(_servoCmprs[i], SERVO_PULSE_MIN_US);
            }

            mcpwm_generator_config_t gen_config = {};
            gen_config.gen_gpio_num = SERVO_PINS[i];
            if (mcpwm_new_generator(_mcpwmOpers[opIdx], &gen_config, &_servoGens[i]) == ESP_OK && _servoCmprs[i] != nullptr) {
                (void)mcpwm_generator_set_action_on_timer_event(
                    _servoGens[i],
                    MCPWM_GEN_TIMER_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, MCPWM_TIMER_EVENT_EMPTY, MCPWM_GEN_ACTION_HIGH)
                );
                (void)mcpwm_generator_set_action_on_compare_event(
                    _servoGens[i],
                    MCPWM_GEN_COMPARE_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, _servoCmprs[i], MCPWM_GEN_ACTION_LOW)
                );
            }
        }

        (void)mcpwm_timer_enable(_mcpwmTimer);
        (void)mcpwm_timer_start_stop(_mcpwmTimer, MCPWM_TIMER_START_NO_STOP);
    }

    // 3. Initialize Hall Sensors (A3144 active-LOW) with internal pull-ups and FALLING-edge ISRs
    for (uint8_t i = 0U; i < NUM_HALLS; i++) {
#ifdef ENABLE_TEMP_SERIAL
        if (HALL_PINS[i] == 44U) continue; // Keep GPIO 44 for UART0 RX in bench debug mode
#endif
        pinMode(HALL_PINS[i], INPUT_PULLUP);
        (void)gpio_pullup_en((gpio_num_t)HALL_PINS[i]);
        (void)gpio_pulldown_dis((gpio_num_t)HALL_PINS[i]);
        attachInterruptArg(
            digitalPinToInterrupt(HALL_PINS[i]),
            hall_gpio_isr_handler,
            (void*)(uintptr_t)i,
            FALLING
        );
    }
    delay(10);
    syncHallBaseline();
#endif
    _lastTickMs = (uint32_t)millis();
}

void RealIO::setMotor(uint8_t id, int pwm, MotorDir dir, int rampMs) {
    if (id < 1U || id > NUM_MOTORS) return;
    uint8_t idx = id - 1U;

    if (_estop) return;

    int32_t clampedPwm = constrain((int32_t)pwm, 0, MOTOR_PWM_MAX_PCT);
    _motors[idx].targetPwm = clampedPwm;
    _motors[idx].targetDir = dir;

    if (rampMs > 0) {
        _motors[idx].rampStepPerMs = (float)MOTOR_PWM_MAX_PCT / (float)rampMs;
    } else {
        _motors[idx].rampStepPerMs = 0.0f;
        _motors[idx].currentPwm = (float)clampedPwm;
        _motors[idx].currentDir = dir;
    }

    applyMotorHardware(idx);
}

void RealIO::stopMotor(uint8_t id) {
    if (id < 1U || id > NUM_MOTORS) return;
    uint8_t idx = id - 1U;
    _motors[idx].targetPwm = 0;
    _motors[idx].currentPwm = 0.0f;
    applyMotorHardware(idx);
}

void RealIO::stopAllMotors() {
    for (uint8_t i = 1U; i <= NUM_MOTORS; i++) {
        stopMotor(i);
    }
}

void RealIO::setServo(uint8_t id, int angle, int speed) {
    if (id < 1U || id > NUM_SERVOS) return;
    uint8_t idx = id - 1U;

    int32_t clampedAngle = constrain((int32_t)angle, SERVO_ANGLE_MIN_DEG, SERVO_ANGLE_MAX_DEG);
    _servos[idx].targetAngle = clampedAngle;
    _servos[idx].speed = (int32_t)speed;

    if (speed <= 0) {
        _servos[idx].currentAngle = (float)clampedAngle;
        applyServoHardware(idx);
    }
}

void RealIO::applyMotorHardware(uint8_t idx) {
#ifndef COASTER_FORCE_SIM
    if (idx >= NUM_MOTORS) return;

    if (_simMode || _estop) {
        uint8_t pin1 = MOTOR_PINS[idx][0];
        uint8_t pin2 = MOTOR_PINS[idx][1];
        (void)ledcWrite(pin1, 0U);
        if (pin2 != PIN_UNUSED) {
            (void)ledcWrite(pin2, 0U);
        }
        return;
    }

    uint8_t pin1 = MOTOR_PINS[idx][0];
    uint8_t pin2 = MOTOR_PINS[idx][1];
    int32_t duty = (int32_t)((_motors[idx].currentPwm * (float)MOTOR_PWM_MAX_DUTY) / (float)MOTOR_PWM_MAX_PCT);
    duty = constrain(duty, 0, MOTOR_PWM_MAX_DUTY);

    if (pin2 != PIN_UNUSED) {
        // H-Bridge (Motors 1 & 2)
        if (duty == 0) {
            (void)ledcWrite(pin1, 0U);
            (void)ledcWrite(pin2, 0U);
        } else if (_motors[idx].currentDir == MotorDir::FWD) {
            (void)ledcWrite(pin2, 0U);
            (void)ledcWrite(pin1, (uint32_t)duty);
        } else {
            (void)ledcWrite(pin1, 0U);
            (void)ledcWrite(pin2, (uint32_t)duty);
        }
    } else {
        // FET (Motors 3 - 6)
        (void)ledcWrite(pin1, (uint32_t)duty);
    }
#endif
}

void RealIO::applyServoHardware(uint8_t idx) {
#ifndef COASTER_FORCE_SIM
    if (_simMode || idx >= NUM_SERVOS) return;
#ifdef ENABLE_TEMP_SERIAL
    if (SERVO_PINS[idx] == 43U) return; // Keep GPIO 43 for UART0 TX
#endif
    if (_servoCmprs[idx] != nullptr) {
        int32_t angle = constrain((int32_t)_servos[idx].currentAngle, SERVO_ANGLE_MIN_DEG, SERVO_ANGLE_MAX_DEG);
        uint32_t pulseUs = SERVO_PULSE_MIN_US + (((uint32_t)angle * SERVO_PULSE_SPAN_US) / (uint32_t)SERVO_ANGLE_MAX_DEG);
        (void)mcpwm_comparator_set_compare_value(_servoCmprs[idx], pulseUs);
    }
#endif
}

void RealIO::update() {
    uint32_t now = (uint32_t)millis();
    uint32_t delta = now - _lastTickMs;
    _lastTickMs = now;
    if (delta > IO_MAX_TICK_DELTA_MS) {
        delta = IO_MAX_TICK_DELTA_MS;
    }

    // 1. Update motor ramping
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        if (_motors[i].currentPwm != (float)_motors[i].targetPwm || _motors[i].currentDir != _motors[i].targetDir) {
            if (_motors[i].currentDir != _motors[i].targetDir) {
                // Ramp down to zero first before reversing H-bridge direction
                float step = (_motors[i].rampStepPerMs > 0.0f)
                                 ? (_motors[i].rampStepPerMs * (float)delta)
                                 : (float)MOTOR_PWM_MAX_PCT;
                _motors[i].currentPwm -= step;
                if (_motors[i].currentPwm <= 0.0f) {
                    _motors[i].currentPwm = 0.0f;
                    _motors[i].currentDir = _motors[i].targetDir;
                }
            } else {
                float step = (_motors[i].rampStepPerMs > 0.0f)
                                 ? (_motors[i].rampStepPerMs * (float)delta)
                                 : (float)MOTOR_PWM_MAX_PCT;
                if (_motors[i].currentPwm < (float)_motors[i].targetPwm) {
                    _motors[i].currentPwm += step;
                    if (_motors[i].currentPwm > (float)_motors[i].targetPwm) {
                        _motors[i].currentPwm = (float)_motors[i].targetPwm;
                    }
                } else {
                    _motors[i].currentPwm -= step;
                    if (_motors[i].currentPwm < (float)_motors[i].targetPwm) {
                        _motors[i].currentPwm = (float)_motors[i].targetPwm;
                    }
                }
            }
            applyMotorHardware(i);
        }
    }

    // 2. Update servo speed transitions
    for (uint8_t i = 0U; i < NUM_SERVOS; i++) {
        if (_servos[i].currentAngle != (float)_servos[i].targetAngle) {
            if (_servos[i].speed > 0) {
                float step = ((float)_servos[i].speed * (float)delta) / 1000.0f;
                if (_servos[i].currentAngle < (float)_servos[i].targetAngle) {
                    _servos[i].currentAngle += step;
                    if (_servos[i].currentAngle > (float)_servos[i].targetAngle) {
                        _servos[i].currentAngle = (float)_servos[i].targetAngle;
                    }
                } else {
                    _servos[i].currentAngle -= step;
                    if (_servos[i].currentAngle < (float)_servos[i].targetAngle) {
                        _servos[i].currentAngle = (float)_servos[i].targetAngle;
                    }
                }
            } else {
                _servos[i].currentAngle = (float)_servos[i].targetAngle;
            }
            applyServoHardware(i);
        }
    }

    // 3. Process Deferred Hall Sensor ISR Events, Digital EMI Glitch Filter & Multi-Magnet Debounce
#ifndef COASTER_FORCE_SIM
    uint16_t isrEdges = 0U;
    portENTER_CRITICAL(&s_hallIsrMux);
    isrEdges = s_isrHallEdgeMask;
    s_isrHallEdgeMask = 0U;
    portEXIT_CRITICAL(&s_hallIsrMux);
    (void)isrEdges;

    if (!_simMode) {
        uint8_t lowCounts[NUM_HALLS];
        sample_all_halls_low_counts(lowCounts);

        for (uint8_t i = 0U; i < NUM_HALLS; i++) {
#ifdef ENABLE_TEMP_SERIAL
            if (HALL_PINS[i] == 44U) continue; // Keep GPIO 44 for UART0 RX
#endif
            // Multi-sample burst across 28 us rejects 20 kHz motor PWM crosstalk on adjacent pins
            // (such as GPIO 12 M2_IN1 coupling onto GPIO 13 HALL_1) and connector contact bounce.
            uint8_t lowReads = lowCounts[i];
            bool solidLow = (lowReads >= HALL_BURST_QUORUM);
            bool solidHigh = ((HALL_BURST_SAMPLES - lowReads) >= HALL_BURST_QUORUM);

            if (solidLow) {
                _halls[i].highTickCount = 0U;
                if (_halls[i].lowTickCount < HALL_FILTER_LOW_TICKS) {
                    _halls[i].lowTickCount++;
                }
                if (_halls[i].lowTickCount >= HALL_FILTER_LOW_TICKS) {
                    _halls[i].debouncedActive = true;
                }
            } else if (solidHigh) {
                _halls[i].lowTickCount = 0U;
                if (_halls[i].highTickCount < HALL_FILTER_HIGH_TICKS) {
                    _halls[i].highTickCount++;
                }
                if (_halls[i].highTickCount >= HALL_FILTER_HIGH_TICKS) {
                    _halls[i].debouncedActive = false;
                }
            }

            bool isMagnetPresent = _halls[i].debouncedActive;
            _halls[i].rawState = isMagnetPresent;

            // True debounced leading-edge detection (strictly requires sustained HIGH -> sustained LOW)
            bool leadingEdge = (isMagnetPresent && !_halls[i].wasActive);
            _halls[i].wasActive = isMagnetPresent;

            if (isMagnetPresent) {
                // Check if we are outside the multi-magnet debounce lockout window
                if (leadingEdge && (now >= _halls[i].lockoutUntilMs)) {
                    // First magnet of train detected - valid primary trigger!
                    _halls[i].lastTriggerMs = now;
                    _halls[i].lockoutUntilMs = now + _hallDebounceMs;
                    _halls[i].count++;
                    _halls[i].activeUntilMs = now + HALL_VISUAL_PULSE_MS;
                    if (_hallCallback) {
                        _hallCallback(i + 1U);
                    }
                } else if (now < _halls[i].lockoutUntilMs) {
                    // Subsequent magnet (magnets 2..6) on the same train pass:
                    // Keep visual pulse alive while the train is physically crossing
                    _halls[i].activeUntilMs = now + HALL_TRAIN_HOLD_PULSE_MS;
                }
            }
        }
    }
#endif
}

MotorStatus RealIO::getMotorStatus(uint8_t id) const {
    if (id < 1U || id > NUM_MOTORS) return {0, 0, MotorDir::FWD, 0};
    uint8_t idx = id - 1U;
    return {
        (int32_t)_motors[idx].currentPwm,
        _motors[idx].targetPwm,
        _motors[idx].currentDir,
        0
    };
}

ServoStatus RealIO::getServoStatus(uint8_t id) const {
    if (id < 1U || id > NUM_SERVOS) return {0, 0, 0};
    uint8_t idx = id - 1U;
    return {
        (int32_t)_servos[idx].currentAngle,
        _servos[idx].targetAngle,
        _servos[idx].speed
    };
}

bool RealIO::getHallActive(uint8_t id) const {
    if (id < 1U || id > NUM_HALLS) return false;
    uint8_t idx = id - 1U;
    return ((uint32_t)millis() < _halls[idx].activeUntilMs) || _halls[idx].rawState;
}

uint32_t RealIO::getHallCount(uint8_t id) const {
    if (id < 1U || id > NUM_HALLS) return 0U;
    return _halls[id - 1U].count;
}

void RealIO::resetHallCounts() {
    for (uint8_t i = 0U; i < NUM_HALLS; i++) {
        _halls[i].count = 0U;
    }
}

void RealIO::syncHallBaseline() {
#ifndef COASTER_FORCE_SIM
    portENTER_CRITICAL(&s_hallIsrMux);
    s_isrHallEdgeMask = 0U;
    portEXIT_CRITICAL(&s_hallIsrMux);

    if (!_simMode) {
        uint8_t lowCounts[NUM_HALLS];
        sample_all_halls_low_counts(lowCounts);

        for (uint8_t i = 0U; i < NUM_HALLS; i++) {
#ifdef ENABLE_TEMP_SERIAL
            if (HALL_PINS[i] == 44U) continue;
#endif
            bool isLow = (lowCounts[i] >= HALL_BURST_QUORUM);
            _halls[i].rawState = isLow;
            _halls[i].debouncedActive = isLow;
            _halls[i].wasActive = isLow;
            _halls[i].lowTickCount = isLow ? HALL_FILTER_LOW_TICKS : 0U;
            _halls[i].highTickCount = isLow ? 0U : HALL_FILTER_HIGH_TICKS;
        }
    }
#endif
}

void RealIO::simulateHall(uint8_t id) {
    if (id < 1U || id > NUM_HALLS) return;
    uint8_t idx = id - 1U;
    uint32_t now = (uint32_t)millis();
    if (now >= _halls[idx].lockoutUntilMs) {
        _halls[idx].lastTriggerMs = now;
        _halls[idx].lockoutUntilMs = now + HALL_SIM_DEBOUNCE_MS;
        _halls[idx].count++;
        _halls[idx].activeUntilMs = now + HALL_VISUAL_PULSE_MS;
    }
}

void RealIO::setEstop(bool active) {
    _estop = active;
    if (_estop) {
        stopAllMotors();
    }
}
