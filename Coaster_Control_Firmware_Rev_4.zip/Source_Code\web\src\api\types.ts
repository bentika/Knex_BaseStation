/**
 * Shared protocol between the web app and the ESP32 firmware (API v1).
 * Keep this file in sync with firmware/src/net/protocol.md.
 */

export const MOTOR_COUNT = 6
export const SERVO_COUNT = 6
export const HALL_COUNT = 12

export type MotorDir = 'fwd' | 'rev'

/** Live state pushed by the board over WebSocket (~10 Hz + on change). */
export interface BoardState {
  /** Board uptime in ms when this frame was produced. */
  ms: number
  estop: boolean
  sim: boolean
  duelingMode?: boolean
  /** true = magnet present (sensor output LOW). */
  halls: boolean[]
  hallCounts: number[]
  motors: MotorState[]
  servos: ServoState[]
  runloop?: RunLoopStatus
  runloopA?: RunLoopStatus
  runloopB?: RunLoopStatus
  panel?: {
    detected: boolean
    raw: number
  }
}

export interface MotorState {
  /** Current output 0–100 % (after ramping). */
  pwm: number
  /** Requested output 0–100 %. */
  target: number
  dir: MotorDir
}

export interface ServoState {
  angle: number
  target: number
}

export type EventKind = 'hall' | 'motor' | 'servo' | 'system' | 'warn' | 'error'

export interface BoardEvent {
  id: number
  ms: number
  kind: EventKind
  msg: string
}

export interface HardwareInfo {
  motors: { id: number; name: string; reversible: boolean; driver: 'hbridge' | 'fet' }[]
  servos: { id: number; name: string; home: number }[]
  halls: { id: number; name: string; lockoutMs: number }[]
}

export interface BoardInfo {
  fw: string
  build: string
  chip: string
  sim: boolean
  /** Simulation forced by the build (e.g. classic ESP32 dev board). */
  simForced: boolean
  uptimeMs: number
  heapFree: number
  psramFree: number
  fsUsed: number
  fsTotal: number
  hostname: string
  wifi: {
    mode: WifiMode
    connected: boolean
    ssid: string
    ip: string
    rssi: number
    apActive: boolean
    apSsid: string
    apIp: string
  }
  hw: HardwareInfo
}

export type WifiMode = 'home' | 'coaster'

export interface WifiConfig {
  mode: WifiMode
  ssid: string
  /** Write-only. Empty string on read; send only when changing. */
  password?: string
  hasPassword?: boolean
  apSsid: string
  apPassword?: string
  hostname: string
  apAlwaysOn?: boolean
  connected?: boolean
  staIp?: string
  apIp?: string
  rssi?: number
}

export interface WifiNetwork {
  ssid: string
  rssi: number
  secure: boolean
}

export interface SystemConfig {
  sim: boolean
  duelingMode?: boolean
  hallDebounceMs?: number
}

/** Messages server -> client over /ws */
export type ServerMessage =
  | { t: 'state'; d: BoardState }
  | { t: 'event'; d: BoardEvent }
  | { t: 'events'; d: BoardEvent[] }

/** Commands client -> server over /ws (also accepted by POST /api/v1/cmd) */
export type Command =
  | { c: 'motor'; id: number; pwm: number; dir?: MotorDir; rampMs?: number }
  | { c: 'motorStop'; id: number }
  | { c: 'servo'; id: number; angle: number; speed?: number }
  | { c: 'simHall'; id: number }
  | { c: 'allStop' }
  | { c: 'estop' }
  | { c: 'reset' }
  | { c: 'resetCounts' }
  | { c: 'dispatch' }
  | { c: 'dispatchA' }
  | { c: 'dispatchB' }
  | { c: 'dispatchBoth' }
  | { c: 'startLoop' }
  | { c: 'stopLoop' }
  | { c: 'resetLoop' }
  | { c: 'startLoopA' }
  | { c: 'stopLoopA' }
  | { c: 'resetLoopA' }
  | { c: 'startLoopB' }
  | { c: 'stopLoopB' }
  | { c: 'resetLoopB' }
  | { c: 'testHall'; id: number }
  | { c: 'testHallA'; id: number }
  | { c: 'testHallB'; id: number }
  | { c: 'triggerWled'; target?: string; preset: number }

// --- Run Loop Definitions ---
export type ActionType = 'motor' | 'servo' | 'delay' | 'waitDispatch' | 'wled'

export interface StepAction {
  type: ActionType
  // Motor
  motor?: number // 1..6
  op?: 'start' | 'stop' | 'runTime' | 'set' | 'half' | 'full' | 'fullPause'
  pwm?: number // 0..100
  dir?: MotorDir
  durationMs?: number
  // Servo
  servo?: number // 1..6
  angle?: number // 0..180
  speed?: number
  pauseMs?: number
  // Wait Dispatch
  timeoutMs?: number
  // WLED
  target?: string
  preset?: number
}

export interface RunStep {
  delayMs?: number
  actions: StepAction[]
}

export interface HallProgram {
  id: number // 0 = Dispatch, 1..12 = Hall 1..12
  name: string
  enabled: boolean
  wledPreset: number
  lockoutMs: number
  // Block Zone Hold Point settings
  isBlockHold?: boolean
  blockMotorId?: number // 0 = auto/none, 1..6 = Motor channel
  blockMotorPwm?: number // 1..100%
  blockMotorDir?: MotorDir
  blockServoId?: number // 0 = none, 1..6 = Servo channel
  blockHoldAngle?: number // 0..180 deg when held
  blockReleaseAngle?: number // 0..180 deg when released
  steps: RunStep[]
}

export interface RunLoopConfig {
  trainCount?: 1 | 2
  halls: HallProgram[]
}

export interface TrainTrackerStatus {
  id: number // 1 or 2
  currentHall: number // Active Hall ID at start of current block zone
  nextHall: number // Next active Hall ID ahead of train
  held: boolean // True if stopped at currentHall waiting for next block zone to clear
}

export interface RunLoopStatus {
  running: boolean
  activeHall: number
  activeStep: number
  totalSteps: number
  waitingDispatch: boolean
  stepDurationMs: number
  elapsedStepMs: number
  trainCount?: 1 | 2
  trains?: TrainTrackerStatus[]
}

// --- WLED Definitions ---
export interface WledDevice {
  id: string
  name: string
  ip: string
  enabled: boolean
}

export interface WledConfig {
  devices: WledDevice[]
}

// --- Panel Definitions ---
export interface PanelPinConfig {
  pin: number
  action: string
  label: string
  pressed?: boolean
}

export interface PanelConfig {
  pins: PanelPinConfig[]
}

export interface PanelStatus {
  detected: boolean
  pins: PanelPinConfig[]
}

