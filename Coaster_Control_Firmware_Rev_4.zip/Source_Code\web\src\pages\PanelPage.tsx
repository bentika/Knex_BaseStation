import { useEffect, useState, useMemo } from 'react'
import {
  Sliders,
  Save,
  RefreshCw,
  Radio,
  AlertTriangle,
  Info,
} from 'lucide-react'
import { useBoard } from '../store/boardStore'
import { toast } from '../store/toastStore'
import type { PanelPinConfig } from '../api/types'
import styles from './PanelPage.module.css'

export const ACTION_OPTIONS = [
  { value: 'none', label: 'Unassigned (None)' },
  { value: 'dispatch', label: 'Dispatch Button' },
  { value: 'estop', label: 'Software Stop (I2C Emergency Stop)' },
  { value: 'reset', label: 'Reset Software Stop' },
  { value: 'startStopLoop', label: 'Run Loop Toggle (Start/Stop)' },
  { value: 'motorToggle_1', label: 'Motor 1 Toggle (ON / OFF)' },
  { value: 'motorToggle_2', label: 'Motor 2 Toggle (ON / OFF)' },
  { value: 'motorToggle_3', label: 'Motor 3 Toggle (ON / OFF)' },
  { value: 'motorToggle_4', label: 'Motor 4 Toggle (ON / OFF)' },
  { value: 'motorToggle_5', label: 'Motor 5 Toggle (ON / OFF)' },
  { value: 'motorToggle_6', label: 'Motor 6 Toggle (ON / OFF)' },
  { value: 'servoToggle_1', label: 'Servo 1 Toggle (0° / 180°)' },
  { value: 'servoToggle_2', label: 'Servo 2 Toggle (0° / 180°)' },
  { value: 'servoToggle_3', label: 'Servo 3 Toggle (0° / 180°)' },
  { value: 'servoToggle_4', label: 'Servo 4 Toggle (0° / 180°)' },
  { value: 'servoToggle_5', label: 'Servo 5 Toggle (0° / 180°)' },
  { value: 'servoToggle_6', label: 'Servo 6 Toggle (0° / 180°)' },
  { value: 'hall_1', label: 'Trigger Hall 1' },
  { value: 'hall_2', label: 'Trigger Hall 2' },
  { value: 'hall_3', label: 'Trigger Hall 3' },
  { value: 'hall_4', label: 'Trigger Hall 4' },
  { value: 'hall_5', label: 'Trigger Hall 5' },
  { value: 'hall_6', label: 'Trigger Hall 6' },
  { value: 'hall_7', label: 'Trigger Hall 7' },
  { value: 'hall_8', label: 'Trigger Hall 8' },
  { value: 'hall_9', label: 'Trigger Hall 9' },
  { value: 'hall_10', label: 'Trigger Hall 10' },
  { value: 'hall_11', label: 'Trigger Hall 11' },
  { value: 'hall_12', label: 'Trigger Hall 12' },
]

export function PanelPage() {
  const { link, state, send } = useBoard()

  const [pins, setPins] = useState<PanelPinConfig[]>([])
  const [initialPinsJson, setInitialPinsJson] = useState<string>('')
  const [detected, setDetected] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [pressedSim, setPressedSim] = useState<{ [pin: number]: boolean }>({})
  const [filterMode, setFilterMode] = useState<'all' | 'assigned'>(() => {
    if (typeof window !== 'undefined' && window.innerWidth <= 768) {
      return 'assigned'
    }
    return 'all'
  })

  // Emergency Stop Reassignment Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    open: boolean
    pinIdx: number
    newAction: string
  }>({ open: false, pinIdx: -1, newAction: '' })

  useEffect(() => {
    loadPanel()
  }, [])

  const loadPanel = async () => {
    try {
      setLoading(true)
      const data = await link.getPanel()
      setDetected(data.detected)
      const rawPins = data.pins || []
      // Normalize labels: if label is generic default "Panel Button N", set to empty so placeholder shows
      const normalizedPins = rawPins.map((p) => {
        const isDefaultLabel =
          !p.label ||
          p.label === `Panel Button ${p.pin + 1}` ||
          p.label === `Pin ${p.pin + 1}`
        return {
          ...p,
          label: isDefaultLabel ? '' : p.label,
        }
      })
      setPins(normalizedPins)
      setInitialPinsJson(JSON.stringify(normalizedPins))
    } catch {
      toast.error('Failed to load panel mappings')
    } finally {
      setLoading(false)
    }
  }

  // Detect dirty changes
  const isDirty = useMemo(() => {
    if (!initialPinsJson) return false
    return JSON.stringify(pins) !== initialPinsJson
  }, [pins, initialPinsJson])

  // Detect duplicate action assignments
  const duplicateActions = useMemo(() => {
    const counts: Record<string, number[]> = {}
    pins.forEach((p) => {
      if (p.action && p.action !== 'none') {
        counts[p.action] = counts[p.action] ? [...counts[p.action], p.pin] : [p.pin]
      }
    })
    return Object.entries(counts)
      .filter(([_, pinList]) => pinList.length > 1)
      .map(([action, pinList]) => ({
        action,
        label: ACTION_OPTIONS.find((o) => o.value === action)?.label || action,
        pins: pinList,
      }))
  }, [pins])

  const handleSave = async () => {
    try {
      setSaving(true)
      // Restore default label for unassigned or empty pins before saving
      const payloadPins = pins.map((p) => ({
        ...p,
        label: p.label.trim() || `Panel Button ${p.pin + 1}`,
      }))
      await link.savePanel({ pins: payloadPins })
      setInitialPinsJson(JSON.stringify(pins))
      toast.success('Control panel mappings saved to LittleFS')
    } catch {
      toast.error('Failed to save panel mappings')
    } finally {
      setSaving(false)
    }
  }

  const handleActionChange = (pinIdx: number, newAction: string) => {
    const currentAction = pins[pinIdx]?.action
    // If altering an existing E-Stop pin or setting to E-Stop, prompt confirmation
    if (currentAction === 'estop' || newAction === 'estop') {
      setConfirmModal({
        open: true,
        pinIdx,
        newAction,
      })
      return
    }

    applyActionChange(pinIdx, newAction)
  }

  const applyActionChange = (pinIdx: number, newAction: string) => {
    setPins((prev) =>
      prev.map((p, idx) => (idx === pinIdx ? { ...p, action: newAction } : p))
    )
  }

  const handleLabelChange = (pinIdx: number, label: string) => {
    setPins((prev) =>
      prev.map((p, idx) => (idx === pinIdx ? { ...p, label } : p))
    )
  }

  // Determine if pin is pressed (from live raw bits or local simulation)
  const isPinLow = (pinIdx: number) => {
    if (pressedSim[pinIdx]) return true
    if (state?.panel && typeof state.panel.raw === 'number') {
      return (state.panel.raw & (1 << pinIdx)) === 0
    }
    return false
  }

  // Interactive Press / Hold Handlers
  const handlePressStart = (pin: PanelPinConfig) => {
    setPressedSim((prev) => ({ ...prev, [pin.pin]: true }))

    // Execute mapped action
    if (pin.action === 'dispatch') {
      send({ c: 'dispatch' })
      toast.info('Panel: Dispatch triggered')
    } else if (pin.action === 'estop') {
      send({ c: 'estop' })
      toast.error('Panel: Software Stop (E-Stop) triggered')
    } else if (pin.action === 'reset') {
      send({ c: 'reset' })
      toast.success('Panel: Software Stop reset')
    } else if (pin.action === 'startStopLoop') {
      send({ c: 'startLoop' })
      toast.info('Panel: Sequencer loop toggle')
    } else if (pin.action.startsWith('hall_')) {
      const h = parseInt(pin.action.substring(5), 10)
      send({ c: 'testHall', id: h })
    } else if (pin.action.startsWith('motorToggle_')) {
      const mId = parseInt(pin.action.substring(12), 10)
      const mState = state?.motors?.[mId - 1]
      if (mState && (mState.pwm > 0 || mState.target > 0)) {
        send({ c: 'motorStop', id: mId })
        toast.info(`Panel: Motor ${mId} toggled OFF`)
      } else {
        send({ c: 'motor', id: mId, pwm: 100, dir: 'fwd' })
        toast.info(`Panel: Motor ${mId} toggled ON (100%)`)
      }
    } else if (pin.action.startsWith('servoToggle_')) {
      const sId = parseInt(pin.action.substring(12), 10)
      const sState = state?.servos?.[sId - 1]
      const nextAngle = sState && sState.target > 90 ? 0 : 180
      send({ c: 'servo', id: sId, angle: nextAngle, speed: 100 })
      toast.info(`Panel: Servo ${sId} toggled to ${nextAngle}°`)
    }
  }

  const handlePressEnd = (pin: PanelPinConfig) => {
    setPressedSim((prev) => ({ ...prev, [pin.pin]: false }))
  }

  // Live Hardware Connection Status
  const isHardwareOnline = state?.panel ? state.panel.detected : detected

  // Filter Pins
  const displayedPins = useMemo(() => {
    if (filterMode === 'assigned') {
      return pins.filter((p) => p.action && p.action !== 'none')
    }
    return pins
  }, [pins, filterMode])

  const assignedCount = useMemo(() => {
    return pins.filter((p) => p.action && p.action !== 'none').length
  }, [pins])

  // Split into 2 columns for Desktop
  const col1Pins = displayedPins.filter((p) => p.pin < 8)
  const col2Pins = displayedPins.filter((p) => p.pin >= 8)

  const renderPinRow = (pin: PanelPinConfig) => {
    const pressed = isPinLow(pin.pin)
    const isAssigned = pin.action && pin.action !== 'none'
    const isEstop = pin.action === 'estop'
    const hasDuplicate = duplicateActions.some((d) => d.action === pin.action)

    return (
      <div
        key={pin.pin}
        className={`${styles.pinRow} ${
          isEstop
            ? styles.rowEstop
            : isAssigned
            ? styles.rowAssigned
            : styles.rowUnassigned
        } ${pressed ? styles.rowPressed : ''}`}
      >
        {/* Live Hardware LED Dot */}
        <div className={styles.ledCell} title={pressed ? 'Physical Pin LOW (Ground closed)' : 'Physical Pin HIGH (Open)'}>
          <div className={`${styles.pinLed} ${pressed ? styles.pinLedActive : ''}`} />
        </div>

        {/* Pin Badge */}
        <span className={`${styles.pinBadge} ${isAssigned ? styles.pinBadgeActive : ''}`}>
          P{pin.pin}
        </span>

        {/* Inline Name Input */}
        <div className={styles.inputCell}>
          <input
            className={styles.nameInput}
            value={pin.label}
            placeholder={`Panel Button ${pin.pin + 1}`}
            onChange={(e) => handleLabelChange(pin.pin, e.target.value)}
            aria-label={`Label for Pin ${pin.pin}`}
          />
        </div>

        {/* Action Select Dropdown */}
        <div className={styles.selectCell}>
          <select
            className={`${styles.actionSelect} ${
              hasDuplicate ? styles.actionSelectDuplicate : ''
            }`}
            value={pin.action}
            onChange={(e) => handleActionChange(pin.pin, e.target.value)}
            aria-label={`Action for Pin ${pin.pin}`}
          >
            {ACTION_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        {/* Simulate Press / Hold Button */}
        <div className={styles.actionBtnCell}>
          <button
            type="button"
            className={`${styles.pressBtn} ${
              isEstop
                ? styles.pressBtnDanger
                : pressed
                ? styles.pressBtnActive
                : ''
            }`}
            onPointerDown={() => handlePressStart(pin)}
            onPointerUp={() => handlePressEnd(pin)}
            onPointerLeave={() => handlePressEnd(pin)}
            title="Press and hold to test hardware logic"
            aria-label={`Simulate press for Pin ${pin.pin}`}
          >
            <Radio size={14} />
            <span className={styles.pressBtnLabel}>{isEstop ? 'Soft Stop' : pressed ? 'LOW' : 'Press'}</span>
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className={styles.page}>
      {/* ---------------- Top Hero Command Center ---------------- */}
      <div className={styles.headerCard}>
        <div className={styles.headerContent}>
          <div className={styles.headerTitleGroup}>
            <div className={styles.headerIcon}>
              <Sliders size={24} />
            </div>
            <div>
              <h1 className={styles.title}>Physical Control Panel (I2C)</h1>
              <p className={styles.subtitle}>
                16-Bit expander PCF8575 at address 0x20. Active-low debounced inputs with live state detection.
              </p>
            </div>
          </div>

          <div className={styles.headerActions}>
            {/* Real Hardware Detection Pill */}
            <div
              className={`${styles.statusBadge} ${
                isHardwareOnline ? styles.statusDetected : styles.statusSim
              }`}
            >
              {isHardwareOnline ? (
                <>
                  <span className={styles.statusDotGreen} />
                  <span>PCF8575 Hardware Online (0x20 ACK)</span>
                </>
              ) : (
                <>
                  <span className={styles.statusDotRed} />
                  <span>Hardware Offline (No 0x20 ACK · Sim)</span>
                </>
              )}
            </div>

            {/* Unsaved Changes Indicator */}
            {isDirty && (
              <span className={styles.unsavedBadge}>
                <span className={styles.unsavedDot} />
                Unsaved changes
              </span>
            )}

            <button
              type="button"
              className={styles.toolbarBtn}
              onClick={loadPanel}
              disabled={loading}
              title="Reload configuration from board"
            >
              <RefreshCw size={15} />
              <span>Reload</span>
            </button>

            <button
              type="button"
              className={`${styles.toolbarBtn} ${isDirty ? styles.saveBtnActive : styles.saveBtnDisabled}`}
              onClick={handleSave}
              disabled={!isDirty || saving}
              title={isDirty ? 'Persist control panel mappings to LittleFS' : 'No configuration changes to save'}
              aria-label={isDirty ? 'Save Mappings' : 'No changes to save'}
            >
              <Save size={15} />
              <span>{saving ? 'Saving...' : isDirty ? 'Save Mappings' : 'No changes to save'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ---------------- Duplicate Action Warning Banner ---------------- */}
      {duplicateActions.length > 0 && (
        <div className={styles.duplicateBanner}>
          <AlertTriangle className={styles.duplicateBannerIcon} />
          <div>
            <strong>Duplicate Action Warning:</strong>{' '}
            {duplicateActions.map((d, i) => (
              <span key={d.action}>
                "{d.label}" is assigned to {d.pins.map((p) => `P${p}`).join(' and ')}
                {i < duplicateActions.length - 1 ? '; ' : '.'}
              </span>
            ))}{' '}
            Both physical buttons will trigger identical behavior.
          </div>
        </div>
      )}

      {/* ---------------- Safety Advisory Note ---------------- */}
      <div className={styles.safetyBanner}>
        <Info className={styles.safetyBannerIcon} size={16} />
        <div>
          <strong>Safety Advisory (Software Stop vs Hardware E-Stop):</strong> Control panel inputs are polled via
          I2C expander. The "Software Stop" action notifies firmware to de-energize PWM outputs. For certified amusement ride
          emergency protection, wire a physical normally-closed contact in series with the motor power feed independent of the MCU.
        </div>
      </div>

      {/* ---------------- Filters & Statistics ---------------- */}
      <div className={styles.filterRow}>
        <div className={styles.filterTabs}>
          <button
            type="button"
            className={`${styles.filterTab} ${filterMode === 'all' ? styles.filterTabActive : ''}`}
            onClick={() => setFilterMode('all')}
          >
            All Pins (16)
          </button>
          <button
            type="button"
            className={`${styles.filterTab} ${filterMode === 'assigned' ? styles.filterTabActive : ''}`}
            onClick={() => setFilterMode('assigned')}
          >
            Assigned Only ({assignedCount})
          </button>
        </div>
        <span className={styles.filterStats}>
          {assignedCount} of 16 pins configured · Hold "Press" to test active-low ground logic
        </span>
      </div>

      {/* ---------------- High-Density 2-Column Desktop Grid ---------------- */}
      <div className={styles.tableColumns}>
        {/* Column 1: Pins 0 to 7 */}
        <div className={styles.columnCard}>
          <div className={styles.columnHeader}>
            <span className={styles.columnHeaderTitle}>Port 0 (Pins P0–P7)</span>
            <span className={styles.columnHeaderSub}>I2C Register Low Byte</span>
          </div>
          <div className={styles.pinRowsList}>
            {loading ? (
              <p style={{ padding: '16px', color: 'var(--text-3)' }}>Loading pins...</p>
            ) : col1Pins.length === 0 ? (
              <p style={{ padding: '16px', color: 'var(--text-3)', fontSize: '13px' }}>
                No assigned pins in Port 0.
              </p>
            ) : (
              col1Pins.map((pin) => renderPinRow(pin))
            )}
          </div>
        </div>

        {/* Column 2: Pins 8 to 15 */}
        <div className={styles.columnCard}>
          <div className={styles.columnHeader}>
            <span className={styles.columnHeaderTitle}>Port 1 (Pins P8–P15)</span>
            <span className={styles.columnHeaderSub}>I2C Register High Byte</span>
          </div>
          <div className={styles.pinRowsList}>
            {loading ? (
              <p style={{ padding: '16px', color: 'var(--text-3)' }}>Loading pins...</p>
            ) : col2Pins.length === 0 ? (
              <p style={{ padding: '16px', color: 'var(--text-3)', fontSize: '13px' }}>
                No assigned pins in Port 1.
              </p>
            ) : (
              col2Pins.map((pin) => renderPinRow(pin))
            )}
          </div>
        </div>
      </div>

      {/* ---------------- Mobile Unassigned Bar & Toggle ---------------- */}
      {filterMode === 'assigned' && pins.length > assignedCount && (
        <div className={styles.unassignedMobileBar}>
          <button
            type="button"
            className={styles.unassignedMobileBtn}
            onClick={() => setFilterMode('all')}
          >
            <span>+ Show {pins.length - assignedCount} Unassigned Pins</span>
          </button>
        </div>
      )}

      {/* ---------------- Emergency Stop Reassignment Confirmation Modal ---------------- */}
      {confirmModal.open && (
        <div className={styles.modalOverlay} onClick={() => setConfirmModal({ open: false, pinIdx: -1, newAction: '' })}>
          <div className={styles.modalCard} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <AlertTriangle color="#ef4444" size={20} />
              <h3 className={styles.modalTitle}>Confirm Software Stop Modification</h3>
            </div>
            <div className={styles.modalBody}>
              {confirmModal.newAction === 'estop' ? (
                <p>
                  You are assigning Pin P{confirmModal.pinIdx} as the <strong>Software Stop</strong>. Pressing this physical
                  button will trigger an emergency software shutdown across all motors.
                </p>
              ) : (
                <p>
                  Pin P{confirmModal.pinIdx} is currently mapped as the <strong>Software Stop</strong>. Are you sure you want to
                  reassign it to <em>"{ACTION_OPTIONS.find((o) => o.value === confirmModal.newAction)?.label}"</em>?
                </p>
              )}
            </div>
            <div className={styles.modalFoot}>
              <button
                type="button"
                className={styles.toolbarBtn}
                onClick={() => setConfirmModal({ open: false, pinIdx: -1, newAction: '' })}
              >
                Cancel
              </button>
              <button
                type="button"
                className={`${styles.toolbarBtn} ${styles.saveBtnActive}`}
                onClick={() => {
                  applyActionChange(confirmModal.pinIdx, confirmModal.newAction)
                  setConfirmModal({ open: false, pinIdx: -1, newAction: '' })
                  toast.info('Software stop mapping updated')
                }}
              >
                Confirm Modification
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
