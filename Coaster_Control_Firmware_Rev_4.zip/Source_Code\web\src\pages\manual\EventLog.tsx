import { useRef, useEffect } from 'react'
import { Terminal, Trash2 } from 'lucide-react'
import type { BoardEvent, EventKind } from '../../api/types'
import styles from './EventLog.module.css'

interface Props {
  events: BoardEvent[]
  onClear: () => void
}

const KIND_COLORS: Record<EventKind, { bg: string; text: string; border: string }> = {
  hall: { bg: 'rgba(16, 185, 129, 0.15)', text: '#65f2b5', border: 'rgba(16, 185, 129, 0.4)' },
  motor: { bg: 'rgba(0, 240, 255, 0.15)', text: '#00f0ff', border: 'rgba(0, 240, 255, 0.4)' },
  servo: { bg: 'rgba(168, 85, 247, 0.15)', text: '#ddb7ff', border: 'rgba(168, 85, 247, 0.4)' },
  system: { bg: 'rgba(38, 42, 52, 0.8)', text: '#7df4ff', border: 'rgba(255, 255, 255, 0.1)' },
  warn: { bg: 'rgba(245, 158, 11, 0.15)', text: '#f59e0b', border: 'rgba(245, 158, 11, 0.4)' },
  error: { bg: 'rgba(239, 68, 68, 0.2)', text: '#ffb4ab', border: 'rgba(239, 68, 68, 0.5)' },
}

export function EventLog({ events, onClear }: Props) {
  const logBoxRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (logBoxRef.current) {
      logBoxRef.current.scrollTop = logBoxRef.current.scrollHeight
    }
  }, [events.length])

  return (
    <div className={styles.container}>
      <div className={styles.toolbar}>
        <div className={styles.terminalTitleGroup}>
          <Terminal className={styles.terminalIcon} />
          <span className={styles.terminalLabel}>REAL-TIME EVENT BUS</span>
          <span className={styles.pulseLive}>
            <span className={styles.pingDot} />
            <span className={styles.coreDot} />
          </span>
        </div>

        <div className={styles.toolbarRight}>
          <span className={`${styles.count} mono`}>{events.length} events logged</span>
          <button type="button" className={styles.clearBtn} onClick={onClear}>
            <Trash2 className={styles.clearIcon} />
            <span>Clear Log</span>
          </button>
        </div>
      </div>

      <div ref={logBoxRef} className={styles.terminalScreen}>
        {events.length === 0 ? (
          <div className={styles.empty}>
            <span className={styles.emptyIcon}>_</span>
            <span>Awaiting hardware interrupts, PWM actuations, or Hall sensor triggers...</span>
          </div>
        ) : (
          events.map((e) => {
            const sec = (e.ms / 1000).toFixed(2)
            const style = KIND_COLORS[e.kind] || KIND_COLORS.system
            return (
              <div key={e.id} className={styles.line}>
                <span className={`${styles.time} mono`}>+{sec}s</span>
                <span
                  className={styles.kind}
                  style={{ backgroundColor: style.bg, color: style.text, borderColor: style.border }}
                >
                  {e.kind.toUpperCase()}
                </span>
                <span className={styles.msg}>{e.msg}</span>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
