import { AlertCircle, AlertTriangle, CheckCircle2, Info, X } from 'lucide-react'
import { useToasts, type ToastTone } from '../store/toastStore'
import styles from './Toasts.module.css'

const ICONS: Record<ToastTone, React.ReactNode> = {
  info: <Info />,
  success: <CheckCircle2 />,
  warn: <AlertTriangle />,
  error: <AlertCircle />,
}

export function Toasts() {
  const toasts = useToasts((s) => s.toasts)
  const dismiss = useToasts((s) => s.dismiss)

  if (toasts.length === 0) return null

  return (
    <div className={styles.container} aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`${styles.toast} ${styles[t.tone]}`}>
          <span className={styles.icon}>{ICONS[t.tone]}</span>
          <div className={styles.content}>
            <div className={styles.title}>{t.title}</div>
            {t.body && <div className={styles.body}>{t.body}</div>}
          </div>
          {t.action && (
            <button
              type="button"
              className={styles.actionBtn}
              onClick={() => {
                t.action?.onClick()
                dismiss(t.id)
              }}
            >
              {t.action.label}
            </button>
          )}
          <button
            type="button"
            className={styles.close}
            onClick={() => dismiss(t.id)}
            aria-label="Dismiss toast"
          >
            <X />
          </button>
        </div>
      ))}
    </div>
  )
}
