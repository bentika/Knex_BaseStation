import { Activity, Wifi } from 'lucide-react'
import { useBoard } from '../store/boardStore'
import styles from './StatusPill.module.css'

export function StatusPill({ detailed }: { detailed?: boolean }) {
  const status = useBoard((s) => s.status)
  const isSim = useBoard((s) => s.state?.sim ?? false)
  const linkKind = useBoard((s) => s.link.kind)
  const info = useBoard((s) => s.info)
  const isProcessing = useBoard((s) => s.isProcessing)

  const isOnline = status === 'online'
  const isConnecting = status === 'connecting'

  return (
    <div className={`${styles.pill} ${detailed ? styles.detailed : ''}`}>
      <div className={styles.statusRow}>
        <span
          className={`${styles.dot} ${
            isOnline ? (isProcessing ? styles.processing : styles.online) : isConnecting ? styles.connecting : styles.offline
          }`}
        />
        <span className={styles.text}>
          {isOnline
            ? isProcessing
              ? 'SYNCING...'
              : isSim || linkKind === 'mock'
              ? 'SIMULATOR'
              : 'ONLINE'
            : isConnecting
            ? 'CONNECTING'
            : 'OFFLINE'}
        </span>
        {isOnline && (
          <span className={styles.icon}>
            {info?.wifi.connected ? <Wifi className={styles.wifiIcon} /> : <Activity className={styles.wifiIcon} />}
          </span>
        )}
      </div>

      {detailed && isOnline && info && (
        <div className={styles.details}>
          <div className={styles.metaRow}>
            <span className={styles.metaLabel}>Host:</span>
            <span className="mono">{info.hostname}.local</span>
          </div>
          <div className={styles.metaRow}>
            <span className={styles.metaLabel}>IP:</span>
            <span className="mono">{info.wifi.ip || info.wifi.apIp}</span>
          </div>
          <div className={styles.metaRow}>
            <span className={styles.metaLabel}>Chip:</span>
            <span>{info.chip}</span>
          </div>
        </div>
      )}
    </div>
  )
}
