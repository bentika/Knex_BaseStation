# Hardware Resource & Pin Mapping (Rev 3 PCB)

## Target MCU

- **Module**: ESP32-S3-WROOM-1 / ESP32-S3-DevKitC-1 **N16R8**
- **CPU**: Dual-Core Xtensa 32-bit LX7 @ 240 MHz
- **Memory**: 512 KB SRAM + 16 MB Quad-SPI Flash + 8 MB Octal-SPI PSRAM (`qio_opi`)
- **USB Note**: `GPIO 19` and `GPIO 20` (ESP32-S3 native USB D-/D+) are wired to the **Motor 1 DRV8833 H-Bridge** on the Rev 3 PCB. The firmware compiles with `-DARDUINO_USB_CDC_ON_BOOT=0` and `-DARDUINO_USB_MODE=0` so `GPIO 19` and `GPIO 20` operate purely as LEDC PWM outputs.

---

## Peripheral Allocation Summary

| Subsystem | ESP32-S3 Peripheral | Channels / Units Used | Frequency / Resolution |
|---|---|---|---|
| Motors 1 & 2 (H-Bridge) | LEDC PWM | 4 channels (`0..3`) | 20 kHz, 8-bit (`0..255`) |
| Motors 3 – 6 (MOSFET) | LEDC PWM | 4 channels (`4..7`) | 20 kHz, 8-bit (`0..255`) |
| Servos 1 – 6 | MCPWM Group 0 | 1 Timer, 3 Operators, 6 Comparators, 6 Generators | 1 MHz tick (`1 µs`), 50 Hz period (`20,000 µs`) |
| Halls 1 – 12 | GPIO Matrix + IO MUX ISR | 12 Inputs (`INPUT_PULLUP`, `FALLING` ISR) | `< 2 µs` `IRAM_ATTR` edge capture |
| Control Panel Expander | I2C0 (`Wire`) | 1 Bus (`0x20` PCF8575) | 100 kHz Standard Mode, polled @ 50 Hz |

> [!IMPORTANT]
> **Why Servos Use MCPWM Group 0 Instead of LEDC**:
> The ESP32-S3 hardware has a total of **8 LEDC channels** (`SOC_LEDC_CHANNEL_NUM = 8`). Because Motors 1 & 2 use 4 LEDC channels (2 pins each) and Motors 3–6 use 4 LEDC channels (1 pin each), all 8 LEDC channels are occupied by the 6 motor outputs. Driving Servos 1–6 via **MCPWM Group 0** (`<driver/mcpwm_prelude.h>`) gives all 6 servos dedicated hardware pulse generators with zero LEDC channel conflict.

---

## Complete Pinout Table (`firmware/src/pins.h`)

### 1. Motor Outputs (`NUM_MOTORS = 6`)

| Channel | PCB Label | ESP32-S3 GPIO | Hardware Driver | Capabilities |
|---|---|---|---|---|
| **Motor 1** | `M1_IN1` / `M1_IN2` | `GPIO 19` / `GPIO 20` | DRV8833 Dual H-Bridge | Forward, Reverse, Soft Ramp, 0–100% PWM (Default 100%) |
| **Motor 2** | `M2_IN1` / `M2_IN2` | `GPIO 12` / `GPIO 11` | DRV8833 Dual H-Bridge | Forward, Reverse, Soft Ramp, 0–100% PWM (Default 100%) |
| **Motor 3** | `M3_PWM` | `GPIO 10` | Low-Side MOSFET | Forward / Switch, Soft Ramp, 0–100% PWM (Default 100%) |
| **Motor 4** | `M4_PWM` | `GPIO 38` | Low-Side MOSFET | Forward / Switch, Soft Ramp, 0–100% PWM (Default 100%) |
| **Motor 5** | `M5_PWM` | `GPIO 18` | Low-Side MOSFET | Forward / Switch, Soft Ramp, 0–100% PWM (Default 100%) |
| **Motor 6** | `M6_PWM` | `GPIO 39` | Low-Side MOSFET | Forward / Switch, Soft Ramp, 0–100% PWM (Default 100%) |

### 2. RC Servo Outputs (`NUM_SERVOS = 6`)

| Channel | PCB Label | ESP32-S3 GPIO | MCPWM Operator / Generator | Pulse Width (`0°–180°`) |
|---|---|---|---|---|
| **Servo 1** | `SERVO_1` | `GPIO 4` | Group 0, Operator 0, Gen A | `500 – 2500 µs` @ 50 Hz |
| **Servo 2** | `SERVO_2` | `GPIO 5` | Group 0, Operator 0, Gen B | `500 – 2500 µs` @ 50 Hz |
| **Servo 3** | `SERVO_3` | `GPIO 6` | Group 0, Operator 1, Gen A | `500 – 2500 µs` @ 50 Hz |
| **Servo 4** | `SERVO_4` | `GPIO 7` | Group 0, Operator 1, Gen B | `500 – 2500 µs` @ 50 Hz |
| **Servo 5** | `SERVO_5` | `GPIO 43` *(UART0 TX in bench mode)* | Group 0, Operator 2, Gen A | `500 – 2500 µs` @ 50 Hz |
| **Servo 6** | `SERVO_6` | `GPIO 15` | Group 0, Operator 2, Gen B | `500 – 2500 µs` @ 50 Hz |

### 3. Hall Effect Sensor Inputs (`NUM_HALLS = 12`)

| Sensor | Default Label | ESP32-S3 GPIO | Sensor Type | Trigger Polarity |
|---|---|---|---|---|
| **Hall 1** | `Hall 1` | `GPIO 13` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 2** | `Hall 2` | `GPIO 47` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 3** | `Hall 3` | `GPIO 41` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 4** | `Hall 4` | `GPIO 2` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 5** | `Hall 5` | `GPIO 1` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 6** | `Hall 6` | `GPIO 44` *(UART0 RX in bench mode)* | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 7** | `Hall 7` | `GPIO 14` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 8** | `Hall 8` | `GPIO 21` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 9** | `Hall 9` | `GPIO 40` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 10** | `Hall 10` | `GPIO 42` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 11** | `Hall 11` | `GPIO 17` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |
| **Hall 12** | `Hall 12` | `GPIO 16` | A3144 Hall Switch | Active LOW (`FALLING` ISR + pull-up) |

### 4. I2C Control Panel Expander (`PCF8575`)

| Signal | ESP32-S3 GPIO | Target Device | Details |
|---|---|---|---|
| **I2C SDA** | `GPIO 8` | PCF8575 (`0x20`) | 100 kHz I2C data line |
| **I2C SCL** | `GPIO 9` | PCF8575 (`0x20`) | 100 kHz I2C clock line |

