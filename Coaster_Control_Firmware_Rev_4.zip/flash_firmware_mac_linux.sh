#!/usr/bin/env bash
# K'nex Roller Coaster Base Station - Flash Installer for macOS & Linux

set -e

echo "====================================================================="
echo "   K'NEX ROLLER COASTER BASE STATION - ONE-CLICK INSTALLER (UNIX)"
echo "   ESP32-S3 (16 MB Flash, Dual DRV8833, 4x FET, 12x Hall, 6x Servos)"
echo "====================================================================="
echo ""

# Find esptool
ESPTOOL_CMD=""
if command -v esptool.py &> /dev/null; then
    ESPTOOL_CMD="esptool.py"
elif command -v esptool &> /dev/null; then
    ESPTOOL_CMD="esptool"
elif command -v python3 &> /dev/null; then
    if python3 -m esptool version &> /dev/null; then
        ESPTOOL_CMD="python3 -m esptool"
    else
        echo "Installing esptool via pip..."
        python3 -m pip install esptool
        ESPTOOL_CMD="python3 -m esptool"
    fi
else
    echo "[ERROR] Python 3 / esptool not found. Please install python3 and pip install esptool."
    exit 1
fi

echo "[OK] Using tool: $ESPTOOL_CMD"
echo ""

# Prompt for port
read -p "Enter ESP32-S3 serial port (e.g. /dev/ttyUSB0 or /dev/cu.usbmodem*): " PORT
if [ -z "$PORT" ]; then
    echo "[ERROR] No port provided."
    exit 1
fi

echo ""
echo "[1/2] Writing Factory Firmware (0x0)..."
$ESPTOOL_CMD --chip esp32s3 --port "$PORT" --baud 921600 write-flash 0x0 Binaries/firmware.factory.bin

echo ""
echo "[2/2] Writing Web Dashboard LittleFS Storage (0xC90000)..."
$ESPTOOL_CMD --chip esp32s3 --port "$PORT" --baud 921600 write-flash 0xC90000 Binaries/littlefs.bin

echo ""
echo "====================================================================="
echo "   SUCCESS! Base Station firmware & Web UI installed successfully!"
echo "====================================================================="
echo "1. Reset your ESP32-S3."
echo "2. Connect Wi-Fi to SSID: 'Coaster-Setup'"
echo "3. Open browser: http://192.168.4.1"
echo "====================================================================="
