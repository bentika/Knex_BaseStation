import type { ReactNode } from 'react'
import styles from './Card.module.css'

interface Props {
  title?: ReactNode
  subtitle?: ReactNode
  icon?: ReactNode
  actions?: ReactNode
  children: ReactNode
  className?: string
  /** Remove inner padding (for lists that bleed to the edge). */
  flush?: boolean
  id?: string
}

export function Card({ title, subtitle, icon, actions, children, className, flush, id }: Props) {
  return (
    <section id={id} className={[styles.card, className].filter(Boolean).join(' ')}>
      {(title || actions || subtitle) && (
        <header className={styles.head}>
          <div className={styles.headTopRow}>
            {icon && <span className={styles.icon}>{icon}</span>}
            {title && (
              <div className={styles.titleWrapper}>
                <h2 className={styles.title}>{title}</h2>
              </div>
            )}
          </div>
          {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
          {actions && <div className={styles.actions}>{actions}</div>}
        </header>
      )}
      <div className={flush ? undefined : styles.body}>{children}</div>
    </section>
  )
}
