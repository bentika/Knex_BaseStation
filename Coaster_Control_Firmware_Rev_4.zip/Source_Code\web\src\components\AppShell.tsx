import { useState, type ReactNode } from 'react'
import {
  Activity,
  AlertTriangle,
  Cpu,
  Gamepad2,
  Lightbulb,
  RotateCcw,
  Route as RouteIcon,
  Settings,
  SlidersHorizontal,
  Sun,
  Moon,
  Wifi,
} from 'lucide-react'
import { href, type Route } from '../hooks/useRoute'
import { useBoard } from '../store/boardStore'
import { useTheme } from '../store/themeStore'
import { toast } from '../store/toastStore'
import { Button } from './Button'
import { EstopButton } from './EstopButton'
import { Logo } from './Logo'
import { Toasts } from './Toasts'
import styles from './AppShell.module.css'

interface NavItem {
  route: Route
  label: string
  sub: string
  short: string
  icon: ReactNode
  soon?: boolean
}

export function AppShell({ route, children }: { route: Route; children: ReactNode }) {
  const status = useBoard((s) => s.status)
  const isProcessing = useBoard((s) => s.isProcessing)
  const estop = useBoard((s) => s.state?.estop ?? false)
  const dueling = useBoard((s) => s.state?.duelingMode ?? false)
  const info = useBoard((s) => s.info)
  const isSim = useBoard((s) => s.state?.sim ?? s.info?.sim ?? false)
  const link = useBoard((s) => s.link)
  const send = useBoard((s) => s.send)
  const { theme, toggleTheme } = useTheme()

  const [rebooting, setRebooting] = useState(false)
  const [showRebootModal, setShowRebootModal] = useState(false)

  const executeReboot = async () => {
    setShowRebootModal(false)
    try {
      setRebooting(true)
      toast.info('Reboot command dispatched to ESP32...')
      await link.reboot()
      setTimeout(() => {
        setRebooting(false)
        toast.success('ESP32 rebooting. Reconnecting in a few moments...')
      }, 2500)
    } catch {
      setRebooting(false)
      toast.error('Reboot failed or board offline')
    }
  }

  const navItems: NavItem[] = dueling
    ? [
        { route: 'manual', label: 'Manual', sub: 'Direct I/O & PWM', short: 'Manual', icon: <SlidersHorizontal /> },
        { route: 'run-a', label: 'Coaster A 🔵', sub: 'Track A Sequencer', short: 'Track A', icon: <RouteIcon /> },
        { route: 'run-b', label: 'Coaster B 🔴', sub: 'Track B Sequencer', short: 'Track B', icon: <RouteIcon /> },
        { route: 'panel', label: 'Control Panel', sub: 'PCF8575 Expander', short: 'Panel', icon: <Gamepad2 /> },
        { route: 'wled', label: 'WLED', sub: 'RGB Broadcast', short: 'WLED', icon: <Lightbulb /> },
        { route: 'settings', label: 'Settings', sub: 'OTA & Wi-Fi Diagnostic', short: 'Settings', icon: <Settings /> },
      ]
    : [
        { route: 'manual', label: 'Manual', sub: 'Direct I/O & PWM', short: 'Manual', icon: <SlidersHorizontal /> },
        { route: 'run', label: 'Run Loop', sub: 'Track Sequencer', short: 'Run Loop', icon: <RouteIcon /> },
        { route: 'panel', label: 'Control Panel', sub: 'PCF8575 Expander', short: 'Panel', icon: <Gamepad2 /> },
        { route: 'wled', label: 'WLED', sub: 'RGB Broadcast', short: 'WLED', icon: <Lightbulb /> },
        { route: 'settings', label: 'Settings', sub: 'OTA & Wi-Fi Diagnostic', short: 'Settings', icon: <Settings /> },
      ]

  const isNavActive = (nRoute: Route) => {
    if (route === nRoute) return true
    if (dueling && route === 'run' && nRoute === 'run-a') return true
    return false
  }

  const heapText = info?.heapFree ? `${Math.round(info.heapFree / 1024)} KB` : '203 KB'
  const psramText = info?.psramFree ? `${(info.psramFree / (1024 * 1024)).toFixed(2)} MB` : '7.98 MB'
  const ipText = info?.wifi?.ip || info?.wifi?.apIp || '10.139.140.245'
  const hostText = info?.hostname ? `${info.hostname}.local` : 'coaster.local'
  const rssiVal = info?.wifi?.rssi ?? -48

  return (
    <div className={styles.shell}>
      {/* Desktop Fixed Telemetry Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <a className={styles.brand} href={href('manual')}>
            <Logo size={38} />
            <div className={styles.brandText}>
              <span className={styles.brandName}>Coaster Control</span>
              <span className={styles.brandSub}>Base Station</span>
            </div>
          </a>

          {/* Core Hardware Revision Tag */}
          <div className={styles.coreTag}>
            <div className={styles.coreTagLeft}>
              <Cpu className={styles.coreIcon} />
              <span className={styles.coreLabel}>ESP32-S3 CORE</span>
            </div>
            <span className={styles.coreRev}>
              <span className={styles.coreRevDot} />
              REV 3
            </span>
          </div>

          <nav className={styles.nav} aria-label="Main Navigation">
            {navItems.map((n) => (
              <a
                key={n.route}
                id={`nav-${n.route}`}
                href={href(n.route)}
                className={`${styles.navItem} ${isNavActive(n.route) ? styles.navActive : ''}`}
                aria-current={isNavActive(n.route) ? 'page' : undefined}
              >
                <span className={styles.navIcon}>{n.icon}</span>
                <div className={styles.navLabels}>
                  <span className={styles.navLabel}>{n.label}</span>
                  <span className={styles.navSub}>{n.sub}</span>
                </div>
                {n.soon && <span className={styles.soon}>Soon</span>}
              </a>
            ))}
          </nav>
        </div>

        {/* Sidebar Hardware Telemetry Card */}
        <div className={styles.sidebarFoot}>
          <div className={styles.telemetryCard}>
            <div className={styles.telemetryHeader}>
              <div className={styles.telemetryStatus}>
                <span className={styles.pulseBeacon}>
                  <span className={styles.pulsePing} />
                  <span className={styles.pulseCore} />
                </span>
                <span className={styles.telemetryOnlineText}>
                  {status === 'online' ? (isSim ? 'SIMULATOR' : 'ONLINE') : status.toUpperCase()}
                </span>
              </div>
              <span className={`${styles.telemetryIp} mono`}>{ipText}</span>
            </div>

            <div className={styles.telemetryGrid}>
              <div className={styles.telemetryRow}>
                <span className={styles.telemetryField}>Host:</span>
                <span className={`${styles.telemetryVal} mono`}>{hostText}</span>
              </div>
              <div className={styles.telemetryRow}>
                <span className={styles.telemetryField}>Heap:</span>
                <span className={`${styles.telemetryVal} ${styles.valCyan} mono`}>{heapText}</span>
              </div>
              <div className={styles.telemetryRow}>
                <span className={styles.telemetryField}>PSRAM:</span>
                <span className={`${styles.telemetryVal} ${styles.valMint} mono`}>{psramText}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main View Area */}
      <div className={styles.main}>
        {/* Top Header */}
        <header className={styles.header}>
          {/* Left Breadcrumb & Node Info */}
          <div className={styles.headerLeft}>
            <a className={styles.mobileBrand} href={href('manual')}>
              <Logo size={32} />
              <span className={styles.mobileBrandName}>Coaster Control</span>
            </a>

            <div className={styles.telemetryBreadcrumb}>
              <span className={styles.telemetryPrefix}>NODE //</span>
              <span className={styles.telemetryNodeName}>ESP32-S3-MAIN</span>
              <span className={styles.telemetryDivider}>/</span>
              <span className={styles.telemetryBus}>TELEMETRY BUS</span>
            </div>
          </div>

          {/* Right Status Actions */}
          <div className={styles.headerRight}>
            {/* Persistent Global Operation Mode Indicator */}
            {isSim ? (
              <div
                className={`${styles.modePill} ${styles.simModePill}`}
                title="Simulation Active: Commands safe for bench testing, no high-voltage motor output"
              >
                <span className={styles.modeDot} />
                <span>SIM</span>
              </div>
            ) : (
              <div
                className={`${styles.modePill} ${styles.liveModePill}`}
                title="LIVE Hardware Outputs Active: Physical motors, servos, and drivers energized!"
              >
                <span className={styles.modeDot} />
                <span>LIVE</span>
              </div>
            )}

            <div className={styles.telemetryPills}>
              <div className={styles.telemetryPill} title="WebSocket telemetry ping roundtrip">
                <Activity className={styles.pillIconMint} />
                <span className="mono">12ms</span>
              </div>
              <div className={styles.telemetryPillDivider} />
              <div className={styles.telemetryPill} title="Wi-Fi Signal Strength">
                <Wifi className={styles.pillIconCyan} />
                <span className="mono">{rssiVal} dBm</span>
              </div>
            </div>

            <button
              id="btn-reboot"
              type="button"
              className={styles.rebootBtn}
              onClick={() => setShowRebootModal(true)}
              disabled={rebooting}
              title="Reboot ESP32-S3 controller"
            >
              <RotateCcw className={`${styles.rebootIcon} ${rebooting ? styles.rebootSpin : ''}`} />
              <span className={styles.rebootText}>Reboot</span>
            </button>

            <button
              id="btn-theme-toggle"
              type="button"
              className={styles.themeToggleBtn}
              onClick={toggleTheme}
              title={theme === 'light' ? 'Switch to Dark Theme' : 'Switch to Light Theme'}
              aria-label={theme === 'light' ? 'Switch to Dark Theme' : 'Switch to Light Theme'}
            >
              {theme === 'light' ? (
                <>
                  <Sun className={styles.themeIcon} />
                  <span className={styles.themeText}>Theme: Light</span>
                </>
              ) : (
                <>
                  <Moon className={styles.themeIcon} />
                  <span className={styles.themeText}>Theme: Dark</span>
                </>
              )}
            </button>

            <EstopButton />
          </div>
        </header>

        {isProcessing && <div className={styles.processingBar} title="Communicating with ESP32..." />}

        {status !== 'online' && (
          <div className={styles.connectingBanner} role="status">
            <span className={styles.connectingSpinner} />
            <div className={styles.connectingText}>
              <strong>{status === 'connecting' ? 'Connecting to ESP32...' : 'Reconnecting to ESP32 Wi-Fi...'}</strong>
              <span>
                {status === 'connecting'
                  ? 'Establishing WebSocket connection to coaster Base Station'
                  : 'Lost link. Automatically reconnecting (checking 192.168.4.1)...'}
              </span>
            </div>
          </div>
        )}

        {estop && (
          <div className={styles.estopBanner} role="alert">
            <span className={styles.estopDot} />
            <div className={styles.estopText}>
              <strong>E-STOP ACTIVE</strong>
              <span>All motors are halted. Output commands are blocked until reset.</span>
            </div>
            <button id="estop-reset" className={styles.estopReset} onClick={() => send({ c: 'reset' })}>
              Reset E-STOP
            </button>
          </div>
        )}

        <main className={styles.content}>{children}</main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className={styles.tabbar} aria-label="Mobile Navigation">
        {navItems.map((n) => (
          <a
            key={n.route}
            href={href(n.route)}
            className={`${styles.tab} ${isNavActive(n.route) ? styles.tabActive : ''}`}
            aria-current={isNavActive(n.route) ? 'page' : undefined}
          >
            <span className={styles.tabIcon}>{n.icon}</span>
            <span className={styles.tabLabel}>{n.short}</span>
          </a>
        ))}
      </nav>

      {/* In-App Confirmation Modal for Controller Reboot */}
      {showRebootModal && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modalCard}>
            <div className={styles.modalHeader}>
              <AlertTriangle className={styles.modalIconDanger} />
              <h3 className={styles.modalTitle}>Reboot Base Station Controller?</h3>
            </div>
            <div className={styles.modalBody}>
              All active loop sequencers, sensor listeners, and motor PWM outputs will momentarily halt. The ESP32-S3 will reboot and automatically re-establish telemetry in ~5 seconds.
            </div>
            <div className={styles.modalActions}>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowRebootModal(false)}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={executeReboot}
              >
                Reboot Controller
              </Button>
            </div>
          </div>
        </div>
      )}

      <Toasts />
    </div>
  )
}
