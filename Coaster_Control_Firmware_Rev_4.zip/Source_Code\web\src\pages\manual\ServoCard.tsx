import { useState, useEffect } from 'react'
import type { ServoState } from '../../api/types'
import styles from './ServoCard.module.css'

interface Props {
  id: number
  name: string
  state: ServoState
  onSet: (angle: number) => void
  disabled?: boolean
}

const PRESETS = [0, 45, 90, 135, 180]

export function ServoCard({ id, name, state, onSet, disabled }: Props) {
  const [targetAngle, setTargetAngle] = useState(state.target ?? 90)

  useEffect(() => {
    if (state.target !== undefined) {
      setTargetAngle(state.target)
    }
  }, [state.target])

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10)
    setTargetAngle(val)
  }

  const handleSliderCommit = (e: React.PointerEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>) => {
    const val = parseInt((e.currentTarget as HTMLInputElement).value, 10)
    setTargetAngle(val)
    onSet(val)
  }

  const handlePreset = (deg: number) => {
    setTargetAngle(deg)
    onSet(deg)
  }

  // Semi-circle perimeter for R=40 is PI * 40 = 125.66
  const maxCircumference = 125.66
  const fraction = Math.max(0, Math.min(180, targetAngle)) / 180
  const strokeOffset = maxCircumference - maxCircumference * fraction
  const pct = (targetAngle / 180) * 100

  const roleName = `Channel S-0${id}`

  return (
    <div className={styles.card} data-servo={id} data-angle={targetAngle}>
      {/* Header */}
      <div className={styles.header}>
        <span className={styles.name}>{name}</span>
        <span className={`${styles.posTag} mono`}>{targetAngle}°</span>
      </div>

      {/* Tactile Arc Radial Gauge */}
      <div className={styles.gaugeContainer}>
        <svg className={styles.gaugeSvg} viewBox="0 0 100 55" aria-hidden="true">
          {/* Background Track */}
          <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="var(--surface-container-highest)"
            strokeWidth="7"
            strokeLinecap="round"
          />
          {/* Active Glowing Arc */}
          <path
            className={styles.gaugeArc}
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="7"
            strokeLinecap="round"
            strokeDasharray={maxCircumference}
            strokeDashoffset={strokeOffset}
          />
        </svg>

        {/* Center Readout & Subtitle */}
        <div className={styles.readoutCenter}>
          <span className={`${styles.degReadout} mono`}>{targetAngle}°</span>
          <span className={styles.roleLabel}>{roleName}</span>
        </div>
      </div>

      {/* Range Drag Slider with 6px track and dynamic fill */}
      <div className={styles.sliderWrap}>
        <input
          type="range"
          min={0}
          max={180}
          value={targetAngle}
          disabled={disabled}
          onChange={handleSliderChange}
          onPointerUp={handleSliderCommit}
          onKeyUp={handleSliderCommit}
          className={styles.rangeInput}
          style={{
            background: `linear-gradient(to right, #0284c7 ${pct}%, var(--surface-container-highest) ${pct}%)`,
          }}
          aria-label={`${name} angle`}
        />
      </div>

      {/* Compact Segmented Presets */}
      <div className={styles.segmentedControl}>
        {PRESETS.map((deg) => (
          <button
            key={deg}
            type="button"
            className={`${styles.segmentBtn} ${
              targetAngle === deg ? styles.segmentActive : ''
            }`}
            onClick={() => handlePreset(deg)}
            disabled={disabled}
          >
            <span className="mono">{deg}°</span>
          </button>
        ))}
      </div>
    </div>
  )
}
