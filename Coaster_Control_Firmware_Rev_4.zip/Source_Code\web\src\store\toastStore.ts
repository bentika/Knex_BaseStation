import { create } from 'zustand'

export type ToastTone = 'info' | 'success' | 'warn' | 'error'

export interface ToastAction {
  label: string
  onClick: () => void
}

export interface Toast {
  id: number
  tone: ToastTone
  title: string
  body?: string
  action?: ToastAction
}

interface ToastStore {
  toasts: Toast[]
  push: (tone: ToastTone, title: string, body?: string, action?: ToastAction) => void
  dismiss: (id: number) => void
}

let nextId = 1

export const useToasts = create<ToastStore>((set, get) => ({
  toasts: [],
  push: (tone, title, body, action) => {
    const id = nextId++
    set((s) => ({ toasts: [...s.toasts, { id, tone, title, body, action }].slice(-4) }))
    const timeout = action ? 7500 : (tone === 'error' ? 6000 : 3500)
    window.setTimeout(() => get().dismiss(id), timeout)
  },
  dismiss: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}))

/** Shortcut usable outside React components. */
export const toast = {
  info: (title: string, body?: string, action?: ToastAction) => useToasts.getState().push('info', title, body, action),
  success: (title: string, body?: string, action?: ToastAction) => useToasts.getState().push('success', title, body, action),
  warn: (title: string, body?: string, action?: ToastAction) => useToasts.getState().push('warn', title, body, action),
  error: (title: string, body?: string, action?: ToastAction) => useToasts.getState().push('error', title, body, action),
}

