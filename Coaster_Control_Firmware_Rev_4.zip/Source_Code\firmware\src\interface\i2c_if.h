#ifndef INTERFACE_I2C_IF_H
#define INTERFACE_I2C_IF_H

#include <stdint.h>
#include "error.h"

/**
 * @brief Abstract I2C bus interface contract.
 *
 * Decouples device drivers (e.g., PCF8575) from MCU vendor HAL libraries
 * (Wire / ESP-IDF I2C) and enables deterministic host-side mock testing.
 */
typedef struct {
    /**
     * @brief Probe a 7-bit I2C device address for ACK.
     *
     * @param addr 7-bit slave address
     * @return fw_err_t FW_OK if device responds, FW_ERR_COMMUNICATION otherwise
     */
    fw_err_t (*probe)(uint8_t addr);

    /**
     * @brief Write raw bytes to a 7-bit I2C device address.
     *
     * @param addr 7-bit slave address
     * @param data Pointer to transmit buffer
     * @param len  Number of bytes to transmit
     * @return fw_err_t FW_OK on success
     */
    fw_err_t (*write)(uint8_t addr, const uint8_t *data, uint32_t len);

    /**
     * @brief Read raw bytes from a 7-bit I2C device address.
     *
     * @param addr 7-bit slave address
     * @param data Pointer to receive buffer
     * @param len  Number of bytes to read
     * @return fw_err_t FW_OK on success
     */
    fw_err_t (*read)(uint8_t addr, uint8_t *data, uint32_t len);
} i2c_if_t;

#endif /* INTERFACE_I2C_IF_H */

