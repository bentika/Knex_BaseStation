#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <stdint.h>
#include <stdbool.h>
#include "../pins.h"
#include "../io/IOInterface.h"
#include "pcf8575.h"

#define PCF8575_I2C_ADDR            PCF8575_DEFAULT_I2C_ADDR
#define NUM_PANEL_PINS              PCF8575_NUM_PINS
#define PANEL_I2C_FREQ_HZ           (100000UL)
#define PANEL_POLL_INTERVAL_MS      (20UL)
#define PANEL_DEBOUNCE_MS           (50UL)
#define PANEL_REPROBE_INTERVAL_MS   (3000UL)
#define PANEL_MAX_READ_FAILURES     (10U)
#define PANEL_INVALID_PIN           (255U)
#define PANEL_DEFAULT_MOTOR_PWM     (100)
#define PANEL_SERVO_THRESHOLD_DEG   (90)
#define PANEL_SERVO_MIN_DEG         (0)
#define PANEL_SERVO_MAX_DEG         (180)
#define PANEL_SERVO_DEFAULT_SPEED   (100)

/**
 * @brief Button action mapping for a single PCF8575 expander input pin.
 */
struct PanelPinConfig {
    uint8_t pin;           // 0..15
    String action;         // "dispatch", "estop", "reset", "startStopLoop", "hall_X", "motorToggle_X", "servoToggle_X", "none"
    String label;
};

/**
 * @brief Physical control panel manager.
 *
 * Polls the 16-bit PCF8575 I/O expander through the layered `pcf8575_t` device
 * driver (`i2c_if_t`), applies per-pin debouncing, and dispatches button actions
 * to the `IOInterface` and `RunLoopEngine`.
 */
class PanelManager {
public:
    /**
     * @brief Get the singleton PanelManager instance.
     * @return PanelManager& Singleton reference
     */
    static PanelManager& instance();

    /**
     * @brief Initialize the I2C bus, probe the PCF8575 expander, and load button mappings.
     *
     * @param io Pointer to the active hardware I/O interface
     * @return bool true if the PCF8575 expander was detected on the I2C bus
     */
    bool begin(IOInterface* io);

    /**
     * @brief Poll the PCF8575 expander at 50 Hz (20 ms interval) and process edge transitions.
     */
    void update();

    /**
     * @brief Check whether the physical PCF8575 panel is connected.
     * @return bool true if detected at boot
     */
    bool isDetected() const { return _detected; }

    /**
     * @brief Get the raw 16-bit port state mask (active-low: bit = 0 when pressed).
     * @return uint16_t 16-bit state mask
     */
    uint16_t getRawState() const { return _currentState; }

    /**
     * @brief Query whether a specific panel pin (0..15) is currently pressed.
     *
     * @param pin Pin index (0..15)
     * @return bool true if pressed (active LOW)
     */
    bool isPinPressed(uint8_t pin) const;

    /**
     * @brief Get configuration for a panel pin (0..15).
     *
     * @param pin Pin index (0..15)
     * @return const PanelPinConfig& Pin configuration
     */
    const PanelPinConfig& getPinConfig(uint8_t pin) const;

    /**
     * @brief Update and persist the action and label for a panel pin.
     *
     * @param pin    Pin index (0..15)
     * @param action Action identifier string
     * @param label  Human-readable button label
     */
    void setPinConfig(uint8_t pin, const String& action, const String& label);

    /**
     * @brief Load panel pin mappings from `/panel.json` on LittleFS.
     * @return bool true on success
     */
    bool loadConfig();

    /**
     * @brief Save panel pin mappings to `/panel.json` on LittleFS.
     * @return bool true on success
     */
    bool saveConfig();

    /**
     * @brief Populate default button mappings for pins 0..15.
     */
    void loadDefaultMappings();

    /**
     * @brief Serialize panel detection state and pin configs into a JSON object.
     * @param obj Target JsonObject
     */
    void serializeStatus(JsonObject& obj) const;

private:
    PanelManager();
    void executePinAction(uint8_t pin);

    IOInterface* _io;
    pcf8575_t _expander;
    bool _detected;
    uint16_t _currentState;
    uint16_t _lastState;
    uint32_t _lastReadMs;
    uint32_t _lastProbeMs;
    uint8_t _readFailures;
    uint32_t _lastDebounceMs[NUM_PANEL_PINS];

    PanelPinConfig _pinConfigs[NUM_PANEL_PINS];
};
