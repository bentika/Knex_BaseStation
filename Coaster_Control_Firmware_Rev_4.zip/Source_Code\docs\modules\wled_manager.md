# WledManager Module (`docs/modules/wled_manager.md`)

## Purpose

[`WledManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/net/WledManager.h) provides non-blocking network integration with external WLED Wi-Fi lighting controllers (such as on-train battery LEDs or coaster track scenery).

## Responsibilities

- Maintains a FreeRTOS queue (`WLED_QUEUE_DEPTH = 16`) of fixed-width `WledCommand` structs (`char targetIp[40]`, `int32_t preset`) with zero heap allocation during queue operations.
- Runs a dedicated background worker task (`WledWorker`) on **Core 0** (`Priority 1`, `4096 B` stack) that performs HTTP GET requests (`http://<ip>/win&PL=<preset>`, `300 ms` timeout) without ever blocking the Core 1 coaster control loop.
- Exposes `getQueueDepth()`, `getStackHighWaterMark()`, and `getLastHeartbeatMs()` to the RTOS health monitor.

