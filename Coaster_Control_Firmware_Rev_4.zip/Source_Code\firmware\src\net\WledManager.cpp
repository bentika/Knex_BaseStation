#include "WledManager.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <cstring>

WledManager& WledManager::instance() {
    static WledManager inst;
    return inst;
}

WledManager::WledManager()
    : _queue(nullptr),
      _taskHandle(nullptr),
      _lastHeartbeatMs(0U) {
}

bool WledManager::begin() {
    (void)loadConfig();

    _queue = xQueueCreate(WLED_QUEUE_DEPTH, sizeof(WledCommand));
    if (_queue == nullptr) {
        return false;
    }

    _lastHeartbeatMs = (uint32_t)millis();

    // Run WLED background communication worker task on Core 0 with priority 1
    BaseType_t created = xTaskCreatePinnedToCore(
        workerTask,
        "WledWorker",
        WLED_TASK_STACK_BYTES,
        this,
        WLED_TASK_PRIORITY,
        &_taskHandle,
        WLED_TASK_CORE
    );

    return (created == pdPASS);
}

void WledManager::update() {
    // Worker task runs independently on Core 0
}

void WledManager::queueTrigger(const String& targetIp, int preset) {
    if (_queue == nullptr || targetIp.length() == 0U || preset <= 0) {
        return;
    }

    WledCommand cmd;
    strncpy(cmd.targetIp, targetIp.c_str(), sizeof(cmd.targetIp) - 1U);
    cmd.targetIp[sizeof(cmd.targetIp) - 1U] = '\0';
    cmd.preset = (int32_t)preset;

    // Non-blocking queue send; drop if queue is completely full so control task never blocks
    (void)xQueueSend(_queue, &cmd, 0U);
}

void WledManager::triggerAll(int preset) {
    for (const auto& dev : _devices) {
        if (dev.enabled && dev.ip.length() > 0U) {
            queueTrigger(dev.ip, preset);
        }
    }
}

void WledManager::triggerDevice(const String& deviceIdOrIp, int preset) {
    for (const auto& dev : _devices) {
        if (dev.id == deviceIdOrIp || dev.ip == deviceIdOrIp) {
            queueTrigger(dev.ip, preset);
            return;
        }
    }
    queueTrigger(deviceIdOrIp, preset);
}

void WledManager::setDevices(const std::vector<WledDevice>& devices) {
    _devices = devices;
    (void)saveConfig();
}

uint32_t WledManager::getQueueDepth() const {
    if (_queue == nullptr) {
        return 0U;
    }
    return (uint32_t)uxQueueMessagesWaiting(_queue);
}

uint32_t WledManager::getStackHighWaterMark() const {
    if (_taskHandle == nullptr) {
        return 0U;
    }
    return (uint32_t)uxTaskGetStackHighWaterMark(_taskHandle);
}

bool WledManager::loadConfig() {
    _devices.clear();

    if (!LittleFS.exists("/wled.json")) {
        _devices.push_back({"train1", "Train #1", "192.168.0.130", true});
        _devices.push_back({"scenery", "Track Scenery", "192.168.0.131", true});
        return saveConfig();
    }

    File f = LittleFS.open("/wled.json", "r");
    if (!f) {
        return false;
    }

    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, f);
    f.close();

    if (err || !doc["devices"].is<JsonArray>()) {
        _devices.push_back({"train1", "Train #1", "192.168.0.130", true});
        _devices.push_back({"scenery", "Track Scenery", "192.168.0.131", true});
        return false;
    }

    for (JsonObject obj : doc["devices"].as<JsonArray>()) {
        WledDevice dev;
        dev.id = obj["id"] | "";
        dev.name = obj["name"] | "";
        dev.ip = obj["ip"] | "";
        dev.enabled = obj["enabled"] | true;
        if (dev.ip.length() > 0U) {
            _devices.push_back(dev);
        }
    }

    return true;
}

bool WledManager::saveConfig() {
    JsonDocument doc;
    JsonArray arr = doc["devices"].to<JsonArray>();

    for (const auto& dev : _devices) {
        JsonObject obj = arr.add<JsonObject>();
        obj["id"] = dev.id;
        obj["name"] = dev.name;
        obj["ip"] = dev.ip;
        obj["enabled"] = dev.enabled;
    }

    File f = LittleFS.open("/wled.json", "w");
    if (!f) {
        return false;
    }

    (void)serializeJson(doc, f);
    f.close();
    return true;
}

void WledManager::workerTask(void* param) {
    WledManager* self = static_cast<WledManager*>(param);
    if (self == nullptr) {
        vTaskDelete(nullptr);
        return;
    }

    WledCommand cmd;

    for (;;) {
        self->_lastHeartbeatMs = (uint32_t)millis();
        if (xQueueReceive(self->_queue, &cmd, pdMS_TO_TICKS(WLED_HEARTBEAT_WAIT_MS)) == pdTRUE) {
            self->_lastHeartbeatMs = (uint32_t)millis();
            if (WiFi.status() == WL_CONNECTED && strlen(cmd.targetIp) > 0U && cmd.preset > 0) {
                self->sendHttpRequest(cmd.targetIp, cmd.preset);
            }
        }
    }
}

void WledManager::sendHttpRequest(const char* ip, int32_t preset) {
    if (ip == nullptr) {
        return;
    }
    HTTPClient http;
    String url = "http://" + String(ip) + "/win&PL=" + String(preset);
    if (http.begin(url)) {
        http.setTimeout(WLED_HTTP_TIMEOUT_MS);
        (void)http.GET();
        http.end();
    }
}
