# K'NEX Roller Coaster Base Station Controller

## Project Overview

Embedded firmware (`firmware/`) and offline-first React/TypeScript web control dashboard (`web/`) for the **K'NEX Roller Coaster Base Station (Rev 3)** designed around the **ESP32-S3-DevKitC-1 N16R8** (16 MB Flash, 8 MB OPI PSRAM).

The controller automates single-track and dueling multi-train K'NEX roller coasters using 12 active-LOW Hall effect block-zone sensors, 6 PWM motor channels (2 reversible H-bridge + 4 MOSFET switch channels), 6 hardware-timed 50 Hz RC servo outputs, a 16-button PCF8575 I2C physical control panel, and network-synchronized WLED lighting controllers.

---

## Features

- **6 Motor Outputs (100% Default PWM, 20 kHz Silent LEDC)**:
  - **Motors 1 & 2**: DRV8833 Dual H-Bridge (`FWD`/`REV` direction control + soft-start/stop ramping).
  - **Motors 3 – 6**: High-current MOSFET switch/PWM drivers (selectable 3V, 5V, or VCC rails on PCB).
- **6 Hardware RC Servo Outputs (ESP32-S3 MCPWM Group 0 @ 50 Hz)**:
  - Driven via the dedicated ESP32-S3 MCPWM hardware peripheral (`500–2500 µs` pulse width, `0–180°`) so all 6 servos operate with zero LEDC channel conflict.
- **12 Hall Effect Sensor Inputs (A3144 Active LOW)**:
  - Hardware `IRAM_ATTR` falling-edge interrupt capture (`< 2 µs` Fast-In/Fast-Out ISR) with deferred task-context multi-magnet train debounce lockout (`1500 ms` default).
- **Programmable Block-Zone & Timed-Stage Sequencer (`RunLoopEngine`)**:
  - Includes a dedicated **Dispatch (`id = 0`)** intro block feeding into `H1 → H2 → ... → H12`.
  - Configurable per-stage time delays (`+0.5s`, `+1s`, `+2s`, `+3s`, `+5s`, or custom seconds).
  - Supports **Single Coaster Mode** (12 Halls, 6 Motors) and **Dueling Coaster Mode** (Track A & Track B independent state machines).
- **Interactive Web Dashboard (`http://coaster.local` / `http://192.168.4.1`)**:
  - Interactive draggable **Track Schematic Vector Editor** with active-Hall filtering.
  - One-click **Quick Motor & Servo Toggle** bus and Manual Test workbench.
  - Built-in browser simulator (`npm run dev:mock`) for full offline testing without hardware.
- **Physical Control Panel (`PCF8575` 16-Bit I2C Expander)**:
  - Layered HAL-independent driver (`pcf8575_t` + `i2c_if_t`) polling 16 arcade buttons at 50 Hz.
- **Asynchronous WLED Lighting Integration (`WledManager`)**:
  - Non-blocking FreeRTOS queue and Core 0 HTTP worker task for triggering train and scenery presets.

---

## Hardware Platform

- **MCU**: ESP32-S3-WROOM-1 / ESP32-S3-DevKitC-1 **N16R8** (Dual-Core Xtensa LX7 @ 240 MHz, 16 MB QIO Flash, 8 MB OPI PSRAM)
- **Board Revision**: Base Station PCB Rev 3 (`BaseStationPinsAfterLayout - RunLoop.pdf`)

| Peripheral | Interface / Driver | GPIO Pins | Purpose |
|---|---|---|---|
| Motors 1 & 2 | LEDC Ch 0–3 (`RealIO`) | M1: `19, 20` / M2: `12, 11` | DRV8833 H-Bridge reversible motors (20 kHz, 8-bit) |
| Motors 3 – 6 | LEDC Ch 4–7 (`RealIO`) | `10, 38, 18, 39` | MOSFET single-direction motors (20 kHz, 8-bit) |
| Servos 1 – 6 | MCPWM Group 0 (`RealIO`) | `4, 5, 6, 7, 43, 15` | 50 Hz RC Servos (`500–2500 µs` hardware timers) |
| Halls 1 – 12 | GPIO ISR (`RealIO`) | `13, 47, 41, 2, 1, 44, 14, 21, 40, 42, 17, 16` | A3144 Active-LOW Hall sensors (`INPUT_PULLUP`, `FALLING` ISR) |
| I2C Bus | `i2c_if_t` / `pcf8575_t` | SDA: `8`, SCL: `9` | PCF8575 16-bit arcade control panel expander (`0x20`) |

See [`docs/Hardware.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/Hardware.md) for the complete electrical and peripheral mapping table.

---

## Build Instructions

### 1. Build Web Dashboard (and Gzip to `firmware/data/`)

```bash
cd web
npm install
npm run build
```

For local browser simulation without an ESP32 board:

```bash
cd web
npm run dev:mock
```

### 2. Compile ESP32-S3 Firmware

```bash
cd firmware
pio run -e s3
```

See [`docs/Build.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/Build.md) for all PlatformIO build environments (`s3`, `s3-bench`, `s3-sim`, `s3-ota`, `esp32-sim`).

---

## Flash Instructions

Connect the ESP32-S3-DevKitC-1 via its **UART** USB-C port:

```bash
cd firmware

# 1. Flash compiled firmware binary
pio run -e s3 -t upload

# 2. Flash gzipped React Web UI into LittleFS partition
pio run -e s3 -t uploadfs
```

Alternatively, double-click `flash_firmware_windows.bat` in the delivery package, or upload `firmware.bin` and `littlefs.bin` wirelessly via `http://coaster.local/api/v1/update`.

---

## Project Structure

```text
rollor-coster-esp32-hall-effects-project-12/
├── firmware/
│   ├── src/
│   │   ├── main.cpp                 — App entry, RTOS ControlTask & Health Watchdog
│   │   ├── pins.h                   — Board pinout & default Wi-Fi macros
│   │   ├── interface/               — Hardware abstraction contracts (error.h, i2c_if.h)
│   │   ├── io/                      — IOInterface contract & ESP32-S3 RealIO driver
│   │   ├── drivers/                 — PCF8575 device driver & PanelManager service
│   │   ├── engine/                  — RunLoopEngine block-zone & stage state machine
│   │   ├── config/                  — LittleFS persistent configuration manager
│   │   └── net/                     — AsyncWebServer, WebSocket, Captive Portal & WledManager
│   ├── data/                        — Gzipped LittleFS web assets built from web/
│   └── platformio.ini               — PlatformIO multi-environment configuration
├── web/                             — React 19 + TypeScript + Vite dashboard & mock simulator
├── docs/                            — Embedded architecture, RTOS, ISR, hardware & module docs
└── graphify-out/                    — Codebase knowledge graph
```

See [`docs/DirectoryStructure.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/DirectoryStructure.md) for full details.

---

## Software Architecture

```text
app (main.cpp: ControlTask @ 500 Hz, CommLoop @ 200 Hz, HealthMonitor)
 ↓
module (RunLoopEngine, PanelManager, ConfigManager, WebServerManager, WledManager)
 ↓
interface (IOInterface, i2c_if_t, fw_err_t)
 ↓
driver / bsp (RealIO [LEDC + MCPWM + GPIO ISR], pcf8575_t [I2C Expander], bsp_i2c)
 ↓
platform (ESP32-S3 Arduino Core 3.x / ESP-IDF MCPWM, LEDC, FreeRTOS, LittleFS)
```

---

## Documentation Index

- **L1 — Project Documentation**:
  - [`docs/Architecture.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/Architecture.md) — Layered firmware architecture & dependency rules
  - [`docs/Build.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/Build.md) — Toolchain, PlatformIO environments & LittleFS asset pipeline
  - [`docs/Hardware.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/Hardware.md) — Rev 3 PCB pinout, timers, LEDC/MCPWM channels & electrical specs
  - [`docs/DirectoryStructure.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/DirectoryStructure.md) — Repository directory layout
- **L2 — Module Design Documents**:
  - [`docs/modules/io_driver.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/modules/io_driver.md) — `RealIO` Motor LEDC, Servo MCPWM & Hall Sensor driver
  - [`docs/modules/runloop_engine.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/modules/runloop_engine.md) — `RunLoopEngine` coaster automation sequencer
  - [`docs/modules/panel_manager.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/modules/panel_manager.md) — `PanelManager` & `pcf8575_t` arcade control panel driver
  - [`docs/modules/wled_manager.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/modules/wled_manager.md) — `WledManager` asynchronous network lighting service
  - [`docs/modules/webserver_manager.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/modules/webserver_manager.md) — `WebServerManager` REST, WebSocket & Wi-Fi AP+STA manager
- **L3 — Interface Specifications**:
  - [`docs/interfaces/io_interface.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/interfaces/io_interface.md) — `IOInterface` hardware abstraction contract
  - [`docs/interfaces/i2c_interface.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/interfaces/i2c_interface.md) — `i2c_if_t` & `fw_err_t` bus abstraction contract
- **L4 — RTOS & ISR Design**:
  - [`docs/TaskDesign.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/TaskDesign.md) — FreeRTOS task decomposition, priorities, periods, WCET & watchdog
  - [`docs/ISRDesign.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/ISRDesign.md) — Hall GPIO interrupt design, latency budget & deferred processing
- **L5 — Control & State Machines**:
  - [`docs/StateMachine.md`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/docs/StateMachine.md) — `RunLoopEngine` & Wi-Fi state machine diagrams and transitions

---

## Dependencies

- **Firmware**:
  - `pioarduino/platform-espressif32` (Arduino-ESP32 Core 3.x / ESP-IDF 5.x)
  - `esp32async/AsyncTCP` (`^3.3.2`)
  - `esp32async/ESPAsyncWebServer` (`^3.7.0`)
  - `bblanchon/ArduinoJson` (`^7.2.0`)
- **Web Application**:
  - Node.js 18+ / npm
  - React 19, TypeScript 5.8, Vite 6, Lucide React

---

## License

Proprietary / Custom Hardware Controller Firmware for K'NEX Roller Coaster Base Station (`bentika`).
