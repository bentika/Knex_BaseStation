# RTOS Task Design (`embedded-rtos-design`)

## Task Classification & Schedule Table

| Task Name | Category | Core | Period / Rate | Priority | Stack (Bytes) | Estimated WCET | Primary Responsibility |
|---|---|---|---|---|---|---|---|
| `ControlTask` | Control & Acquisition | Core 1 | `2 ms` (`500 Hz`) via `vTaskDelayUntil` | `5` (High) | `8192` | `< 150 µs` | Motor PWM ramping, Servo slew interpolation, deferred Hall ISR debounce, `RunLoopEngine` A & B step timing |
| `AsyncTCP` | Communication | Core 1 | Event-driven | `3` (Medium) | `16384` | `< 2 ms` | Non-blocking HTTP REST & WebSocket packet framing |
| `loopTask` (`CommLoop`) | Communication & Service | Core 1 | `5 ms` (`200 Hz`) via `vTaskDelayUntil` | `1` (Low) | `8192` | `< 800 µs` | PCF8575 I2C button polling (50 Hz), Captive DNS, Wi-Fi state recovery, 10–16 Hz WebSocket broadcast, Watchdog monitor |
| `WledWorker` | Service / Comm | Core 0 | Event-driven (`1000 ms` heartbeat wake) | `1` (Low) | `4096` | `< 300 ms` (HTTP timeout) | Asynchronous HTTP GET preset triggers to external WLED controllers |

---

## Task Interaction & Data Flow Diagram

```text
[Hall GPIO FALLING ISR] (< 2 µs, IRAM)
          │
          ▼ (s_isrHallEdgeMask + portMUX_TYPE spinlock)
   ┌──────────────┐
   │ ControlTask  │ (Core 1, Priority 5, 500 Hz fixed-rate vTaskDelayUntil)
   │  - RealIO    │
   │  - RunLoop   │
   └──────┬───────┘
          │
          ├───► [LEDC Hardware Channels 0..7] ───► Motors 1..6 (20 kHz PWM)
          ├───► [MCPWM Group 0 Hardware]      ───► Servos 1..6 (50 Hz PWM)
          │
          └───► (xQueueSend non-blocking: WledCommand[16])
                                │
                                ▼
                         ┌──────────────┐
                         │  WledWorker  │ (Core 0, Priority 1)
                         └──────┬───────┘
                                │
                                ▼
                        HTTP GET /win&PL=<preset>
```

---

## Resource Ownership Model

Every hardware peripheral has a single owning context to prevent bus contention:

| Hardware Resource | Owning Task / Context | Access Mechanism |
|---|---|---|
| LEDC Channels `0..7` (Motors 1–6) | `ControlTask` (`RealIO`) | Updated deterministically in `RealIO::update()` / `applyMotorHardware()` |
| MCPWM Group 0 (Servos 1–6) | `ControlTask` (`RealIO`) | Updated in `RealIO::update()` / `applyServoHardware()` |
| Hall Sensor GPIOs (`1..12`) | `hall_gpio_isr_handler` → `ControlTask` | ISR latches edge bitmask (`s_isrHallEdgeMask`); `ControlTask` debounces & clears |
| I2C0 Bus (`GPIO 8/9`, `PCF8575 0x20`) | `loopTask` (`PanelManager`) | Polled exclusively by `PanelManager::update()` at 50 Hz |
| Outbound WLED HTTP Client | `WledWorker` (Core 0) | Producers enqueue `WledCommand` via `_queue` (`xQueueSend` with `0` wait) |

---

## Synchronization Primitives

| Resource | Primitive Type | Producer | Consumer | Purpose |
|---|---|---|---|---|
| `s_isrHallEdgeMask` | `portMUX_TYPE` critical section + `volatile uint16_t` | `hall_gpio_isr_handler` (ISR) | `RealIO::update()` (`ControlTask`) | Lock-free sub-microsecond handoff of Hall sensor falling edges |
| `WledManager::_queue` | FreeRTOS `QueueHandle_t` (`16 × sizeof(WledCommand)`) | `RunLoopEngine` / `WebServerManager` | `WledWorker` (Core 0) | Decouples up to 300 ms Wi-Fi HTTP requests from real-time coaster control |
| `RunLoopEngine::_mutex` | FreeRTOS recursive mutex (`RunLoopLock` RAII guard) | `ControlTask`, AsyncTCP (REST/WS), `loopTask` (panel buttons) | all three | Serializes access to the program vector and live sequence state so a program upload can never race a running sequence |
| `s_controlTaskHeartbeatMs` | `volatile uint32_t` timestamp | `ControlTask` (every 2 ms) | `health_monitor_check()` (`loopTask`) | Liveness watchdog monitoring |

---

## Watchdog & Health Monitoring (`health_monitor_check`)

Implemented in [`firmware/src/main.cpp`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/main.cpp):

1. **Hard Real-Time Liveness Check**:
   - `ControlTask` updates `s_controlTaskHeartbeatMs` every `2 ms`.
   - `health_monitor_check()` verifies `(nowMs - s_controlTaskHeartbeatMs) <= WATCHDOG_CONTROL_TIMEOUT_MS (500 ms)` on every communication pass.
   - If `ControlTask` ever stalls for `> 500 ms`, the health monitor immediately latches Emergency Stop (`s_realIO.setEstop(true)`), zeroing all 6 motor PWM channels and broadcasting a `WATCHDOG FAULT` event.
2. **Queue Depth & Stack High-Water Mark Telemetry**:
   - Periodically samples `uxTaskGetStackHighWaterMark(s_controlTaskHandle)`, `WledManager::instance().getStackHighWaterMark()`, and `WledManager::instance().getQueueDepth()` (`uxQueueMessagesWaiting`) every `5000 ms`.

