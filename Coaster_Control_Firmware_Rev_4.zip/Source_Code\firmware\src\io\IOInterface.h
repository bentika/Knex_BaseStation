#pragma once

#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>
#include <functional>
#include "../interface/error.h"

#define HALL_DEFAULT_DEBOUNCE_MS    (1500UL)

/**
 * @brief Motor rotation direction for reversible H-Bridge channels (M1, M2).
 */
enum class MotorDir : uint8_t {
    FWD = 0,
    REV = 1
};

/**
 * @brief Telemetry snapshot for a single motor channel.
 */
struct MotorStatus {
    int32_t pwm;        // 0 - 100% (current ramped output)
    int32_t target;     // 0 - 100% (commanded target output)
    MotorDir dir;       // FWD or REV
    int32_t rampMs;     // Ramp duration in ms
};

/**
 * @brief Telemetry snapshot for a single RC servo channel.
 */
struct ServoStatus {
    int32_t angle;      // 0 - 180 deg (current interpolated angle)
    int32_t target;     // 0 - 180 deg (commanded target angle)
    int32_t speed;      // 0 = immediate, >0 = angular speed (deg/s)
};

/**
 * @brief Hardware Abstraction Interface for Motors, Servos, Hall Sensors, and E-Stop.
 *
 * Consumed by `RunLoopEngine`, `PanelManager`, and `WebServerManager` so application
 * modules never access ESP32-S3 LEDC, MCPWM, or GPIO registers directly.
 */
class IOInterface {
public:
    virtual ~IOInterface() = default;

    /**
     * @brief Initialize all hardware peripherals (LEDC, MCPWM, GPIO, ISRs).
     */
    virtual void begin() = 0;

    /**
     * @brief Periodic real-time update tick (ramping, servo interpolation, deferred ISR handling).
     */
    virtual void update() = 0;

    /**
     * @brief Command a motor output (1..NUM_MOTORS).
     *
     * @param id     1-based motor index (1..6)
     * @param pwm    Target PWM percentage (0..100)
     * @param dir    Direction (FWD or REV; REV supported on H-bridge motors 1 & 2)
     * @param rampMs Soft-start/stop ramp duration in milliseconds (0 = immediate)
     */
    virtual void setMotor(uint8_t id, int pwm, MotorDir dir = MotorDir::FWD, int rampMs = 0) = 0;

    /**
     * @brief Immediately stop a single motor (1..NUM_MOTORS).
     * @param id 1-based motor index (1..6)
     */
    virtual void stopMotor(uint8_t id) = 0;

    /**
     * @brief Immediately stop all motors (1..NUM_MOTORS).
     */
    virtual void stopAllMotors() = 0;

    /**
     * @brief Command a servo output angle (1..NUM_SERVOS).
     *
     * @param id    1-based servo index (1..6)
     * @param angle Target angle in degrees (0..180)
     * @param speed Slew rate in deg/s (0 = immediate step)
     */
    virtual void setServo(uint8_t id, int angle, int speed = 0) = 0;

    /**
     * @brief Query current status of a motor channel.
     * @param id 1-based motor index (1..6)
     * @return MotorStatus Current PWM, target, and direction
     */
    virtual MotorStatus getMotorStatus(uint8_t id) const = 0;

    /**
     * @brief Query current status of a servo channel.
     * @param id 1-based servo index (1..6)
     * @return ServoStatus Current angle, target, and slew speed
     */
    virtual ServoStatus getServoStatus(uint8_t id) const = 0;

    /**
     * @brief Query whether a Hall sensor is currently active (or holding its UI pulse).
     * @param id 1-based Hall sensor index (1..12)
     * @return bool true if active
     */
    virtual bool getHallActive(uint8_t id) const = 0;

    /**
     * @brief Get total valid train-pass trigger count for a Hall sensor.
     * @param id 1-based Hall sensor index (1..12)
     * @return uint32_t Trigger counter
     */
    virtual uint32_t getHallCount(uint8_t id) const = 0;

    /**
     * @brief Reset all Hall sensor trigger counters to zero.
     */
    virtual void resetHallCounts() = 0;

    /**
     * @brief Synchronize Hall sensor baseline states with current physical pin levels
     *        and clear any pending edge glitches (called on engine start / dispatch).
     */
    virtual void syncHallBaseline() {}

    /**
     * @brief Simulate a manual Hall sensor pulse (for Manual Test UI) without firing the Run Loop.
     * @param id 1-based Hall sensor index (1..12)
     */
    virtual void simulateHall(uint8_t id) = 0;

    /**
     * @brief Activate or clear the Emergency Stop latch.
     * @param active true to cut all motors immediately and inhibit actuation
     */
    virtual void setEstop(bool active) = 0;

    /**
     * @brief Check whether Emergency Stop is currently latched.
     * @return bool true if E-Stop is active
     */
    virtual bool isEstop() const = 0;

    typedef std::function<void(uint8_t hallId)> HallCallback;

    /**
     * @brief Register task-context callback invoked when a physical Hall sensor triggers.
     * @param cb Callback receiving 1-based hallId (1..12)
     */
    virtual void setHallCallback(HallCallback cb) { _hallCallback = cb; }

    /**
     * @brief Configure the multi-magnet train debounce lockout window in milliseconds.
     * @param ms Lockout window (100..10000 ms, default 1500 ms)
     */
    virtual void setHallDebounceMs(uint32_t ms) { _hallDebounceMs = ms; }

    /**
     * @brief Get the configured multi-magnet train debounce lockout window in milliseconds.
     * @return uint32_t Lockout window in ms
     */
    virtual uint32_t getHallDebounceMs() const { return _hallDebounceMs; }

    /**
     * @brief Enable or disable dry-run simulation mode (suppresses physical PWM output).
     * @param sim true for simulation mode, false for physical hardware mode
     */
    virtual void setSimMode(bool sim) = 0;

    /**
     * @brief Check whether dry-run simulation mode is active.
     * @return bool true if in simulation mode
     */
    virtual bool isSimMode() const = 0;

protected:
    HallCallback _hallCallback = nullptr;
    uint32_t _hallDebounceMs = HALL_DEFAULT_DEBOUNCE_MS;
};
