import type {
  BoardInfo,
  Command,
  ServerMessage,
  SystemConfig,
  WifiConfig,
  WifiNetwork,
} from './types'

export type LinkStatus = 'connecting' | 'online' | 'offline'

export interface LinkHandlers {
  onStatus: (status: LinkStatus) => void
  onMessage: (msg: ServerMessage) => void
}

export type UploadTarget = 'firmware' | 'fs'

/**
 * Everything the UI needs from "a board". Two implementations:
 *  - BoardLink: talks to the real ESP32 over HTTP + WebSocket
 *  - MockBoard: a simulated board running inside the browser
 * Pages never talk to fetch/WebSocket directly, which keeps the door open
 * for a future native (Capacitor) app.
 */
export interface Link {
  readonly kind: 'board' | 'mock'
  connect(handlers: LinkHandlers): void
  disconnect(): void
  send(cmd: Command): void

  getInfo(): Promise<BoardInfo>
  getWifi(): Promise<WifiConfig>
  saveWifi(cfg: WifiConfig): Promise<void>
  scanWifi(): Promise<WifiNetwork[]>
  getSystem(): Promise<SystemConfig>
  saveSystem(cfg: SystemConfig): Promise<void>
  reboot(): Promise<void>
  upload(target: UploadTarget, file: File, onProgress: (fraction: number) => void): Promise<void>

  // Run Loop
  getRunLoop(coaster?: 'a' | 'b'): Promise<import('./types').RunLoopConfig>
  saveRunLoop(cfg: import('./types').RunLoopConfig, coaster?: 'a' | 'b'): Promise<void>
  startRunLoop(coaster?: 'a' | 'b'): Promise<void>
  stopRunLoop(coaster?: 'a' | 'b'): Promise<void>
  resetRunLoop(coaster?: 'a' | 'b'): Promise<void>
  dispatch(coaster?: 'a' | 'b'): Promise<void>
  dispatchBoth(): Promise<void>
  testHall(hallId: number, coaster?: 'a' | 'b'): Promise<void>
  loadDefaultTemplate(coaster?: 'a' | 'b'): Promise<void>

  // WLED
  getWled(): Promise<import('./types').WledConfig>
  saveWled(cfg: import('./types').WledConfig): Promise<void>
  triggerWled(target: string, preset: number): Promise<void>

  // Panel
  getPanel(): Promise<import('./types').PanelStatus>
  savePanel(cfg: import('./types').PanelConfig): Promise<void>
}
