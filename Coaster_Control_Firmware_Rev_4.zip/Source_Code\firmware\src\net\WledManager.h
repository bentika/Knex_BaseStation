#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <stdint.h>
#include <stdbool.h>
#include <vector>

#define WLED_IP_MAX_LEN         (40U)
#define WLED_QUEUE_DEPTH        (16U)
#define WLED_TASK_STACK_BYTES   (4096U)
#define WLED_TASK_PRIORITY      (1U)
#define WLED_TASK_CORE          (0)
#define WLED_HTTP_TIMEOUT_MS    (300U)
#define WLED_HEARTBEAT_WAIT_MS  (1000U)

/**
 * @brief Network configuration for a WLED lighting controller node.
 */
struct WledDevice {
    String id;
    String name;
    String ip;
    bool enabled;
};

/**
 * @brief Fixed-size queue item passed from real-time tasks to the WLED background worker.
 *        Uses static char array (no heap allocation in queue transfer).
 */
struct WledCommand {
    char targetIp[WLED_IP_MAX_LEN];
    int32_t preset;
};

/**
 * @brief Asynchronous WLED Network Lighting Manager.
 *
 * Decouples HTTP lighting triggers from the real-time coaster control loop using
 * a FreeRTOS message queue (`_queue`) and a background communication task (`WledWorker`)
 * pinned to Core 0.
 */
class WledManager {
public:
    /**
     * @brief Get the singleton WledManager instance.
     * @return WledManager& Singleton reference
     */
    static WledManager& instance();

    /**
     * @brief Load WLED device list from LittleFS and spawn the Core 0 worker task.
     * @return bool true if queue and task were created successfully
     */
    bool begin();

    /**
     * @brief Periodic service hook (no-op; worker task runs asynchronously on Core 0).
     */
    void update();

    /**
     * @brief Enqueue a non-blocking WLED preset HTTP trigger to a specific IP.
     *
     * @param targetIp Destination IPv4 address string
     * @param preset   WLED preset ID (1..250)
     */
    void queueTrigger(const String& targetIp, int preset);

    /**
     * @brief Enqueue a WLED preset trigger for all enabled WLED devices.
     * @param preset WLED preset ID (1..250)
     */
    void triggerAll(int preset);

    /**
     * @brief Enqueue a WLED preset trigger for a specific device ID or IP address.
     *
     * @param deviceIdOrIp Device identifier or IPv4 address
     * @param preset       WLED preset ID (1..250)
     */
    void triggerDevice(const String& deviceIdOrIp, int preset);

    /**
     * @brief Get the configured list of WLED devices.
     * @return const std::vector<WledDevice>& Device vector
     */
    const std::vector<WledDevice>& getDevices() const { return _devices; }

    /**
     * @brief Replace and persist the list of WLED devices.
     * @param devices New device vector
     */
    void setDevices(const std::vector<WledDevice>& devices);

    /**
     * @brief Load WLED configuration from `/wled.json`.
     * @return bool true on success
     */
    bool loadConfig();

    /**
     * @brief Save WLED configuration to `/wled.json`.
     * @return bool true on success
     */
    bool saveConfig();

    /**
     * @brief Get current number of pending commands in the WLED queue (for RTOS health monitor).
     * @return uint32_t Pending message count
     */
    uint32_t getQueueDepth() const;

    /**
     * @brief Get minimum free stack bytes (high-water mark) of the WledWorker task.
     * @return uint32_t Free stack high-water mark
     */
    uint32_t getStackHighWaterMark() const;

    /**
     * @brief Get last worker task heartbeat timestamp in milliseconds.
     * @return uint32_t Timestamp (`millis()`)
     */
    uint32_t getLastHeartbeatMs() const { return _lastHeartbeatMs; }

private:
    WledManager();
    void sendHttpRequest(const char* ip, int32_t preset);

    std::vector<WledDevice> _devices;
    QueueHandle_t _queue;
    TaskHandle_t _taskHandle;
    volatile uint32_t _lastHeartbeatMs;

    static void workerTask(void* param);
};
