import type { Link, LinkHandlers, UploadTarget } from './link'
import type {
  BoardInfo,
  Command,
  PanelConfig,
  PanelStatus,
  RunLoopConfig,
  ServerMessage,
  SystemConfig,
  WifiConfig,
  WifiNetwork,
  WledConfig,
} from './types'

const API = '/api/v1'

/**
 * Base URL of the board. Empty = same origin (the normal case: the UI is
 * served by the board itself). Can be overridden with localStorage
 * "boardUrl", e.g. "http://192.168.1.50" – used by a future native app.
 */
function baseUrl(): string {
  return (localStorage.getItem('boardUrl') ?? '').replace(/\/$/, '')
}

function wsUrl(): string {
  const base = baseUrl()
  if (base) return base.replace(/^http/, 'ws') + '/ws'
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:'
  return `${proto}//${location.host}/ws`
}

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(baseUrl() + API + path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(text || `${res.status} ${res.statusText}`)
  }
  const type = res.headers.get('content-type') ?? ''
  return (type.includes('application/json') ? res.json() : undefined) as Promise<T>
}

export class BoardLink implements Link {
  readonly kind = 'board' as const
  private ws: WebSocket | null = null
  private handlers: LinkHandlers | null = null
  private retry = 0
  private retryTimer: number | undefined
  private closedByUser = false

  connect(handlers: LinkHandlers): void {
    this.handlers = handlers
    this.closedByUser = false
    this.open()
  }

  disconnect(): void {
    this.closedByUser = true
    window.clearTimeout(this.retryTimer)
    this.ws?.close()
    this.ws = null
  }

  private open(): void {
    this.handlers?.onStatus('connecting')
    const ws = new WebSocket(wsUrl())
    this.ws = ws

    ws.onopen = () => {
      this.retry = 0
      this.handlers?.onStatus('online')
    }
    ws.onmessage = (ev) => {
      try {
        this.handlers?.onMessage(JSON.parse(ev.data as string) as ServerMessage)
      } catch {
        /* ignore malformed frames */
      }
    }
    ws.onclose = () => {
      if (this.ws !== ws) return
      this.ws = null
      this.handlers?.onStatus('offline')
      if (this.closedByUser) return
      // Exponential back-off: 0.5 s, 1 s, 2 s … max 5 s
      const delay = Math.min(5000, 500 * 2 ** this.retry++)
      this.retryTimer = window.setTimeout(() => this.open(), delay)
    }
    ws.onerror = () => ws.close()
  }

  send(cmd: Command): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(cmd))
    } else {
      // Fallback over HTTP so important commands (ESTOP) still get through
      void http('/cmd', { method: 'POST', body: JSON.stringify(cmd) }).catch(() => {})
    }
  }

  getInfo = () => http<BoardInfo>('/info')
  getWifi = () => http<WifiConfig>('/config/wifi')
  saveWifi = (cfg: WifiConfig) => http<void>('/config/wifi', { method: 'PUT', body: JSON.stringify(cfg) })
  scanWifi = () => http<WifiNetwork[]>('/wifi/scan')
  getSystem = () => http<SystemConfig>('/config/system')
  saveSystem = (cfg: SystemConfig) =>
    http<void>('/config/system', { method: 'PUT', body: JSON.stringify(cfg) })
  reboot = () => http<void>('/reboot', { method: 'POST' })

  // Run Loop
  getRunLoop = (coaster?: 'a' | 'b') => http<RunLoopConfig>(coaster ? `/runloop/${coaster}` : '/runloop')
  saveRunLoop = (cfg: RunLoopConfig, coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}` : '/runloop', { method: 'PUT', body: JSON.stringify(cfg) })
  startRunLoop = (coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/start` : '/runloop/start', { method: 'POST' })
  stopRunLoop = (coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/stop` : '/runloop/stop', { method: 'POST' })
  resetRunLoop = (coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/reset` : '/runloop/reset', { method: 'POST' })
  dispatch = (coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/dispatch` : '/runloop/dispatch', { method: 'POST' })
  dispatchBoth = () => http<void>('/runloop/dispatch-both', { method: 'POST' })
  testHall = (hallId: number, coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/test-hall` : '/runloop/test-hall', {
      method: 'POST',
      body: JSON.stringify({ hallId }),
    })
  loadDefaultTemplate = (coaster?: 'a' | 'b') =>
    http<void>(coaster ? `/runloop/${coaster}/template` : '/runloop/template', { method: 'POST' })

  // WLED
  getWled = () => http<WledConfig>('/wled')
  saveWled = (cfg: WledConfig) => http<void>('/wled', { method: 'PUT', body: JSON.stringify(cfg) })
  triggerWled = (target: string, preset: number) => http<void>('/wled/trigger', { method: 'POST', body: JSON.stringify({ target, preset }) })

  // Panel
  getPanel = () => http<PanelStatus>('/panel')
  savePanel = (cfg: PanelConfig) => http<void>('/panel', { method: 'PUT', body: JSON.stringify(cfg) })

  upload(target: UploadTarget, file: File, onProgress: (fraction: number) => void): Promise<void> {
    // XHR instead of fetch: fetch has no upload progress events.
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('POST', `${baseUrl()}${API}/update?target=${target}`)
      xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total)
      xhr.onload = () =>
        xhr.status >= 200 && xhr.status < 300
          ? resolve()
          : reject(new Error(xhr.responseText || `Upload failed (${xhr.status})`))
      xhr.onerror = () => reject(new Error('Connection lost during upload'))
      const form = new FormData()
      form.append('file', file, file.name)
      xhr.send(form)
    })
  }
}
