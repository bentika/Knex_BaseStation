# I2C Bus & Error Interface Specification (`embedded-documentation` L3)

## Purpose

[`i2c_if.h`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/interface/i2c_if.h) and [`error.h`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/interface/error.h) provide a portable, mockable C bus interface for I2C peripheral drivers (such as the [`pcf8575_t`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/drivers/pcf8575.h) 16-bit I/O expander) so device drivers never depend directly on MCU vendor HAL libraries (`Wire` / ESP-IDF `i2c_master`).

## Public API

```c
typedef enum {
    FW_OK = 0,
    FW_ERR_TIMEOUT,
    FW_ERR_BUSY,
    FW_ERR_INVALID_PARAM,
    FW_ERR_NOT_INITIALIZED,
    FW_ERR_NOT_READY,
    FW_ERR_COMMUNICATION,
    FW_ERR_OVERFLOW,
    FW_ERR_UNDERFLOW
} fw_err_t;

typedef struct {
    fw_err_t (*probe)(uint8_t addr);
    fw_err_t (*write)(uint8_t addr, const uint8_t *data, uint32_t len);
    fw_err_t (*read)(uint8_t addr, uint8_t *data, uint32_t len);
} i2c_if_t;
```

## Ownership

- **Implemented by**: Board-level I2C adapter (`s_board_i2c_if` in [`PanelManager.cpp`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/drivers/PanelManager.cpp)) or host-side unit test mocks.
- **Consumed by**: [`pcf8575.cpp`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/drivers/pcf8575.cpp).

## Thread Safety

Not internally mutex-locked. The single owning task (`loopTask` via `PanelManager::update()`) serializes all I2C0 bus transactions at 50 Hz.

