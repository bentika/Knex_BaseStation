#include "RunLoopEngine.h"
#include "../net/WledManager.h"
#include "../config/ConfigManager.h"
#include <LittleFS.h>

RunLoopEngine& RunLoopEngine::instance() {
    return instanceA();
}

RunLoopEngine& RunLoopEngine::instanceA() {
    static RunLoopEngine instA('A');
    return instA;
}

RunLoopEngine& RunLoopEngine::instanceB() {
    static RunLoopEngine instB('B');
    return instB;
}

RunLoopEngine::RunLoopEngine(char coasterId)
    : _io(nullptr),
      _coasterId(coasterId),
      _engineActive(false),
      _activeHall(-1),
      _activeStep(-1),
      _stepStartMs(0U),
      _stepDurationMs(0U),
      _waitingDispatch(false),
      _dispatchWaitStartMs(0U),
      _dispatchTimeoutMs(0U),
      _lastDispatchMs(0U),
      _trainCount(1U) {
    _mutex = xSemaphoreCreateRecursiveMutex();
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        _autoStopMotors[i] = {0U, 0U, false};
    }
    for (uint8_t i = 0U; i < NUM_HALLS; i++) {
        _lastHallTriggerMs[i] = 0U;
    }
    _trains[0] = {1U, 1, 2, false};
    _trains[1] = {2U, 4, 1, false};
}

String RunLoopEngine::getConfigPath() const {
    if (_coasterId == 'B') {
        return "/runloop_b.json";
    }
    if (ConfigManager::instance().config().duelingMode) {
        return "/runloop_a.json";
    }
    return "/runloop.json";
}

void RunLoopEngine::begin(IOInterface* io, char coasterId) {
    _io = io;
    _coasterId = coasterId;
    reload();
}

void RunLoopEngine::reload() {
    RunLoopLock lock(_mutex);
    if (!loadConfig()) {
        loadDefaultTemplate();
        (void)saveConfig();
    }
}

void RunLoopEngine::loadDefaultTemplate() {
    RunLoopLock lock(_mutex);
    _programs.clear();
    bool dueling = ConfigManager::instance().config().duelingMode || (_coasterId == 'B');
    uint8_t count = dueling ? RUNLOOP_DUEL_HALLS_PER_TRACK : NUM_HALLS;

    // Include Dispatch (id = 0) as the intro sequence entry in the Run Loop
    HallProgram dispProg;
    dispProg.hallId = RUNLOOP_DISPATCH_HALL_ID;
    dispProg.name = "Dispatch";
    dispProg.enabled = true;
    dispProg.wledPreset = 0;
    dispProg.lockoutMs = RUNLOOP_DEFAULT_DISPATCH_LOCKOUT_MS;
    _programs.push_back(dispProg);

    for (uint8_t h = 1U; h <= count; h++) {
        HallProgram prog;
        prog.hallId = h;
        prog.name = "Hall " + String(h);
        prog.enabled = true;
        prog.wledPreset = 0;
        prog.lockoutMs = RUNLOOP_DEFAULT_HALL_LOCKOUT_MS;
        _programs.push_back(prog);
    }
    _trainCount = 1U;
    resetTrainPositions();
}

std::vector<uint8_t> RunLoopEngine::getActiveHallOrder() const {
    std::vector<uint8_t> order;
    for (const auto& prog : _programs) {
        if (prog.hallId >= 1U && prog.hallId <= NUM_HALLS && prog.enabled) {
            order.push_back(prog.hallId);
        }
    }
    return order;
}

uint8_t RunLoopEngine::getNextActiveHall(uint8_t hallId) const {
    std::vector<uint8_t> order = getActiveHallOrder();
    if (order.empty()) {
        return hallId;
    }
    for (size_t i = 0U; i < order.size(); i++) {
        if (order[i] == hallId) {
            return order[(i + 1U) % order.size()];
        }
    }
    return order[0];
}

void RunLoopEngine::resetTrainPositions() {
    std::vector<uint8_t> order = getActiveHallOrder();
    if (order.empty()) {
        _trains[0] = {1U, 1, 2, false};
        _trains[1] = {2U, 2, 1, false};
        return;
    }
    if (order.size() == 1U) {
        _trains[0] = {1U, (int32_t)order[0], (int32_t)order[0], false};
        _trains[1] = {2U, (int32_t)order[0], (int32_t)order[0], false};
        return;
    }
    _trains[0] = {1U, (int32_t)order[0], (int32_t)order[1], false};
    uint8_t t2Hall = order[order.size() - 1U];
    _trains[1] = {2U, (int32_t)t2Hall, (int32_t)getNextActiveHall(t2Hall), false};
}

void RunLoopEngine::setTrainCount(uint8_t count) {
    RunLoopLock lock(_mutex);
    _trainCount = (count >= 2U) ? 2U : 1U;
    resetTrainPositions();
    (void)saveConfig();
}

void RunLoopEngine::releaseHeldTrain(uint8_t trainIdx) {
    if (trainIdx >= RUNLOOP_MAX_TRAINS || !_trains[trainIdx].held || _io == nullptr) {
        return;
    }
    int32_t holdHall = _trains[trainIdx].currentHall;
    _trains[trainIdx].held = false;
    _trains[trainIdx].nextHall = (int32_t)getNextActiveHall((uint8_t)holdHall);

    const HallProgram* holdProg = nullptr;
    for (const auto& prog : _programs) {
        if ((int32_t)prog.hallId == holdHall && prog.enabled) {
            holdProg = &prog;
            break;
        }
    }
    if (holdProg == nullptr) {
        return;
    }

    // 1. Release block brake servo if configured
    if (holdProg->blockServoId >= 1U && holdProg->blockServoId <= NUM_SERVOS) {
        _io->setServo(holdProg->blockServoId, (int)holdProg->blockReleaseAngle, 100);
    }

    // 2. Restart designated block motor so the train moves into the now-clear block zone
    if (holdProg->blockMotorId >= 1U && holdProg->blockMotorId <= NUM_MOTORS) {
        int32_t pwm = (holdProg->blockMotorPwm > 0) ? holdProg->blockMotorPwm : RUNLOOP_DEFAULT_MOTOR_PWM;
        _io->setMotor(holdProg->blockMotorId, (int)pwm, holdProg->blockMotorDir);
    }

    // 3. Execute any configured stages for this Hall sensor if the sequencer is idle
    if (!holdProg->steps.empty() && _activeHall < 0) {
        _activeHall = holdHall;
        executeStep(0U);
    }
}

void RunLoopEngine::startEngine() {
    RunLoopLock lock(_mutex);
    if (_io != nullptr) {
        _io->syncHallBaseline();
    }
    _engineActive = true;
}

void RunLoopEngine::stopEngine() {
    RunLoopLock lock(_mutex);
    _engineActive = false;
    finishCurrentProgram();
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        _autoStopMotors[i].active = false;
    }
    if (_io != nullptr) {
        if (_coasterId == 'B') {
            for (uint8_t m = 4U; m <= 6U; m++) {
                _io->stopMotor(m);
            }
        } else if (ConfigManager::instance().config().duelingMode) {
            for (uint8_t m = 1U; m <= 3U; m++) {
                _io->stopMotor(m);
            }
        } else {
            _io->stopAllMotors();
        }
    }
}

void RunLoopEngine::resetEngine() {
    RunLoopLock lock(_mutex);
    stopEngine();
    if (_io != nullptr) {
        _io->syncHallBaseline();
    }
    resetTrainPositions();
    _engineActive = true;
}

void RunLoopEngine::dispatch() {
    RunLoopLock lock(_mutex);
    if (_io == nullptr || _io->isEstop()) {
        return;
    }

    _io->syncHallBaseline();
    _lastDispatchMs = (uint32_t)millis();

    if (_waitingDispatch) {
        _waitingDispatch = false;
        if (_activeStep >= 0) {
            executeStep((size_t)(_activeStep + 1));
        }
        return;
    }

    // Update Train 1 to first active block zone on dispatch
    std::vector<uint8_t> order = getActiveHallOrder();
    if (!order.empty()) {
        _trains[0].currentHall = (int32_t)order[0];
        _trains[0].nextHall = (int32_t)getNextActiveHall(order[0]);
        _trains[0].held = false;
    }

    // Trigger programmable Dispatch block (hallId == 0) if configured
    for (const auto& prog : _programs) {
        if (prog.hallId == RUNLOOP_DISPATCH_HALL_ID && prog.enabled) {
            _engineActive = true;
            if (prog.wledPreset > 0) {
                WledManager::instance().triggerAll((int)prog.wledPreset);
            }
            finishCurrentProgram();
            if (!prog.steps.empty()) {
                _activeHall = (int32_t)RUNLOOP_DISPATCH_HALL_ID;
                executeStep(0U);
            }
            return;
        }
    }
}

void RunLoopEngine::testFireHall(uint8_t hallId) {
    RunLoopLock lock(_mutex);
    if (hallId == RUNLOOP_DISPATCH_HALL_ID) {
        dispatch();
        return;
    }
    _engineActive = true;
    onHallTriggered(hallId);
}

void RunLoopEngine::onHallTriggered(uint8_t hallId) {
    RunLoopLock lock(_mutex);
    if (!_engineActive || _io == nullptr || _io->isEstop()) {
        return;
    }
    if (hallId < 1U || hallId > NUM_HALLS) {
        return;
    }

    const HallProgram* targetProg = nullptr;
    for (const auto& prog : _programs) {
        if (prog.hallId == hallId && prog.enabled) {
            targetProg = &prog;
            break;
        }
    }
    if (targetProg == nullptr) {
        return;
    }

    // Enforce post-dispatch motor startup EMI / station departure settling window on Hall 1
    uint32_t now = (uint32_t)millis();
    if (hallId == 1U && _lastDispatchMs > 0U && ((now - _lastDispatchMs) < RUNLOOP_DISPATCH_SETTLE_MS)) {
        return;
    }

    // Enforce multi-magnet train debounce lockout (ignores trailing magnets 1-6 on same train pass)
    uint32_t lockout = (targetProg->lockoutMs > 0U)
                           ? targetProg->lockoutMs
                           : RUNLOOP_DEFAULT_HALL_LOCKOUT_MS;
    if ((now - _lastHallTriggerMs[hallId - 1U]) < lockout) {
        return; // Suppressed: train is still passing over this block section
    }
    _lastHallTriggerMs[hallId - 1U] = now;

    // 1. Update Train Position & Block Zone Safety Interlocks (1-Train vs 2-Train Mode)
    uint8_t nextHallId = getNextActiveHall(hallId);
    if (_trainCount <= 1U) {
        _trains[0].currentHall = (int32_t)hallId;
        _trains[0].nextHall = (int32_t)nextHallId;
        _trains[0].held = false;
    } else {
        // 2-Train Block Zone Mode: Identify which train arrived at hallId
        uint8_t arrivingIdx = 0U;
        if (_trains[0].nextHall == (int32_t)hallId && !_trains[0].held) {
            arrivingIdx = 0U;
        } else if (_trains[1].nextHall == (int32_t)hallId && !_trains[1].held) {
            arrivingIdx = 1U;
        } else if (_trains[0].currentHall == (int32_t)hallId) {
            arrivingIdx = 0U;
        } else if (_trains[1].currentHall == (int32_t)hallId) {
            arrivingIdx = 1U;
        }
        uint8_t otherIdx = (arrivingIdx == 0U) ? 1U : 0U;

        // Advance arriving train to hallId (this clears its previous block zone!)
        _trains[arrivingIdx].currentHall = (int32_t)hallId;
        _trains[arrivingIdx].nextHall = (int32_t)nextHallId;
        _trains[arrivingIdx].held = false;

        // Step A: If the other train was held at a previous block boundary waiting for its zone ahead
        // to clear, check if that zone is now clear and release the held train automatically!
        if (_trains[otherIdx].held) {
            int32_t holdZone = _trains[otherIdx].currentHall;
            bool zoneNowClear = (_trains[arrivingIdx].currentHall != holdZone);
            if (zoneNowClear) {
                releaseHeldTrain(otherIdx);
            }
        }

        // Step B: Check if the block zone ahead of hallId (hallId -> nextHallId) is currently OCCUPIED
        // by the other train. If so, and hallId is a Block Hold Point, hold the arriving train here!
        bool nextBlockOccupied = (_trains[otherIdx].currentHall == (int32_t)hallId) ||
                                 (_trains[otherIdx].currentHall == (int32_t)nextHallId && _trains[otherIdx].held);
        if (nextBlockOccupied && targetProg->isBlockHold) {
            _trains[arrivingIdx].held = true;
            if (targetProg->blockMotorId >= 1U && targetProg->blockMotorId <= NUM_MOTORS) {
                _io->stopMotor(targetProg->blockMotorId);
            } else {
                // Auto-stop any motor referenced in this Hall's stages
                for (const auto& st : targetProg->steps) {
                    for (const auto& act : st.actions) {
                        if (act.type == ActionType::MOTOR && act.motorId >= 1U && act.motorId <= NUM_MOTORS) {
                            _io->stopMotor(act.motorId);
                        }
                    }
                }
            }
            if (targetProg->blockServoId >= 1U && targetProg->blockServoId <= NUM_SERVOS) {
                _io->setServo(targetProg->blockServoId, (int)targetProg->blockHoldAngle, 100);
            }
            if (targetProg->wledPreset > 0) {
                WledManager::instance().triggerAll((int)targetProg->wledPreset);
            }
            return; // Hold train at hallId until the block zone ahead clears!
        }
    }

    // 2. Fire WLED trigger immediately if defined
    if (targetProg->wledPreset > 0) {
        WledManager::instance().triggerAll((int)targetProg->wledPreset);
    }

    // 3. If this Hall is a Block Hold point and the block ahead is CLEAR, ensure its block motor/servo are in release state
    if (targetProg->isBlockHold && targetProg->steps.empty()) {
        if (targetProg->blockServoId >= 1U && targetProg->blockServoId <= NUM_SERVOS) {
            _io->setServo(targetProg->blockServoId, (int)targetProg->blockReleaseAngle, 100);
        }
        if (targetProg->blockMotorId >= 1U && targetProg->blockMotorId <= NUM_MOTORS) {
            int32_t pwm = (targetProg->blockMotorPwm > 0) ? targetProg->blockMotorPwm : RUNLOOP_DEFAULT_MOTOR_PWM;
            _io->setMotor(targetProg->blockMotorId, (int)pwm, targetProg->blockMotorDir);
        }
    }

    // 4. Preempt currently running sequence
    finishCurrentProgram();

    // 5. If there are steps to execute, begin Step 0
    if (!targetProg->steps.empty()) {
        _activeHall = (int32_t)hallId;
        executeStep(0U);
    }
}

void RunLoopEngine::executeStep(size_t stepIdx) {
    if (_activeHall < 0 || _io == nullptr || _io->isEstop()) {
        finishCurrentProgram();
        return;
    }

    const HallProgram* prog = nullptr;
    for (const auto& p : _programs) {
        if ((int32_t)p.hallId == _activeHall) {
            prog = &p;
            break;
        }
    }

    if (prog == nullptr || stepIdx >= prog->steps.size()) {
        finishCurrentProgram();
        return;
    }

    _activeStep = (int32_t)stepIdx;
    _stepStartMs = (uint32_t)millis();
    _waitingDispatch = false;

    const RunStep& step = prog->steps[stepIdx];
    uint32_t maxActionDuration = step.delayMs;

    // Execute all concurrent actions in this step
    for (const auto& act : step.actions) {
        switch (act.type) {
            case ActionType::MOTOR: {
                if (act.motorOp == "start") {
                    _io->setMotor(act.motorId, (int)act.pwm, act.dir);
                } else if (act.motorOp == "stop") {
                    _io->stopMotor(act.motorId);
                } else if (act.motorOp == "runTime") {
                    _io->setMotor(act.motorId, (int)act.pwm, act.dir);
                    uint8_t idx = act.motorId - 1U;
                    if (idx < NUM_MOTORS) {
                        _autoStopMotors[idx].motorId = act.motorId;
                        _autoStopMotors[idx].stopAtMs = (uint32_t)millis() + act.durationMs;
                        _autoStopMotors[idx].active = true;
                    }
                    if (act.durationMs > maxActionDuration) {
                        maxActionDuration = act.durationMs;
                    }
                }
                break;
            }
            case ActionType::SERVO: {
                _io->setServo(act.servoId, (int)act.angle, (int)act.speed);
                if (act.durationMs > maxActionDuration) {
                    maxActionDuration = act.durationMs;
                }
                break;
            }
            case ActionType::DELAY: {
                if (act.durationMs > maxActionDuration) {
                    maxActionDuration = act.durationMs;
                }
                break;
            }
            case ActionType::WAIT_DISPATCH: {
                _waitingDispatch = true;
                _dispatchWaitStartMs = (uint32_t)millis();
                _dispatchTimeoutMs = act.timeoutMs;
                break;
            }
            case ActionType::WLED: {
                if (act.wledPreset > 0) {
                    if (act.wledTarget.length() == 0U || act.wledTarget == "all") {
                        WledManager::instance().triggerAll((int)act.wledPreset);
                    } else {
                        WledManager::instance().triggerDevice(act.wledTarget, (int)act.wledPreset);
                    }
                }
                break;
            }
        }
    }

    // If the next timed stage has a configured delayMs (time offset after this stage),
    // wait at least that duration before advancing to stepIdx + 1
    if ((stepIdx + 1U) < prog->steps.size() && prog->steps[stepIdx + 1U].delayMs > maxActionDuration) {
        maxActionDuration = prog->steps[stepIdx + 1U].delayMs;
    }

    _stepDurationMs = maxActionDuration;
}

void RunLoopEngine::finishCurrentProgram() {
    _activeHall = -1;
    _activeStep = -1;
    _waitingDispatch = false;
    _stepDurationMs = 0U;
}

void RunLoopEngine::update() {
    RunLoopLock lock(_mutex);
    uint32_t now = (uint32_t)millis();

    // 1. Auto-stop any motors whose runTime has expired
    for (uint8_t i = 0U; i < NUM_MOTORS; i++) {
        if (_autoStopMotors[i].active && now >= _autoStopMotors[i].stopAtMs) {
            _autoStopMotors[i].active = false;
            if (_io != nullptr) {
                _io->stopMotor(_autoStopMotors[i].motorId);
            }
        }
    }

    // 2. Check active sequence progression
    if (_activeHall >= 0 && _activeStep >= 0) {
        if (_io != nullptr && _io->isEstop()) {
            finishCurrentProgram();
            return;
        }

        if (_waitingDispatch) {
            if (_dispatchTimeoutMs > 0U && ((now - _dispatchWaitStartMs) >= _dispatchTimeoutMs)) {
                _waitingDispatch = false;
                executeStep((size_t)(_activeStep + 1));
                return;
            }
        } else {
            if ((now - _stepStartMs) >= _stepDurationMs) {
                executeStep((size_t)(_activeStep + 1));
            }
        }
    }
}

RunLoopStatus RunLoopEngine::getStatus() const {
    RunLoopLock lock(_mutex);
    RunLoopStatus st;
    st.enabled = _engineActive;
    st.activeHall = (_activeHall >= 0) ? _activeHall : 0;
    st.activeStep = _activeStep;
    st.waitingDispatch = _waitingDispatch;
    st.stepDurationMs = _stepDurationMs;
    st.elapsedStepMs = (_activeStep >= 0) ? ((uint32_t)millis() - _stepStartMs) : 0U;

    st.totalSteps = 0;
    if (_activeHall >= 0 && _activeStep >= 0) {
        for (const auto& p : _programs) {
            if ((int32_t)p.hallId == _activeHall) {
                st.totalSteps = (int32_t)p.steps.size();
                break;
            }
        }
    }

    st.trainCount = _trainCount;
    st.trains[0] = _trains[0];
    st.trains[1] = _trains[1];

    return st;
}

void RunLoopEngine::setPrograms(const std::vector<HallProgram>& programs) {
    RunLoopLock lock(_mutex);
    _programs = programs;
    resetTrainPositions();
    (void)saveConfig();
}

void RunLoopEngine::serializeConfig(JsonDocument& doc) const {
    RunLoopLock lock(_mutex);
    doc["trainCount"] = _trainCount;
    JsonArray arr = doc["halls"].to<JsonArray>();
    for (const auto& prog : _programs) {
        JsonObject hObj = arr.add<JsonObject>();
        hObj["id"] = prog.hallId;
        hObj["name"] = prog.name;
        hObj["enabled"] = prog.enabled;
        hObj["wledPreset"] = prog.wledPreset;
        hObj["lockoutMs"] = prog.lockoutMs;
        hObj["isBlockHold"] = prog.isBlockHold;
        hObj["blockMotorId"] = prog.blockMotorId;
        hObj["blockMotorPwm"] = prog.blockMotorPwm;
        hObj["blockMotorDir"] = (prog.blockMotorDir == MotorDir::REV) ? "rev" : "fwd";
        hObj["blockServoId"] = prog.blockServoId;
        hObj["blockHoldAngle"] = prog.blockHoldAngle;
        hObj["blockReleaseAngle"] = prog.blockReleaseAngle;

        JsonArray stepsArr = hObj["steps"].to<JsonArray>();
        for (const auto& step : prog.steps) {
            JsonObject sObj = stepsArr.add<JsonObject>();
            if (step.delayMs > 0U) {
                sObj["delayMs"] = step.delayMs;
            }
            JsonArray actArr = sObj["actions"].to<JsonArray>();
            for (const auto& act : step.actions) {
                JsonObject aObj = actArr.add<JsonObject>();
                if (act.type == ActionType::MOTOR) {
                    aObj["type"] = "motor";
                    aObj["motor"] = act.motorId;
                    aObj["op"] = act.motorOp;
                    aObj["pwm"] = act.pwm;
                    aObj["dir"] = (act.dir == MotorDir::FWD) ? "fwd" : "rev";
                    aObj["durationMs"] = act.durationMs;
                } else if (act.type == ActionType::SERVO) {
                    aObj["type"] = "servo";
                    aObj["servo"] = act.servoId;
                    aObj["op"] = act.servoOp;
                    aObj["angle"] = act.angle;
                    aObj["speed"] = act.speed;
                    aObj["pauseMs"] = act.pauseMs;
                } else if (act.type == ActionType::DELAY) {
                    aObj["type"] = "delay";
                    aObj["durationMs"] = act.durationMs;
                } else if (act.type == ActionType::WAIT_DISPATCH) {
                    aObj["type"] = "waitDispatch";
                    aObj["timeoutMs"] = act.timeoutMs;
                } else if (act.type == ActionType::WLED) {
                    aObj["type"] = "wled";
                    aObj["target"] = act.wledTarget;
                    aObj["preset"] = act.wledPreset;
                }
            }
        }
    }
}

bool RunLoopEngine::deserializeConfig(JsonVariantConst doc) {
    RunLoopLock lock(_mutex);
    if (!doc["halls"].is<JsonArrayConst>()) {
        return false;
    }

    uint8_t parsedTrainCount = doc["trainCount"] | 1U;
    _trainCount = (parsedTrainCount >= 2U) ? 2U : 1U;

    std::vector<HallProgram> progs;
    bool hasDispatch = false;

    auto isLegacyDefaultName = [](const String& n) -> bool {
        return n == "Station Approach" ||
               n == "Station Stop & Dispatch" ||
               n == "Switch Track Turn" ||
               n == "Switch Track Straight" ||
               n == "Lift Hill Crest" ||
               n == "Brake Run" ||
               n.startsWith("Hall Sensor ") ||
               n.startsWith("Track A ") ||
               n.startsWith("Track B ");
    };

    for (JsonObjectConst hObj : doc["halls"].as<JsonArrayConst>()) {
        HallProgram p;
        p.hallId = hObj["id"].is<int>() ? (uint8_t)hObj["id"].as<int>() : 1U;
        if (p.hallId == RUNLOOP_DISPATCH_HALL_ID) {
            hasDispatch = true;
        }

        String defName = (p.hallId == RUNLOOP_DISPATCH_HALL_ID) ? "Dispatch" : ("Hall " + String(p.hallId));
        String rawName = hObj["name"].is<String>() ? hObj["name"].as<String>() : defName;
        bool wasLegacyDemo = (p.hallId > 0U && isLegacyDefaultName(rawName));
        p.name = wasLegacyDemo ? defName : rawName;
        p.enabled = hObj["enabled"] | true;
        p.wledPreset = wasLegacyDemo ? 0 : (hObj["wledPreset"] | 0);
        p.lockoutMs = hObj["lockoutMs"] | RUNLOOP_DEFAULT_DISPATCH_LOCKOUT_MS;
        p.isBlockHold = hObj["isBlockHold"] | false;
        p.blockMotorId = hObj["blockMotorId"] | 0U;
        p.blockMotorPwm = hObj["blockMotorPwm"] | RUNLOOP_DEFAULT_MOTOR_PWM;
        String bmDir = hObj["blockMotorDir"] | "fwd";
        p.blockMotorDir = (bmDir == "rev") ? MotorDir::REV : MotorDir::FWD;
        p.blockServoId = hObj["blockServoId"] | 0U;
        p.blockHoldAngle = hObj["blockHoldAngle"] | 0;
        p.blockReleaseAngle = hObj["blockReleaseAngle"] | 90;

        if (!wasLegacyDemo && hObj["steps"].is<JsonArrayConst>()) {
            size_t stepIdx = 0U;
            for (JsonObjectConst sObj : hObj["steps"].as<JsonArrayConst>()) {
                RunStep s;
                s.delayMs = sObj["delayMs"] | (stepIdx > 0U ? RUNLOOP_DEFAULT_STAGE_DELAY_MS : 0UL);
                stepIdx++;
                if (sObj["actions"].is<JsonArrayConst>()) {
                    for (JsonObjectConst aObj : sObj["actions"].as<JsonArrayConst>()) {
                        StepAction a{};
                        String t = aObj["type"] | "";
                        if (t == "motor") {
                            a.type = ActionType::MOTOR;
                            a.motorId = aObj["motor"] | 1U;
                            a.motorOp = (const char*)(aObj["op"] | "start");
                            a.pwm = aObj["pwm"] | RUNLOOP_DEFAULT_MOTOR_PWM;
                            String d = aObj["dir"] | "fwd";
                            a.dir = (d == "rev") ? MotorDir::REV : MotorDir::FWD;
                            a.durationMs = aObj["durationMs"] | 0UL;
                            s.actions.push_back(a);
                        } else if (t == "servo") {
                            a.type = ActionType::SERVO;
                            a.servoId = aObj["servo"] | 1U;
                            a.servoOp = (const char*)(aObj["op"] | "set");
                            a.angle = aObj["angle"] | 0;
                            a.speed = aObj["speed"] | 0;
                            a.pauseMs = aObj["pauseMs"] | 0UL;
                            a.durationMs = aObj["durationMs"] | RUNLOOP_DEFAULT_STAGE_DELAY_MS;
                            s.actions.push_back(a);
                        } else if (t == "delay") {
                            a.type = ActionType::DELAY;
                            a.durationMs = aObj["durationMs"] | RUNLOOP_DEFAULT_DELAY_ACT_MS;
                            s.actions.push_back(a);
                        } else if (t == "waitDispatch") {
                            a.type = ActionType::WAIT_DISPATCH;
                            a.timeoutMs = aObj["timeoutMs"] | RUNLOOP_DEFAULT_DISPATCH_TIMEOUT_MS;
                            s.actions.push_back(a);
                        } else if (t == "wled") {
                            a.type = ActionType::WLED;
                            a.wledTarget = (const char*)(aObj["target"] | "all");
                            a.wledPreset = aObj["preset"] | 1;
                            s.actions.push_back(a);
                        }
                    }
                }
                p.steps.push_back(s);
            }
        }
        progs.push_back(p);
    }

    if (!hasDispatch) {
        HallProgram dispProg;
        dispProg.hallId = RUNLOOP_DISPATCH_HALL_ID;
        dispProg.name = "Dispatch";
        dispProg.enabled = true;
        dispProg.wledPreset = 0;
        dispProg.lockoutMs = RUNLOOP_DEFAULT_DISPATCH_LOCKOUT_MS;
        progs.insert(progs.begin(), dispProg);
    }

    _programs = progs;
    resetTrainPositions();
    (void)saveConfig();
    return true;
}

bool RunLoopEngine::loadConfig() {
    RunLoopLock lock(_mutex);
    String path = getConfigPath();
    if (!LittleFS.exists(path)) {
        return false;
    }

    File f = LittleFS.open(path, "r");
    if (!f) {
        return false;
    }

    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, f);
    f.close();

    if (err) {
        return false;
    }
    return deserializeConfig(doc);
}

bool RunLoopEngine::saveConfig() {
    RunLoopLock lock(_mutex);
    JsonDocument doc;
    serializeConfig(doc);

    String path = getConfigPath();
    File f = LittleFS.open(path, "w");
    if (!f) {
        return false;
    }

    (void)serializeJson(doc, f);
    f.close();
    return true;
}
