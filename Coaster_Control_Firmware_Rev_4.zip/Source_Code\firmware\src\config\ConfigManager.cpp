#include "ConfigManager.h"
#include "../pins.h"

ConfigManager& ConfigManager::instance() {
    static ConfigManager inst;
    return inst;
}

ConfigManager::ConfigManager() {
    _config.wifiSsid = DEFAULT_WIFI_SSID;
    _config.wifiPassword = DEFAULT_WIFI_PASS;
    _config.wifiMode = (_config.wifiSsid.length() > 0) ? "home" : "coaster";
    _config.apSsid = DEFAULT_AP_SSID;
    _config.apPassword = DEFAULT_AP_PASS;
    _config.hostname = DEFAULT_HOSTNAME;
    _config.apAlwaysOn = DEFAULT_AP_ALWAYS_ON;
    _config.simMode = false;
    _config.duelingMode = false;
    _config.hallDebounceMs = 1500;
}

bool ConfigManager::begin() {
    if (!LittleFS.begin(true)) { // true = formatOnFail
        return false;
    }
    return load();
}

bool ConfigManager::load() {
    if (!LittleFS.exists("/config.json")) {
        return save(); // Save defaults
    }

    File f = LittleFS.open("/config.json", "r");
    if (!f) return false;

    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, f);
    f.close();

    if (err) return false;

    if (doc["wifiMode"].is<String>()) _config.wifiMode = doc["wifiMode"].as<String>();
    if (doc["wifiSsid"].is<String>()) _config.wifiSsid = doc["wifiSsid"].as<String>();
    if (doc["wifiPassword"].is<String>()) _config.wifiPassword = doc["wifiPassword"].as<String>();
    if (doc["apSsid"].is<String>()) _config.apSsid = doc["apSsid"].as<String>();
    if (doc["apPassword"].is<String>()) _config.apPassword = doc["apPassword"].as<String>();
    if (doc["hostname"].is<String>()) _config.hostname = doc["hostname"].as<String>();
    if (doc["apAlwaysOn"].is<bool>()) {
        _config.apAlwaysOn = doc["apAlwaysOn"].as<bool>();
    } else {
        _config.apAlwaysOn = DEFAULT_AP_ALWAYS_ON;
    }
    if (doc["simMode"].is<bool>()) _config.simMode = doc["simMode"].as<bool>();
    if (doc["duelingMode"].is<bool>()) _config.duelingMode = doc["duelingMode"].as<bool>();
    if (doc["hallDebounceMs"].is<uint32_t>()) _config.hallDebounceMs = doc["hallDebounceMs"].as<uint32_t>();

    // Seed or override from pins.h if pre-flash credentials were provided
    String compiledSsid = doc["compiledSsid"] | "";
    bool needsSave = false;
#if FORCE_PINS_WIFI_CONFIG
    if (String(DEFAULT_WIFI_SSID).length() > 0) {
        _config.wifiSsid = DEFAULT_WIFI_SSID;
        _config.wifiPassword = DEFAULT_WIFI_PASS;
        _config.wifiMode = "home";
        if (String(DEFAULT_AP_SSID).length() > 0) _config.apSsid = DEFAULT_AP_SSID;
        if (String(DEFAULT_AP_PASS).length() > 0) _config.apPassword = DEFAULT_AP_PASS;
        if (String(DEFAULT_HOSTNAME).length() > 0) _config.hostname = DEFAULT_HOSTNAME;
        needsSave = true;
    }
#else
    if (String(DEFAULT_WIFI_SSID).length() > 0) {
        if (_config.wifiSsid.length() == 0 || compiledSsid != String(DEFAULT_WIFI_SSID)) {
            _config.wifiSsid = DEFAULT_WIFI_SSID;
            _config.wifiPassword = DEFAULT_WIFI_PASS;
            _config.wifiMode = "home";
            if (String(DEFAULT_AP_SSID).length() > 0) _config.apSsid = DEFAULT_AP_SSID;
            if (String(DEFAULT_AP_PASS).length() > 0) _config.apPassword = DEFAULT_AP_PASS;
            if (String(DEFAULT_HOSTNAME).length() > 0) _config.hostname = DEFAULT_HOSTNAME;
            needsSave = true;
        }
    }
#endif

    if (needsSave) {
        save();
    }

    return true;
}

bool ConfigManager::save() {
    JsonDocument doc;
    doc["wifiMode"] = _config.wifiMode;
    doc["wifiSsid"] = _config.wifiSsid;
    doc["wifiPassword"] = _config.wifiPassword;
    doc["apSsid"] = _config.apSsid;
    doc["apPassword"] = _config.apPassword;
    doc["hostname"] = _config.hostname;
    doc["apAlwaysOn"] = _config.apAlwaysOn;
    doc["simMode"] = _config.simMode;
    doc["duelingMode"] = _config.duelingMode;
    doc["hallDebounceMs"] = _config.hallDebounceMs;
    doc["compiledSsid"] = DEFAULT_WIFI_SSID;

    File f = LittleFS.open("/config.json", "w");
    if (!f) return false;

    serializeJson(doc, f);
    f.close();
    return true;
}
