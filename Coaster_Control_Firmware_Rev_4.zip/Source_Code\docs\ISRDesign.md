# Interrupt Service Routine (ISR) Design (`embedded-isr-design`)

## ISR Summary Table

| Interrupt Handler | Trigger Source | Attributes | Execution Time Budget | Measured / Worst-Case Latency | Shared Variables |
|---|---|---|---|---|---|
| `hall_gpio_isr_handler(void* arg)` | GPIO `FALLING` edge on Hall Pins `1..12` (`GPIO 13, 47, 41, 2, 1, 44, 14, 21, 40, 42, 17, 16`) | `IRAM_ATTR` | `< 5 µs` (GPIO ISR target) | `< 1.5 µs` | `s_isrHallEdgeMask` (`volatile uint16_t`), protected by `s_hallIsrMux` (`portMUX_TYPE`) |

---

## Core Design Principle: "Fast In, Fast Out"

When a K'NEX coaster train passes over an A3144 Hall effect sensor at high speed (e.g., bottom of a drop or launch section), the magnetic pulse can be brief.

To guarantee zero missed train passes while keeping interrupt latency near zero:

1. **Minimal ISR Workload (`hall_gpio_isr_handler` in [`RealIO.cpp`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/RealIO.cpp))**:
   ```cpp
   static portMUX_TYPE s_hallIsrMux = portMUX_INITIALIZER_UNLOCKED;
   static volatile uint16_t s_isrHallEdgeMask = 0U;

   static void IRAM_ATTR hall_gpio_isr_handler(void* arg) {
       uint32_t hallIdx = (uint32_t)(uintptr_t)arg;
       if (hallIdx < (uint32_t)NUM_HALLS) {
           portENTER_CRITICAL_ISR(&s_hallIsrMux);
           s_isrHallEdgeMask |= (uint16_t)(1U << hallIdx);
           portEXIT_CRITICAL_ISR(&s_hallIsrMux);
       }
   }
   ```
2. **Strictly Forbidden in ISR (Verified Absent)**:
   - No `Serial.printf` / logging calls
   - No `malloc` / `free` / `String` construction
   - No floating-point calculations
   - No JSON serialization or WLED network calls
   - No direct motor/servo HAL writes inside ISR

---

## Deferred Processing Flow

```text
[A3144 Hall Sensor Pin Goes LOW]
               │
               ▼
   hall_gpio_isr_handler (IRAM_ATTR, < 1.5 µs)
   Sets bit (1U << hallIdx) in s_isrHallEdgeMask
               │
               ▼ (Atomic fetch & clear via portENTER_CRITICAL)
   RealIO::update() [ControlTask @ 500 Hz / 2 ms]
   1. Checks multi-magnet train debounce lockout (default 1500 ms)
   2. Increments _halls[i].count & sets 350 ms UI visual pulse
   3. Invokes _hallCallback(hallId) in task context
               │
               ▼
   RunLoopEngine::onHallTriggered(hallId)
   Executes Stage 0 actions (Motors, Servos, WLED queue)
```

