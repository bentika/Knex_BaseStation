import { useEffect } from 'react'
import { AppShell } from './components/AppShell'
import { useRoute } from './hooks/useRoute'
import { ManualPage } from './pages/ManualPage'
import { SettingsPage } from './pages/SettingsPage'
import { RunLoopPage } from './pages/RunLoopPage'
import { PanelPage } from './pages/PanelPage'
import { WledPage } from './pages/WledPage'
import { useBoard } from './store/boardStore'

export default function App() {
  const route = useRoute()
  const start = useBoard((s) => s.start)
  const dueling = useBoard((s) => s.state?.duelingMode ?? false)

  useEffect(() => {
    start()
  }, [start])

  return (
    <AppShell route={route}>
      {route === 'manual' && <ManualPage />}
      {route === 'settings' && <SettingsPage />}
      {route === 'run' && (dueling ? <RunLoopPage coaster="a" /> : <RunLoopPage />)}
      {route === 'run-a' && <RunLoopPage coaster="a" />}
      {route === 'run-b' && <RunLoopPage coaster="b" />}
      {route === 'panel' && <PanelPage />}
      {route === 'wled' && <WledPage />}
    </AppShell>
  )
}
