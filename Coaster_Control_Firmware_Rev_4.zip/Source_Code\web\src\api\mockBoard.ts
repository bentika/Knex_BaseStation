import type { Link, LinkHandlers, UploadTarget } from './link'
import {
  HALL_COUNT,
  MOTOR_COUNT,
  SERVO_COUNT,
  type BoardEvent,
  type BoardInfo,
  type BoardState,
  type Command,
  type EventKind,
  type HardwareInfo,
  type PanelConfig,
  type PanelStatus,
  type RunLoopConfig,
  type SystemConfig,
  type WifiConfig,
  type WifiNetwork,
  type WledConfig,
} from './types'

/**
 * Simulation level A: a fake board that runs entirely in the browser.
 * It follows the same rules as the firmware (ESTOP latch, hall lockout,
 * ramps, direction change through zero) so the UI behaves identically.
 */

const TICK_MS = 20
const BROADCAST_MS = 100
const HALL_PULSE_MS = 250

const HW: HardwareInfo = {
  motors: Array.from({ length: MOTOR_COUNT }, (_, i) => ({
    id: i + 1,
    name: `Motor ${i + 1}`,
    reversible: i < 2,
    driver: i < 2 ? ('hbridge' as const) : ('fet' as const),
  })),
  servos: Array.from({ length: SERVO_COUNT }, (_, i) => ({ id: i + 1, name: `Servo ${i + 1}`, home: 0 })),
  halls: Array.from({ length: HALL_COUNT }, (_, i) => ({ id: i + 1, name: `Hall ${i + 1}`, lockoutMs: 500 })),
}

interface MotorSim {
  pwm: number
  target: number
  dir: 'fwd' | 'rev'
  pendingDir: 'fwd' | 'rev' | null
  /** % per ms; 0 = jump immediately */
  rate: number
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

export class MockBoard implements Link {
  readonly kind = 'mock' as const
  private handlers: LinkHandlers | null = null
  private timers: number[] = []
  private start = performance.now()
  private eventId = 0
  private events: BoardEvent[] = []
  private dirty = true

  private estop = false
  private motors: MotorSim[] = Array.from({ length: MOTOR_COUNT }, () => ({
    pwm: 0,
    target: 0,
    dir: 'fwd',
    pendingDir: null,
    rate: 0,
  }))
  private servos = Array.from({ length: SERVO_COUNT }, () => ({ angle: 0, target: 0, speed: 0 }))
  private hallActiveUntil: number[] = Array(HALL_COUNT).fill(0)
  private hallLastTrigger: number[] = Array(HALL_COUNT).fill(-1e9)
  private hallCounts: number[] = Array(HALL_COUNT).fill(0)

  private wifi: WifiConfig = {
    mode: 'home',
    ssid: 'Workshop-WiFi',
    hasPassword: true,
    apSsid: 'Coaster-Setup',
    hostname: 'coaster',
  }
  private system: SystemConfig = { sim: true, duelingMode: false, hallDebounceMs: 1500 }

  // Simulated RunLoop State
  private runloopRunning = false
  private activeHall = -1
  private activeStep = -1
  private waitingDispatch = false
  private stepStartMs = 0
  private stepDurationMs = 0
  private autoStopMotors: { motorId: number; stopAtMs: number }[] = []

  private runloopRunningB = false
  private activeHallB = -1
  private activeStepB = -1
  private waitingDispatchB = false
  private stepStartMsB = 0
  private stepDurationMsB = 0

  private trainCount: 1 | 2 = 1
  private trainCountA: 1 | 2 = 1
  private trainCountB: 1 | 2 = 1
  private trains: import('./types').TrainTrackerStatus[] = [
    { id: 1, currentHall: 1, nextHall: 2, held: false },
    { id: 2, currentHall: 4, nextHall: 1, held: false },
  ]
  private trainsB: import('./types').TrainTrackerStatus[] = [
    { id: 1, currentHall: 1, nextHall: 2, held: false },
    { id: 2, currentHall: 4, nextHall: 1, held: false },
  ]

  private programsA: import('./types').HallProgram[] = [
    { id: 0, name: 'Dispatch', enabled: true, wledPreset: 0, lockoutMs: 500, steps: [] },
    ...Array.from({ length: 6 }, (_, i) => ({
      id: i + 1,
      name: `Hall ${i + 1}`,
      enabled: true,
      wledPreset: 0,
      lockoutMs: 500,
      steps: [],
    })),
  ]

  private programsB: import('./types').HallProgram[] = [
    { id: 0, name: 'Dispatch', enabled: true, wledPreset: 0, lockoutMs: 500, steps: [] },
    ...Array.from({ length: 6 }, (_, i) => ({
      id: i + 1,
      name: `Hall ${i + 1}`,
      enabled: true,
      wledPreset: 0,
      lockoutMs: 500,
      steps: [],
    })),
  ]

  private programs: import('./types').HallProgram[] = [
    { id: 0, name: 'Dispatch', enabled: true, wledPreset: 0, lockoutMs: 500, steps: [] },
    ...Array.from({ length: 12 }, (_, i) => ({
      id: i + 1,
      name: `Hall ${i + 1}`,
      enabled: true,
      wledPreset: 0,
      lockoutMs: 500,
      steps: [],
    })),
  ]

  // Simulated WLED
  private wledDevices: import('./types').WledDevice[] = [
    { id: 'train1', name: 'Train #1', ip: '192.168.0.130', enabled: true },
    { id: 'scenery', name: 'Track Scenery', ip: '192.168.0.131', enabled: true },
  ]

  // Simulated Panel
  private panelPins: import('./types').PanelPinConfig[] = [
    { pin: 0, action: 'dispatch', label: 'Dispatch', pressed: false },
    { pin: 1, action: 'servoToggle_1', label: 'Servo 1', pressed: false },
    { pin: 2, action: 'motorToggle_2', label: 'Motor 2', pressed: false },
    { pin: 3, action: 'estop', label: 'Emergency Stop', pressed: false },
    { pin: 4, action: 'startStopLoop', label: 'Run Loop Toggle', pressed: false },
    ...Array.from({ length: 11 }, (_, i) => ({
      pin: i + 5,
      action: 'none',
      label: `Panel Button ${i + 6}`,
      pressed: false,
    })),
  ]

  private now = () => Math.round(performance.now() - this.start)

  connect(handlers: LinkHandlers): void {
    this.handlers = handlers
    handlers.onStatus('connecting')
    const t = window.setTimeout(() => {
      handlers.onStatus('online')
      if (this.events.length === 0) {
        this.log('system', 'Simulated board ready – no hardware connected')
      }
      handlers.onMessage({ t: 'events', d: this.events })
      this.timers.push(window.setInterval(() => this.tick(), TICK_MS))
      this.timers.push(window.setInterval(() => this.broadcast(), BROADCAST_MS))
    }, 350)
    this.timers.push(t)
  }

  disconnect(): void {
    this.timers.forEach((t) => {
      window.clearInterval(t)
      window.clearTimeout(t)
    })
    this.timers = []
    this.handlers?.onStatus('offline')
  }

  // ---------------------------------------------------------------- commands
  send(cmd: Command): void {
    switch (cmd.c) {
      case 'motor':
        return this.cmdMotor(cmd.id, cmd.pwm, cmd.dir, cmd.rampMs)
      case 'motorStop':
        return this.stopMotor(cmd.id - 1, true)
      case 'allStop':
        this.motors.forEach((_, i) => this.stopMotor(i, false))
        return this.log('motor', 'All motors stopped')
      case 'servo':
        return this.cmdServo(cmd.id, cmd.angle, cmd.speed)
      case 'simHall':
        return this.triggerHall(cmd.id - 1, true, false)
      case 'estop':
        if (this.estop) return
        this.estop = true
        this.motors.forEach((_, i) => this.stopMotor(i, false))
        this.runloopRunning = false
        this.activeHall = -1
        this.activeStep = -1
        this.waitingDispatch = false
        return this.log('error', 'E-STOP activated – all motors stopped')
      case 'reset':
        if (!this.estop) return
        this.estop = false
        return this.log('system', 'E-STOP reset – system ready')
      case 'resetCounts':
        this.hallCounts.fill(0)
        this.dirty = true
        return this.log('hall', 'Hall counters reset')
      case 'dispatch':
      case 'dispatchA':
      case 'dispatchBoth':
        if (this.waitingDispatch) {
          this.waitingDispatch = false
          this.log('system', 'Coaster A train dispatched manually')
          this.executeMockStep(this.activeStep + 1, this.system.duelingMode ? 'a' : 'single')
        } else {
          this.triggerDispatchProgram(this.system.duelingMode ? 'a' : 'single')
        }
        if (cmd.c === 'dispatchBoth' || (cmd.c === 'dispatch' && this.system.duelingMode)) {
          if (this.waitingDispatchB) {
            this.waitingDispatchB = false
            this.log('system', 'Coaster B train dispatched manually')
            this.executeMockStep(this.activeStepB + 1, 'b')
          } else {
            this.triggerDispatchProgram('b')
          }
        }
        return
      case 'dispatchB':
        if (this.waitingDispatchB) {
          this.waitingDispatchB = false
          this.log('system', 'Coaster B train dispatched manually')
          this.executeMockStep(this.activeStepB + 1, 'b')
        } else {
          this.triggerDispatchProgram('b')
        }
        return
      case 'startLoop':
      case 'startLoopA':
        this.runloopRunning = true
        if (cmd.c === 'startLoop' && this.system.duelingMode) this.runloopRunningB = true
        this.dirty = true
        return this.log('system', 'Run loop started')
      case 'startLoopB':
        this.runloopRunningB = true
        this.dirty = true
        return this.log('system', 'Coaster B run loop started')
      case 'stopLoop':
      case 'stopLoopA':
        this.runloopRunning = false
        this.activeHall = -1
        this.activeStep = -1
        this.waitingDispatch = false
        if (cmd.c === 'stopLoop' && this.system.duelingMode) {
          this.runloopRunningB = false
          this.activeHallB = -1
          this.activeStepB = -1
          this.waitingDispatchB = false
          for (let m = 0; m < MOTOR_COUNT; m++) this.stopMotor(m, false)
        } else if (this.system.duelingMode) {
          for (let m = 0; m < 3; m++) this.stopMotor(m, false)
        } else {
          for (let m = 0; m < MOTOR_COUNT; m++) this.stopMotor(m, false)
        }
        this.dirty = true
        return this.log('system', 'Run loop stopped')
      case 'stopLoopB':
        this.runloopRunningB = false
        this.activeHallB = -1
        this.activeStepB = -1
        this.waitingDispatchB = false
        for (let m = 3; m < 6; m++) this.stopMotor(m, false)
        this.dirty = true
        return this.log('system', 'Coaster B run loop stopped')
      case 'resetLoop':
      case 'resetLoopA':
        this.activeHall = -1
        this.activeStep = -1
        this.waitingDispatch = false
        if (cmd.c === 'resetLoop' && this.system.duelingMode) {
          this.activeHallB = -1
          this.activeStepB = -1
          this.waitingDispatchB = false
          for (let m = 0; m < MOTOR_COUNT; m++) this.stopMotor(m, false)
        } else if (this.system.duelingMode) {
          for (let m = 0; m < 3; m++) this.stopMotor(m, false)
        } else {
          for (let m = 0; m < MOTOR_COUNT; m++) this.stopMotor(m, false)
        }
        this.dirty = true
        return this.log('system', 'Run loop reset')
      case 'resetLoopB':
        this.activeHallB = -1
        this.activeStepB = -1
        this.waitingDispatchB = false
        for (let m = 3; m < 6; m++) this.stopMotor(m, false)
        this.dirty = true
        return this.log('system', 'Coaster B run loop reset')
      case 'testHall':
      case 'testHallA':
        if (cmd.id === 0) {
          return this.triggerDispatchProgram(this.system.duelingMode ? 'a' : 'single')
        }
        this.runloopRunning = true
        return this.triggerHall(cmd.id - 1, true, true)
      case 'testHallB':
        if (cmd.id === 0) {
          return this.triggerDispatchProgram('b')
        }
        this.runloopRunningB = true
        return this.triggerHall(cmd.id - 1 + 6, true, true)
      case 'triggerWled':
        return this.log('system', `WLED preset ${cmd.preset} triggered on ${cmd.target ?? 'all'}`)
    }
  }

  private cmdMotor(id: number, pwm: number, dir?: 'fwd' | 'rev', rampMs = 0) {
    const m = this.motors[id - 1]
    if (!m) return
    if (this.estop) return this.log('warn', `Motor ${id} ignored – E-STOP is active`)
    const reversible = HW.motors[id - 1].reversible
    const wantDir = reversible && dir ? dir : 'fwd'
    const target = Math.max(0, Math.min(100, Math.round(pwm)))
    m.rate = rampMs > 0 ? 100 / rampMs : 0
    if (wantDir !== m.dir && m.pwm > 0) {
      // Never slam a reversing gearbox: go through zero first.
      m.pendingDir = wantDir
      m.target = 0
      m.rate = m.rate || 100 / 150
      this.pendingTargets[id - 1] = target
    } else {
      m.dir = wantDir
      m.target = target
      if (m.rate === 0) m.pwm = target
    }
    this.dirty = true
    this.log('motor', `Motor ${id} → ${target}%${reversible ? ` ${wantDir.toUpperCase()}` : ''}`)
  }

  private pendingTargets: number[] = Array(MOTOR_COUNT).fill(0)

  private stopMotor(i: number, logIt: boolean) {
    const m = this.motors[i]
    if (!m) return
    m.target = 0
    m.pwm = 0
    m.pendingDir = null
    this.dirty = true
    if (logIt) this.log('motor', `Motor ${i + 1} stopped`)
  }

  private cmdServo(id: number, angle: number, speed?: number) {
    const s = this.servos[id - 1]
    if (!s) return
    s.target = Math.max(0, Math.min(180, Math.round(angle)))
    s.speed = speed && speed > 0 ? speed : 0
    if (!s.speed) s.angle = s.target
    this.dirty = true
    this.log('servo', `Servo ${id} → ${s.target}°`)
  }

  private triggerDispatchProgram(coaster: 'a' | 'b' | 'single' = 'single') {
    if (this.estop) return
    const isB = coaster === 'b'
    const progs = isB ? this.programsB : coaster === 'a' ? this.programsA : this.programs
    const prog = progs.find((p) => p.id === 0 && p.enabled)
    if (!prog) return
    if (isB) {
      this.runloopRunningB = true
      if (prog.wledPreset > 0) this.log('system', `WLED preset ${prog.wledPreset} triggered by Coaster B Dispatch`)
      if (prog.steps.length > 0) {
        this.activeHallB = 0
        this.log('system', 'Coaster B Dispatch sequence triggered')
        this.executeMockStep(0, 'b')
      } else {
        this.log('system', 'Coaster B Dispatch pressed (no stages configured on Dispatch block)')
      }
    } else {
      this.runloopRunning = true
      if (prog.wledPreset > 0) this.log('system', `WLED preset ${prog.wledPreset} triggered by Dispatch`)
      if (prog.steps.length > 0) {
        this.activeHall = 0
        this.log('system', 'Dispatch sequence triggered')
        this.executeMockStep(0, coaster)
      } else {
        this.log('system', 'Dispatch pressed (no stages configured on Dispatch block)')
      }
    }
    this.dirty = true
  }

  private triggerHall(i: number, simulated: boolean, triggerRunLoop = true) {
    if (i < 0 || i >= HALL_COUNT) return
    const now = this.now()
    const lockout = triggerRunLoop ? (this.system.hallDebounceMs ?? HW.halls[i].lockoutMs ?? 1500) : 250
    if (now - this.hallLastTrigger[i] < lockout) return
    this.hallLastTrigger[i] = now
    this.hallActiveUntil[i] = now + HALL_PULSE_MS
    this.hallCounts[i]++
    this.dirty = true
    this.log('hall', `Hall ${i + 1} triggered${simulated ? ' (simulated)' : ''}`)
    if (triggerRunLoop) {
      this.onMockHall(i + 1)
    }
  }

  private getNextActiveHall(progs: import('./types').HallProgram[], hallId: number): number {
    const active = progs.filter((p) => p.id > 0 && p.enabled).map((p) => p.id)
    if (active.length === 0) return hallId
    const idx = active.indexOf(hallId)
    if (idx === -1) return active[0]
    return active[(idx + 1) % active.length]
  }

  private resetMockTrainPositions(progs: import('./types').HallProgram[], isB = false) {
    const active = progs.filter((p) => p.id > 0 && p.enabled).map((p) => p.id)
    const target = isB ? this.trainsB : this.trains
    if (active.length === 0) {
      target[0] = { id: 1, currentHall: 1, nextHall: 2, held: false }
      target[1] = { id: 2, currentHall: 2, nextHall: 1, held: false }
      return
    }
    if (active.length === 1) {
      target[0] = { id: 1, currentHall: active[0], nextHall: active[0], held: false }
      target[1] = { id: 2, currentHall: active[0], nextHall: active[0], held: false }
      return
    }
    target[0] = { id: 1, currentHall: active[0], nextHall: active[1], held: false }
    const lastH = active[active.length - 1]
    target[1] = { id: 2, currentHall: lastH, nextHall: active[0], held: false }
  }

  private updateMockBlockZone(
    progs: import('./types').HallProgram[],
    hallId: number,
    isB = false
  ): boolean {
    const tCount = isB ? this.trainCountB : (this.system.duelingMode ? this.trainCountA : this.trainCount)
    const tr = isB ? this.trainsB : this.trains
    const nextH = this.getNextActiveHall(progs, hallId)
    const prog = progs.find((p) => p.id === hallId && p.enabled)

    if (tCount <= 1) {
      tr[0] = { id: 1, currentHall: hallId, nextHall: nextH, held: false }
      return true
    }

    let arrivingIdx = 0
    if (tr[0].nextHall === hallId && !tr[0].held) arrivingIdx = 0
    else if (tr[1].nextHall === hallId && !tr[1].held) arrivingIdx = 1
    else if (tr[0].currentHall === hallId) arrivingIdx = 0
    else if (tr[1].currentHall === hallId) arrivingIdx = 1

    const otherIdx = arrivingIdx === 0 ? 1 : 0
    tr[arrivingIdx] = { id: arrivingIdx + 1, currentHall: hallId, nextHall: nextH, held: false }

    // Step A: Check if other train was held waiting for its zone ahead to clear
    if (tr[otherIdx].held && tr[arrivingIdx].currentHall !== tr[otherIdx].currentHall) {
      const holdH = tr[otherIdx].currentHall
      tr[otherIdx].held = false
      tr[otherIdx].nextHall = this.getNextActiveHall(progs, holdH)
      const holdProg = progs.find((p) => p.id === holdH && p.enabled)
      if (holdProg) {
        if (holdProg.blockServoId && holdProg.blockServoId >= 1) {
          this.cmdServo(holdProg.blockServoId, holdProg.blockReleaseAngle ?? 90, 100)
        }
        if (holdProg.blockMotorId && holdProg.blockMotorId >= 1) {
          this.cmdMotor(holdProg.blockMotorId, holdProg.blockMotorPwm ?? 100, holdProg.blockMotorDir ?? 'fwd')
        }
        this.log('system', `Block Zone ${holdH}→${tr[otherIdx].nextHall} CLEAR — Train ${otherIdx + 1} released from H${holdH}!`)
      }
    }

    // Step B: Check if block ahead of hallId is occupied by other train
    const nextOccupied =
      tr[otherIdx].currentHall === hallId ||
      (tr[otherIdx].currentHall === nextH && tr[otherIdx].held)

    if (nextOccupied && prog?.isBlockHold) {
      tr[arrivingIdx].held = true
      if (prog.blockMotorId && prog.blockMotorId >= 1) {
        this.stopMotor(prog.blockMotorId - 1, true)
      }
      if (prog.blockServoId && prog.blockServoId >= 1) {
        this.cmdServo(prog.blockServoId, prog.blockHoldAngle ?? 0, 100)
      }
      this.log('warn', `Block Zone H${hallId}→H${nextH} OCCUPIED — Holding Train ${arrivingIdx + 1} at H${hallId}`)
      return false
    }

    if (prog?.isBlockHold && prog.steps.length === 0) {
      if (prog.blockServoId && prog.blockServoId >= 1) {
        this.cmdServo(prog.blockServoId, prog.blockReleaseAngle ?? 90, 100)
      }
      if (prog.blockMotorId && prog.blockMotorId >= 1) {
        this.cmdMotor(prog.blockMotorId, prog.blockMotorPwm ?? 100, prog.blockMotorDir ?? 'fwd')
      }
    }
    return true
  }

  private onMockHall(hallId: number) {
    if (this.estop) return
    const dueling = this.system.duelingMode ?? false
    if (dueling) {
      if (hallId <= 6) {
        if (!this.runloopRunning) return
        const prog = this.programsA.find((p) => p.id === hallId && p.enabled)
        if (!prog) return
        if (!this.updateMockBlockZone(this.programsA, hallId, false)) {
          this.dirty = true
          return
        }
        if (prog.wledPreset > 0) this.log('system', `WLED preset ${prog.wledPreset} triggered by Coaster A Hall ${hallId}`)
        this.activeHall = hallId
        this.executeMockStep(0, 'a')
      } else {
        if (!this.runloopRunningB) return
        const bid = hallId - 6
        const prog = this.programsB.find((p) => p.id === bid && p.enabled)
        if (!prog) return
        if (!this.updateMockBlockZone(this.programsB, bid, true)) {
          this.dirty = true
          return
        }
        if (prog.wledPreset > 0) this.log('system', `WLED preset ${prog.wledPreset} triggered by Coaster B Hall ${bid}`)
        this.activeHallB = bid
        this.executeMockStep(0, 'b')
      }
    } else {
      if (!this.runloopRunning) return
      const prog = this.programs.find((p) => p.id === hallId && p.enabled)
      if (!prog) return
      if (!this.updateMockBlockZone(this.programs, hallId, false)) {
        this.dirty = true
        return
      }
      if (prog.wledPreset > 0) this.log('system', `WLED preset ${prog.wledPreset} triggered by Hall ${hallId}`)
      this.activeHall = hallId
      this.executeMockStep(0, 'single')
    }
  }

  private executeMockStep(stepIdx: number, coaster: 'a' | 'b' | 'single' = 'single') {
    const isB = coaster === 'b'
    const progs = isB ? this.programsB : coaster === 'a' ? this.programsA : this.programs
    const activeH = isB ? this.activeHallB : this.activeHall
    const prog = progs.find((p) => p.id === activeH)

    if (!prog || stepIdx >= prog.steps.length) {
      if (isB) {
        this.activeHallB = -1
        this.activeStepB = -1
        this.waitingDispatchB = false
        this.stepDurationMsB = 0
      } else {
        this.activeHall = -1
        this.activeStep = -1
        this.waitingDispatch = false
        this.stepDurationMs = 0
      }
      this.dirty = true
      return
    }

    if (isB) {
      this.activeStepB = stepIdx
      this.stepStartMsB = this.now()
      this.waitingDispatchB = false
    } else {
      this.activeStep = stepIdx
      this.stepStartMs = this.now()
      this.waitingDispatch = false
    }
    this.dirty = true

    const step = prog.steps[stepIdx]
    let maxDur = step.delayMs ?? 0

    for (const act of step.actions) {
      if (act.type === 'motor') {
        const id = act.motor ?? (isB ? 5 : 2)
        const pwm = act.pwm ?? 100
        const dir = act.dir ?? 'fwd'
        if (act.op === 'start') {
          this.cmdMotor(id, pwm, dir)
        } else if (act.op === 'stop') {
          this.stopMotor(id - 1, true)
        } else if (act.op === 'runTime') {
          this.cmdMotor(id, pwm, dir)
          const dur = act.durationMs ?? 2000
          this.autoStopMotors.push({ motorId: id, stopAtMs: this.now() + dur })
          if (dur > maxDur) maxDur = dur
        }
      } else if (act.type === 'servo') {
        const id = act.servo ?? (isB ? 4 : 1)
        const angle = act.angle ?? 90
        const speed = act.speed ?? 100
        this.cmdServo(id, angle, speed)
        const dur = act.durationMs ?? 500
        if (dur > maxDur) maxDur = dur
      } else if (act.type === 'delay') {
        const dur = act.durationMs ?? 1000
        if (dur > maxDur) maxDur = dur
      } else if (act.type === 'waitDispatch') {
        if (isB) {
          this.waitingDispatchB = true
          this.stepDurationMsB = act.timeoutMs ?? 10000
        } else {
          this.waitingDispatch = true
          this.stepDurationMs = act.timeoutMs ?? 10000
        }
        this.log('system', `Waiting for ${isB ? 'Coaster B' : 'Coaster A'} DISPATCH button or timeout...`)
        return
      } else if (act.type === 'wled') {
        if (act.preset) {
          this.log('system', `WLED preset ${act.preset} sent to ${act.target ?? 'all'}`)
        }
      }
    }

    if (stepIdx + 1 < prog.steps.length && (prog.steps[stepIdx + 1].delayMs ?? 0) > maxDur) {
      maxDur = prog.steps[stepIdx + 1].delayMs ?? 0
    }

    if (isB) {
      this.stepDurationMsB = maxDur
    } else {
      this.stepDurationMs = maxDur
    }
  }

  // -------------------------------------------------------------- simulation
  private tick() {
    const now = this.now()

    // Auto-stop motors whose runTime has expired
    this.autoStopMotors = this.autoStopMotors.filter((m) => {
      if (now >= m.stopAtMs) {
        this.stopMotor(m.motorId - 1, false)
        return false
      }
      return true
    })

    // Advance Coaster A / single step
    if (this.activeHall >= 0 && this.activeStep >= 0 && !this.waitingDispatch) {
      if (now - this.stepStartMs >= this.stepDurationMs) {
        this.executeMockStep(this.activeStep + 1, this.system.duelingMode ? 'a' : 'single')
      }
    } else if (this.activeHall >= 0 && this.activeStep >= 0 && this.waitingDispatch) {
      if (this.stepDurationMs > 0 && now - this.stepStartMs >= this.stepDurationMs) {
        this.waitingDispatch = false
        this.executeMockStep(this.activeStep + 1, this.system.duelingMode ? 'a' : 'single')
      }
    }

    // Advance Coaster B step
    if (this.system.duelingMode) {
      if (this.activeHallB >= 0 && this.activeStepB >= 0 && !this.waitingDispatchB) {
        if (now - this.stepStartMsB >= this.stepDurationMsB) {
          this.executeMockStep(this.activeStepB + 1, 'b')
        }
      } else if (this.activeHallB >= 0 && this.activeStepB >= 0 && this.waitingDispatchB) {
        if (this.stepDurationMsB > 0 && now - this.stepStartMsB >= this.stepDurationMsB) {
          this.waitingDispatchB = false
          this.executeMockStep(this.activeStepB + 1, 'b')
        }
      }
    }

    for (let i = 0; i < this.motors.length; i++) {
      const m = this.motors[i]
      if (m.pwm !== m.target) {
        const step = m.rate > 0 ? m.rate * TICK_MS : 100
        m.pwm = m.pwm < m.target ? Math.min(m.target, m.pwm + step) : Math.max(m.target, m.pwm - step)
        this.dirty = true
      }
      if (m.pendingDir && m.pwm === 0) {
        m.dir = m.pendingDir
        m.pendingDir = null
        m.target = this.pendingTargets[i]
        this.dirty = true
      }
    }
    for (const s of this.servos) {
      if (s.angle !== s.target && s.speed > 0) {
        const step = (s.speed * TICK_MS) / 1000
        s.angle = s.angle < s.target ? Math.min(s.target, s.angle + step) : Math.max(s.target, s.angle - step)
        this.dirty = true
      }
    }
    if (this.hallActiveUntil.some((t) => t > 0 && t <= now)) {
      this.hallActiveUntil = this.hallActiveUntil.map((t) => (t <= now ? 0 : t))
      this.dirty = true
    }
  }

  private snapshot(): BoardState {
    const now = this.now()
    const dueling = this.system.duelingMode ?? false
    const tCountA = dueling ? this.trainCountA : this.trainCount
    const rls = {
      running: this.runloopRunning,
      activeHall: this.activeHall >= 0 ? this.activeHall : 0,
      activeStep: this.activeStep,
      totalSteps: this.activeHall >= 0 ? ((dueling ? this.programsA : this.programs).find((p) => p.id === this.activeHall)?.steps.length ?? 0) : 0,
      waitingDispatch: this.waitingDispatch,
      stepDurationMs: this.stepDurationMs,
      elapsedStepMs: this.activeStep >= 0 ? Math.max(0, now - this.stepStartMs) : 0,
      trainCount: tCountA,
      trains: this.trains.slice(0, tCountA),
    }
    const rlsB = {
      running: this.runloopRunningB,
      activeHall: this.activeHallB >= 0 ? this.activeHallB : 0,
      activeStep: this.activeStepB,
      totalSteps: this.activeHallB >= 0 ? (this.programsB.find((p) => p.id === this.activeHallB)?.steps.length ?? 0) : 0,
      waitingDispatch: this.waitingDispatchB,
      stepDurationMs: this.stepDurationMsB,
      elapsedStepMs: this.activeStepB >= 0 ? Math.max(0, now - this.stepStartMsB) : 0,
      trainCount: this.trainCountB,
      trains: this.trainsB.slice(0, this.trainCountB),
    }
    return {
      ms: now,
      estop: this.estop,
      sim: true,
      duelingMode: dueling,
      halls: this.hallActiveUntil.map((t) => t > now),
      hallCounts: [...this.hallCounts],
      motors: this.motors.map((m) => ({ pwm: Math.round(m.pwm), target: m.target, dir: m.dir })),
      servos: this.servos.map((s) => ({ angle: Math.round(s.angle), target: s.target })),
      runloop: rls,
      runloopA: dueling ? rls : undefined,
      runloopB: dueling ? rlsB : undefined,
      panel: {
        detected: true,
        raw: 0xffff,
      },
    }
  }

  private lastBroadcast = 0
  private broadcast() {
    const now = this.now()
    if (!this.dirty && now - this.lastBroadcast < 1000) return
    this.dirty = false
    this.lastBroadcast = now
    this.handlers?.onMessage({ t: 'state', d: this.snapshot() })
  }

  private log(kind: EventKind, msg: string) {
    const ev: BoardEvent = { id: ++this.eventId, ms: this.now(), kind, msg }
    this.events.push(ev)
    if (this.events.length > 200) this.events.shift()
    this.handlers?.onMessage({ t: 'event', d: ev })
  }

  // -------------------------------------------------------------------- REST
  async getInfo(): Promise<BoardInfo> {
    await sleep(120)
    return {
      fw: '0.1.0',
      build: 'browser-sim',
      chip: 'Simulated ESP32-S3',
      sim: true,
      simForced: true,
      uptimeMs: this.now(),
      heapFree: 214_000,
      psramFree: 8_150_000,
      fsUsed: 412_000,
      fsTotal: 3_407_872,
      hostname: this.wifi.hostname,
      wifi: {
        mode: this.wifi.mode,
        connected: this.wifi.mode === 'home',
        ssid: this.wifi.mode === 'home' ? this.wifi.ssid : '',
        ip: this.wifi.mode === 'home' ? '192.168.1.42' : '',
        rssi: -58,
        apActive: this.wifi.mode === 'coaster',
        apSsid: this.wifi.apSsid,
        apIp: '192.168.4.1',
      },
      hw: HW,
    }
  }

  async getWifi(): Promise<WifiConfig> {
    await sleep(100)
    return { ...this.wifi, password: '' }
  }

  async saveWifi(cfg: WifiConfig): Promise<void> {
    await sleep(300)
    this.wifi = { ...this.wifi, ...cfg, hasPassword: !!cfg.password || this.wifi.hasPassword }
    this.log('system', `Wi-Fi settings saved (${cfg.mode === 'home' ? 'Home Wi-Fi' : 'Coaster Wi-Fi'})`)
  }

  async scanWifi(): Promise<WifiNetwork[]> {
    await sleep(1400)
    return [
      { ssid: 'Workshop-WiFi', rssi: -52, secure: true },
      { ssid: 'Living Room 5G', rssi: -67, secure: true },
      { ssid: 'Garage', rssi: -74, secure: true },
      { ssid: 'Guest', rssi: -81, secure: false },
    ]
  }

  async getSystem(): Promise<SystemConfig> {
    await sleep(80)
    return { ...this.system }
  }

  async saveSystem(cfg: SystemConfig): Promise<void> {
    await sleep(200)
    this.system = { ...this.system, ...cfg }
    this.dirty = true
    this.log('system', `System configuration updated (Dueling: ${cfg.duelingMode ? 'ON' : 'OFF'})`)
  }

  async reboot(): Promise<void> {
    await sleep(150)
    this.log('system', 'Rebooting…')
    const handlers = this.handlers
    this.disconnect()
    window.setTimeout(() => handlers && this.connect(handlers), 2500)
  }

  async upload(target: UploadTarget, file: File, onProgress: (f: number) => void): Promise<void> {
    const steps = 30
    for (let i = 1; i <= steps; i++) {
      await sleep(80)
      onProgress(i / steps)
    }
    this.log('system', `${target === 'firmware' ? 'Firmware' : 'Web UI'} update "${file.name}" installed (simulated)`)
  }

  // --- Run Loop Link Methods ---
  async getRunLoop(coaster?: 'a' | 'b'): Promise<RunLoopConfig> {
    await sleep(60)
    if (coaster === 'b') return { trainCount: this.trainCountB, halls: JSON.parse(JSON.stringify(this.programsB)) }
    if (coaster === 'a') return { trainCount: this.trainCountA, halls: JSON.parse(JSON.stringify(this.programsA)) }
    return { trainCount: this.trainCount, halls: JSON.parse(JSON.stringify(this.programs)) }
  }

  async saveRunLoop(cfg: RunLoopConfig, coaster?: 'a' | 'b'): Promise<void> {
    await sleep(150)
    const tc: 1 | 2 = cfg.trainCount === 2 ? 2 : 1
    if (coaster === 'b') {
      this.trainCountB = tc
      this.programsB = JSON.parse(JSON.stringify(cfg.halls))
      this.resetMockTrainPositions(this.programsB, true)
      this.log('system', 'Coaster B configuration saved')
    } else if (coaster === 'a') {
      this.trainCountA = tc
      this.programsA = JSON.parse(JSON.stringify(cfg.halls))
      this.resetMockTrainPositions(this.programsA, false)
      this.log('system', 'Coaster A configuration saved')
    } else {
      this.trainCount = tc
      this.programs = JSON.parse(JSON.stringify(cfg.halls))
      this.resetMockTrainPositions(this.programs, false)
      this.log('system', `Run loop configuration saved (${tc}-Train Mode)`)
    }
    this.dirty = true
  }

  async startRunLoop(coaster?: 'a' | 'b'): Promise<void> {
    this.send(coaster === 'b' ? { c: 'startLoopB' } : coaster === 'a' ? { c: 'startLoopA' } : { c: 'startLoop' })
  }

  async stopRunLoop(coaster?: 'a' | 'b'): Promise<void> {
    this.send(coaster === 'b' ? { c: 'stopLoopB' } : coaster === 'a' ? { c: 'stopLoopA' } : { c: 'stopLoop' })
  }

  async resetRunLoop(coaster?: 'a' | 'b'): Promise<void> {
    this.send(coaster === 'b' ? { c: 'resetLoopB' } : coaster === 'a' ? { c: 'resetLoopA' } : { c: 'resetLoop' })
  }

  async dispatch(coaster?: 'a' | 'b'): Promise<void> {
    this.send(coaster === 'b' ? { c: 'dispatchB' } : coaster === 'a' ? { c: 'dispatchA' } : { c: 'dispatch' })
  }

  async dispatchBoth(): Promise<void> {
    this.send({ c: 'dispatchBoth' })
  }

  async testHall(hallId: number, coaster?: 'a' | 'b'): Promise<void> {
    this.send(coaster === 'b' ? { c: 'testHallB', id: hallId } : coaster === 'a' ? { c: 'testHallA', id: hallId } : { c: 'testHall', id: hallId })
  }

  async loadDefaultTemplate(coaster?: 'a' | 'b'): Promise<void> {
    await sleep(100)
    this.log('system', `${coaster ? `Coaster ${coaster.toUpperCase()}` : 'Default'} template loaded`)
  }

  // --- WLED Link Methods ---
  async getWled(): Promise<WledConfig> {
    await sleep(60)
    return { devices: JSON.parse(JSON.stringify(this.wledDevices)) }
  }

  async saveWled(cfg: WledConfig): Promise<void> {
    await sleep(120)
    this.wledDevices = JSON.parse(JSON.stringify(cfg.devices))
    this.log('system', 'WLED devices list updated')
  }

  async triggerWled(target: string, preset: number): Promise<void> {
    this.send({ c: 'triggerWled', target, preset })
  }

  // --- Panel Link Methods ---
  async getPanel(): Promise<PanelStatus> {
    await sleep(60)
    return { detected: true, pins: JSON.parse(JSON.stringify(this.panelPins)) }
  }

  async savePanel(cfg: PanelConfig): Promise<void> {
    await sleep(120)
    this.panelPins = JSON.parse(JSON.stringify(cfg.pins))
    this.log('system', 'Control panel mappings saved')
  }
}
