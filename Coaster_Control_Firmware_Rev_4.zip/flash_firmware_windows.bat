@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
title K'nex Roller Coaster Base Station - Firmware & Web UI Installer

echo =====================================================================
echo    K'NEX ROLLER COASTER BASE STATION - ONE-CLICK INSTALLER
echo    ESP32-S3 (16 MB Flash, Dual DRV8833, 4x FET, 12x Hall, 6x Servos)
echo =====================================================================
echo.

:: Check for esptool or python
set ESPTOOL_CMD=
where esptool.py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    set ESPTOOL_CMD=esptool.py
    goto :FOUND_ESPTOOL
)

where esptool >nul 2>nul
if %ERRORLEVEL% equ 0 (
    set ESPTOOL_CMD=esptool
    goto :FOUND_ESPTOOL
)

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python -m esptool version >nul 2>nul
    if !ERRORLEVEL! equ 0 (
        set ESPTOOL_CMD=python -m esptool
        goto :FOUND_ESPTOOL
    )
    echo Installing esptool via pip...
    python -m pip install esptool
    set ESPTOOL_CMD=python -m esptool
    goto :FOUND_ESPTOOL
)

echo [ERROR] Python / esptool was not detected on your system PATH.
echo Please install Python from https://www.python.org/ (check "Add Python to PATH")
echo or refer to Documentation_PDF\3_Fresh_PC_Flashing_Guide.pdf
echo.
pause
exit /b 1

:FOUND_ESPTOOL
echo [OK] Using flashing tool: %ESPTOOL_CMD%
echo.

:: Prompt for COM Port
set /p COMPORT="Enter your ESP32-S3 COM Port (e.g., COM3, COM19): "
if "%COMPORT%"=="" (
    echo [ERROR] No COM port specified. Exiting.
    pause
    exit /b 1
)

echo.
echo =====================================================================
echo Target Board:  ESP32-S3 on %COMPORT%
echo Flashing:      1. Combined Factory Firmware (0x0000)
echo                2. LittleFS Web Dashboard Storage (0xC90000)
echo =====================================================================
echo.
echo Put your ESP32-S3 into Bootloader mode if needed (Hold BOOT, tap RESET, release BOOT).
echo.
pause

echo.
echo [1/2] Writing Factory Firmware & Partitions...
%ESPTOOL_CMD% --chip esp32s3 --port %COMPORT% --baud 921600 write-flash 0x0 Binaries\firmware.factory.bin
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Flashing firmware failed. Please check COM port and USB cable.
    pause
    exit /b 1
)

echo.
echo [2/2] Writing Web Dashboard LittleFS Partition (0xC90000)...
%ESPTOOL_CMD% --chip esp32s3 --port %COMPORT% --baud 921600 write-flash 0xC90000 Binaries\littlefs.bin
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Flashing LittleFS filesystem failed.
    pause
    exit /b 1
)

echo.
echo =====================================================================
echo   SUCCESS! Flash completed successfully!
echo =====================================================================
echo.
echo 1. Disconnect and reconnect USB (or press the RST button on the ESP32).
echo 2. Connect your phone or laptop to Wi-Fi SSID: "Coaster-Setup"
echo 3. Open your browser and navigate to: http://192.168.4.1
echo    (Or http://coaster.local if connected to home Wi-Fi)
echo.
echo Full manual: Documentation_PDF\4_Web_Dashboard_Operator_Guide.pdf
echo =====================================================================
echo.
pause
