# Build & Flash Guide

## Toolchains Required

1. **Web Application (`web/`)**:
   - **Node.js**: v18.0+ (v20/v22 LTS recommended)
   - **Package Manager**: `npm`
2. **ESP32-S3 Firmware (`firmware/`)**:
   - **PlatformIO Core (`pio`)**: Python 3.10–3.14 environment
   - **Platform**: `pioarduino/platform-espressif32` (Arduino-ESP32 v3.x + ESP-IDF v5.x)

---

## Step 1: Building the Web Dashboard

The React/TypeScript web application in `web/` compiles into static assets and automatically writes gzipped files (`index.html.gz`, `assets/*.gz`) directly into `firmware/data/` for LittleFS flashing.

```bash
cd web
npm install
npm run build
```

### Running the Offline Browser Simulator

To test the UI, Track Schematic Vector Editor, Quick Motor/Servo Toggles, and Run Loop stages without an ESP32 connected:

```bash
cd web
npm run dev:mock
```

---

## Step 2: PlatformIO Firmware Environments

Defined in [`firmware/platformio.ini`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/platformio.ini):

| Environment | Target Board | Description |
|---|---|---|
| `s3` *(default)* | `esp32-s3-devkitc-1` (N16R8) | Production Rev 3 hardware firmware. Native USB CDC disabled on GPIO 19/20 so Motor 1 H-Bridge has dedicated GPIO access. |
| `s3-bench` | `esp32-s3-devkitc-1` (N16R8) | Diagnostic bench mode (`-DENABLE_TEMP_SERIAL=1`). Enables 115200 baud debug logs on UART0 (`GPIO 43` TX / `GPIO 44` RX) while reserving those two pins from Servo 5 / Hall 6. |
| `s3-sim` | `esp32-s3-devkitc-1` (N16R8) | Boots the ESP32-S3 in dry-run simulation mode (`-DCOASTER_DEFAULT_SIM=1`). |
| `s3-ota` | `esp32-s3-devkitc-1` (N16R8) | Wireless Over-The-Air upload (`espota`) to `coaster.local`. |
| `esp32-sim` | `esp32dev` | Classic ESP32 simulation-only target (`-DCOASTER_FORCE_SIM=1`). |

### Compile Commands

```bash
# Compile production firmware
pio run -d firmware -e s3

# Compile bench diagnostic firmware
pio run -d firmware -e s3-bench
```

### Flash Commands (USB UART Port)

```bash
# Flash firmware binary
pio run -d firmware -e s3 -t upload

# Build & flash LittleFS filesystem (firmware/data -> 0xC90000)
pio run -d firmware -e s3 -t uploadfs
```

