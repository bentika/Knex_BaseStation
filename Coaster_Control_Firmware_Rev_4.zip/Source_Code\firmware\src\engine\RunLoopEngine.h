#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <stdint.h>
#include <stdbool.h>
#include <vector>
#include "../pins.h"
#include "../io/IOInterface.h"

#define RUNLOOP_DISPATCH_HALL_ID            (0U)
#define RUNLOOP_DUEL_HALLS_PER_TRACK        (6U)
#define RUNLOOP_DEFAULT_HALL_LOCKOUT_MS     (1500UL)
#define RUNLOOP_DEFAULT_DISPATCH_LOCKOUT_MS (500UL)
#define RUNLOOP_DISPATCH_SETTLE_MS          (250UL)
#define RUNLOOP_DEFAULT_STAGE_DELAY_MS      (500UL)
#define RUNLOOP_DEFAULT_DELAY_ACT_MS        (1000UL)
#define RUNLOOP_DEFAULT_DISPATCH_TIMEOUT_MS (10000UL)
#define RUNLOOP_DEFAULT_MOTOR_PWM           (100)
#define RUNLOOP_MAX_TRAINS                  (2U)

/**
 * @brief Action types executable within a timed RunStep stage.
 */
enum class ActionType : uint8_t {
    MOTOR = 0,
    SERVO,
    DELAY,
    WAIT_DISPATCH,
    WLED
};

/**
 * @brief Single hardware or network action inside a `RunStep`.
 */
struct StepAction {
    ActionType type;

    // Motor parameters
    uint8_t motorId;       // 1..6
    String motorOp;        // "start", "stop", "runTime", "ramp"
    int32_t pwm;           // 0..100
    MotorDir dir;          // FWD, REV
    uint32_t durationMs;   // for runTime or delay

    // Servo parameters
    uint8_t servoId;       // 1..6
    String servoOp;        // "set", "half", "full", "fullPause"
    int32_t angle;         // 0..180
    int32_t speed;         // deg/s (0 = instant)
    uint32_t pauseMs;

    // Wait Dispatch parameters
    uint32_t timeoutMs;

    // WLED parameters
    String wledTarget;     // device ID or "all"
    int32_t wledPreset;
};

/**
 * @brief A timed stage in a Hall/Dispatch sequence containing concurrent actions.
 */
struct RunStep {
    uint32_t delayMs = 0U; // Configurable delay before/for this timed stage (ms)
    std::vector<StepAction> actions;
};

/**
 * @brief Automation sequence bound to either Dispatch (`hallId = 0`) or a Hall Sensor (`hallId = 1..12`).
 */
struct HallProgram {
    uint8_t hallId;        // 0 = Dispatch, 1..12 = Hall 1..12
    String name;
    bool enabled;
    int32_t wledPreset;    // 0 = none, or fires immediately on sensor trigger
    uint32_t lockoutMs;
    // Block-Zone Hold Point configuration
    bool isBlockHold = false;
    uint8_t blockMotorId = 0U;         // 0 = auto/none, 1..6 = Motor channel controlled by block brake/lift
    int32_t blockMotorPwm = 100;       // 1..100% PWM restored on block release
    MotorDir blockMotorDir = MotorDir::FWD;
    uint8_t blockServoId = 0U;         // 0 = none, 1..6 = Brake/gate servo channel
    int32_t blockHoldAngle = 0;        // Servo angle when holding train
    int32_t blockReleaseAngle = 90;    // Servo angle when releasing train
    std::vector<RunStep> steps;
};

/**
 * @brief Live block-zone position & hold status for a tracked train.
 */
struct TrainTrackerStatus {
    uint8_t id;            // 1 or 2
    int32_t currentHall;   // Active Hall ID at start of current block zone (1..12)
    int32_t nextHall;      // Next active Hall ID ahead of train (1..12)
    bool held;             // True if stopped at currentHall waiting for next block zone to clear
};

/**
 * @brief Live state telemetry for a `RunLoopEngine` instance.
 */
struct RunLoopStatus {
    bool enabled;          // Sequencer armed/active
    int32_t activeHall;    // -1 if idle, 0 = Dispatch, 1..12 = Hall
    int32_t activeStep;    // 0-indexed or -1 if idle
    int32_t totalSteps;
    bool waitingDispatch;
    uint32_t elapsedStepMs;
    uint32_t stepDurationMs;
    uint8_t trainCount;    // 1 = Single Train, 2 = 2-Train Block Zone Mode
    TrainTrackerStatus trains[RUNLOOP_MAX_TRAINS];
};

/**
 * @brief Deterministic Block-Zone & Timed-Stage Coaster Automation Engine.
 *
 * Supports Single Coaster mode (`instanceA` owning Halls 1..12 & Motors 1..6)
 * and Dueling Coaster mode (`instanceA` owning Track A and `instanceB` owning Track B).
 * Operates exclusively through `IOInterface` for hardware portability and testability.
 */
class RunLoopEngine {
public:
    static RunLoopEngine& instance(); // alias to instanceA()
    static RunLoopEngine& instanceA();
    static RunLoopEngine& instanceB();

    /**
     * @brief Bind the engine to an `IOInterface` and load saved automation programs.
     *
     * @param io        Pointer to hardware/simulator I/O abstraction
     * @param coasterId Track identifier ('A' or 'B')
     */
    void begin(IOInterface* io, char coasterId = 'A');

    /**
     * @brief Reload automation programs from LittleFS (or initialize clean defaults).
     */
    void reload();

    /**
     * @brief Get track identifier ('A' or 'B').
     * @return char Coaster ID
     */
    char getCoasterId() const { return _coasterId; }

    /**
     * @brief Deterministic non-blocking state machine update tick.
     */
    void update();

    // Controls
    void startEngine();
    void stopEngine();
    void resetEngine();
    void dispatch();
    void testFireHall(uint8_t hallId);

    // Sensor Hook
    void onHallTriggered(uint8_t hallId);

    // Status
    RunLoopStatus getStatus() const;
    bool isRunning() const { return _engineActive; }
    bool isWaitingDispatch() const { return _waitingDispatch; }

    // Configuration
    bool loadConfig();
    bool saveConfig();
    void loadDefaultTemplate();
    const std::vector<HallProgram>& getPrograms() const { return _programs; }
    void setPrograms(const std::vector<HallProgram>& programs);
    uint8_t getTrainCount() const { return _trainCount; }
    void setTrainCount(uint8_t count);

    // Serialization helper for REST / WS
    void serializeConfig(JsonDocument& doc) const;
    bool deserializeConfig(JsonVariantConst doc);

private:
    explicit RunLoopEngine(char coasterId = 'A');
    void executeStep(size_t stepIdx);
    void finishCurrentProgram();
    void resetTrainPositions();
    std::vector<uint8_t> getActiveHallOrder() const;
    uint8_t getNextActiveHall(uint8_t hallId) const;
    void releaseHeldTrain(uint8_t trainIdx);
    String getConfigPath() const;

    /**
     * @brief RAII guard over the engine's recursive mutex.
     *
     * The engine is touched from three contexts: ControlTask (timing + Hall events),
     * AsyncTCP (REST/WebSocket commands, program uploads) and the loop task (panel buttons).
     * Serializing them prevents the program vector from being modified while a sequence iterates it.
     */
    class RunLoopLock {
    public:
        explicit RunLoopLock(SemaphoreHandle_t m) : _m(m) {
            if (_m != nullptr) {
                (void)xSemaphoreTakeRecursive(_m, portMAX_DELAY);
            }
        }
        ~RunLoopLock() {
            if (_m != nullptr) {
                (void)xSemaphoreGiveRecursive(_m);
            }
        }
        RunLoopLock(const RunLoopLock&) = delete;
        RunLoopLock& operator=(const RunLoopLock&) = delete;
    private:
        SemaphoreHandle_t _m;
    };

    mutable SemaphoreHandle_t _mutex = nullptr;
    IOInterface* _io;
    char _coasterId;
    bool _engineActive;
    std::vector<HallProgram> _programs;

    // Live Execution State
    int32_t _activeHall;       // -1 = idle, 0 = Dispatch, 1..12 = Hall
    int32_t _activeStep;       // -1 = idle
    uint32_t _stepStartMs;
    uint32_t _stepDurationMs;
    bool _waitingDispatch;
    uint32_t _dispatchWaitStartMs;
    uint32_t _dispatchTimeoutMs;

    // Internal motor auto-stop tracking for "runTime" actions
    struct AutoStopMotor {
        uint8_t motorId;
        uint32_t stopAtMs;
        bool active;
    } _autoStopMotors[NUM_MOTORS];

    // Multi-magnet train debounce lockout tracking per hall sensor
    uint32_t _lastHallTriggerMs[NUM_HALLS];
    uint32_t _lastDispatchMs;
    uint8_t _trainCount;
    TrainTrackerStatus _trains[RUNLOOP_MAX_TRAINS];
};
