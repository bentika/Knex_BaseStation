#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <DNSServer.h>
#include <ESPmDNS.h>
#include <ESPAsyncWebServer.h>
#include <Update.h>
#include "../io/IOInterface.h"
#include "../config/ConfigManager.h"

struct SystemLogEvent {
    uint32_t id;
    uint32_t ms;
    String kind;
    String msg;
};

class WebServerManager {
public:
    static WebServerManager& instance();

    void begin(IOInterface* io);
    void update();

    void logEvent(const String& kind, const String& msg);
    void broadcastState();
    size_t wsClientCount() const { return _ws.count(); }

    void startAP();
    void stopAP();
    void applyWiFiConfig(const String& oldMode, const String& oldSsid, const String& oldPass, const String& oldApSsid, const String& oldApPass, const String& oldHost);

private:
    WebServerManager();

    void setupWiFi();
    void setupRoutes();
    void setupWebSocket();

    void handleWsMessage(AsyncWebSocketClient* client, void* arg, uint8_t* data, size_t len);
    void handleCommand(JsonVariantConst doc);

    IOInterface* _io;
    AsyncWebServer _server;
    AsyncWebSocket _ws;
    DNSServer _dnsServer;

    unsigned long _lastStateBroadcast;
    unsigned long _wifiConnectStart;
    unsigned long _lastStaRetry;
    unsigned long _scheduledReboot;
    bool _apActive;
    bool _dnsActive;
    bool _staConnected;
    bool _stateDirty;
    uint32_t _nextEventId;

    static const size_t MAX_LOGS = 50;
    SystemLogEvent _logs[MAX_LOGS];
    size_t _logCount;
};
