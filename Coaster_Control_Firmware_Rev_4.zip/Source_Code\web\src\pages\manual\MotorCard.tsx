import { useState, useEffect } from 'react'
import { Play, Square } from 'lucide-react'
import type { MotorDir, MotorState } from '../../api/types'
import styles from './MotorCard.module.css'

interface Props {
  id: number
  name: string
  driver: 'hbridge' | 'fet'
  reversible: boolean
  state: MotorState
  onSet: (pwm: number, dir: MotorDir) => void
  onStop: () => void
  disabled?: boolean
}

const MOTOR_SUBTITLES: Record<number, string> = {
  1: 'CH-01 • DRV8833 Reversible H-Bridge',
  2: 'CH-02 • DRV8833 Reversible H-Bridge',
  3: 'CH-03 • Unidirectional MOSFET',
  4: 'CH-04 • Unidirectional MOSFET',
  5: 'CH-05 • Unidirectional MOSFET',
  6: 'CH-06 • Unidirectional MOSFET',
}

export function MotorCard({
  id,
  name,
  driver,
  reversible,
  state,
  onSet,
  onStop,
  disabled,
}: Props) {
  const [targetPwm, setTargetPwm] = useState(state.target || 100)
  const [targetDir, setTargetDir] = useState<MotorDir>(state.dir || 'fwd')

  useEffect(() => {
    if (state.target > 0) {
      setTargetPwm(state.target)
    }
    if (state.dir) {
      setTargetDir(state.dir)
    }
  }, [state.target, state.dir])

  const isRunning = state.pwm > 0 || state.target > 0

  const handleToggle = () => {
    if (isRunning) {
      onStop()
    } else {
      onSet(targetPwm || 100, targetDir)
    }
  }

  const handleDirChange = (dir: MotorDir) => {
    setTargetDir(dir)
    if (isRunning) {
      onSet(targetPwm, dir)
    }
  }

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10)
    setTargetPwm(val)
  }

  const handleSliderCommit = (e: React.PointerEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>) => {
    const val = parseInt((e.currentTarget as HTMLInputElement).value, 10)
    setTargetPwm(val)
    if (isRunning) {
      onSet(val, targetDir)
    }
  }

  const handlePresetClick = (p: number) => {
    setTargetPwm(p)
    if (isRunning) {
      onSet(p, targetDir)
    }
  }

  const presets = [25, 50, 75, 100]
  const accentHex = driver === 'hbridge' ? '#0284c7' : '#7c3aed'

  return (
    <div className={`${styles.unit} ${isRunning ? styles.running : ''}`}>
      <div className={styles.unitTop}>
        {/* Unit Header */}
        <div className={styles.header}>
          <div className={styles.titleGroup}>
            <span
              className={`${styles.driverBadge} ${
                driver === 'hbridge' ? styles.hbridgeBadge : styles.fetBadge
              }`}
            >
              {driver === 'hbridge' ? 'DRV8833' : 'FET PWM'}
            </span>
            <div className={styles.nameGroup}>
              <span className={styles.name}>{name}</span>
              <span className={styles.subLabel}>{MOTOR_SUBTITLES[id] || `Channel CH-0${id}`}</span>
            </div>
          </div>

          <div
            className={`${styles.statusPill} ${
              isRunning ? styles.statusRunning : styles.statusOff
            }`}
          >
            {isRunning ? (
              <span className={styles.pulseBeacon}>
                <span className={styles.pulsePing} />
                <span className={styles.pulseCore} />
              </span>
            ) : (
              <span className={styles.idleDot} />
            )}
            <span className={styles.statusLabelText}>{isRunning ? 'RUNNING' : 'IDLE'}</span>
            <span className={`${styles.statusValText} mono`}>{isRunning ? `${state.pwm}%` : '0%'}</span>
          </div>
        </div>

        {/* Readout */}
        <div className={styles.readoutRow}>
          <span className={styles.readoutLabel}>PWM DUTY:</span>
          <span
            className={`${styles.readoutVal} ${
              driver === 'hbridge' ? styles.valCyan : styles.valViolet
            } mono`}
          >
            {targetPwm}%
          </span>
        </div>

        {/* 6px Track Slider with dynamic filled gradient */}
        <div className={styles.sliderWrap}>
          <input
            type="range"
            min={0}
            max={100}
            value={targetPwm}
            disabled={disabled}
            onChange={handleSliderChange}
            onPointerUp={handleSliderCommit}
            onKeyUp={handleSliderCommit}
            className={`${styles.slider} ${driver === 'hbridge' ? styles.sliderCyan : styles.sliderViolet}`}
            style={{
              background: `linear-gradient(to right, ${accentHex} ${targetPwm}%, var(--surface-container-highest) ${targetPwm}%)`,
            }}
            aria-label={`${name} PWM Duty`}
          />
        </div>

        {/* Compact Segmented Control Presets */}
        <div className={styles.segmentedControl}>
          {presets.map((p) => (
            <button
              key={p}
              type="button"
              className={`${styles.segmentBtn} ${
                targetPwm === p
                  ? driver === 'hbridge'
                    ? styles.segmentActiveCyan
                    : styles.segmentActiveViolet
                  : ''
              }`}
              onClick={() => handlePresetClick(p)}
              disabled={disabled}
            >
              <span className="mono">{p}%</span>
            </button>
          ))}
        </div>

        {/* Direction for H-Bridge only (Motors 1-2). Filler row removed for Motors 3-6! */}
        {reversible && (
          <div className={styles.dirRow}>
            <span className={styles.dirLabel}>DIRECTION</span>
            <div className={styles.dirToggles}>
              <button
                type="button"
                className={`${styles.dirBtn} ${
                  targetDir === 'fwd' ? styles.dirActive : styles.dirInactive
                }`}
                onClick={() => handleDirChange('fwd')}
                disabled={disabled}
              >
                FWD
              </button>
              <button
                type="button"
                className={`${styles.dirBtn} ${
                  targetDir === 'rev' ? styles.dirActive : styles.dirInactive
                }`}
                onClick={() => handleDirChange('rev')}
                disabled={disabled}
              >
                REV
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Start / Stop Button with consistent solid weight */}
      <button
        type="button"
        className={`${styles.toggleBtn} ${
          isRunning ? styles.btnRunning : driver === 'hbridge' ? styles.btnCyan : styles.btnViolet
        }`}
        onClick={handleToggle}
        disabled={disabled}
      >
        {isRunning ? (
          <>
            <Square className={styles.btnIcon} />
            <span>STOP</span>
          </>
        ) : (
          <>
            <Play className={styles.btnIcon} />
            <span>START</span>
          </>
        )}
      </button>
    </div>
  )
}
