import type { ReactNode } from 'react'
import styles from './Segmented.module.css'

interface Option<T extends string> {
  value: T
  label: ReactNode
  icon?: ReactNode
}

interface Props<T extends string> {
  value: T
  options: Option<T>[]
  onChange: (value: T) => void
  disabled?: boolean
  size?: 'sm' | 'md'
  'aria-label'?: string
  idPrefix?: string
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  disabled,
  size = 'md',
  idPrefix,
  ...aria
}: Props<T>) {
  const index = Math.max(
    0,
    options.findIndex((o) => o.value === value),
  )
  return (
    <div
      className={`${styles.root} ${styles[size]}`}
      role="radiogroup"
      style={{ ['--count' as string]: options.length, ['--index' as string]: index }}
      {...aria}
    >
      <span className={styles.thumb} aria-hidden />
      {options.map((o) => (
        <button
          key={o.value}
          id={idPrefix ? `${idPrefix}-${o.value}` : undefined}
          type="button"
          role="radio"
          aria-checked={o.value === value}
          className={`${styles.option} ${o.value === value ? styles.active : ''}`}
          disabled={disabled}
          onClick={() => onChange(o.value)}
        >
          {o.icon}
          {o.label}
        </button>
      ))}
    </div>
  )
}
