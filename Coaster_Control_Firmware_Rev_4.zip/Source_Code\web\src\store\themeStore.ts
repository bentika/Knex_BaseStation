import { create } from 'zustand'

export type Theme = 'light' | 'dark'

interface ThemeStore {
  theme: Theme
  setTheme: (theme: Theme) => void
  toggleTheme: () => void
}

const getInitialTheme = (): Theme => {
  if (typeof window === 'undefined') return 'light'
  const saved = localStorage.getItem('coaster-theme')
  if (saved === 'dark' || saved === 'light') return saved
  // User explicitly asked: "add a white these mode as well make it primary"
  return 'light'
}

export const useTheme = create<ThemeStore>((set, get) => {
  const initial = getInitialTheme()
  if (typeof document !== 'undefined') {
    document.documentElement.setAttribute('data-theme', initial)
  }

  return {
    theme: initial,
    setTheme: (theme) => {
      localStorage.setItem('coaster-theme', theme)
      document.documentElement.setAttribute('data-theme', theme)
      set({ theme })
    },
    toggleTheme: () => {
      const next = get().theme === 'light' ? 'dark' : 'light'
      get().setTheme(next)
    },
  }
})
