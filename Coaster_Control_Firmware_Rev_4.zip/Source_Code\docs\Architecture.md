# Software Architecture

## Layer Model

The K'NEX Roller Coaster Base Station firmware strictly follows a top-down layered embedded architecture (`embedded-architecture` & `embedded-driver-design`):

```text
+-------------------------------------------------------------------+
| APP LAYER (firmware/src/main.cpp)                                 |
| - System startup sequence                                         |
| - ControlTask (500 Hz drift-free vTaskDelayUntil on Core 1)       |
| - CommLoop (200 Hz I2C panel & WebServer service on Core 1)       |
| - RTOS Health & Watchdog Monitor (health_monitor_check)           |
+-------------------------------------------------------------------+
                                 ↓
+-------------------------------------------------------------------+
| MODULE LAYER (engine/, config/, net/, drivers/PanelManager)       |
| - RunLoopEngine: Coaster A & B block-zone / timed-stage sequencer |
| - PanelManager:  16-button debounce & action dispatch             |
| - WledManager:   Core 0 async HTTP preset worker & command queue  |
| - WebServerManager: Async HTTP REST, WebSocket & Wi-Fi AP+STA     |
| - ConfigManager: Persistent JSON configuration in LittleFS        |
+-------------------------------------------------------------------+
                                 ↓
+-------------------------------------------------------------------+
| INTERFACE LAYER (firmware/src/interface/, firmware/src/io/)       |
| - IOInterface: Abstract contract for Motors, Servos, Halls, EStop |
| - i2c_if_t:    Abstract I2C bus contract (probe, write, read)     |
| - fw_err_t:     Unified project-wide error enum                    |
+-------------------------------------------------------------------+
                                 ↓
+-------------------------------------------------------------------+
| DEVICE & BSP DRIVER LAYER (io/RealIO, drivers/pcf8575)            |
| - pcf8575_t:   HAL-independent 16-bit I/O expander chip driver    |
| - bsp_i2c:     Arduino Wire adapter implementing i2c_if_t         |
| - RealIO:      ESP32-S3 LEDC motors, MCPWM servos, GPIO Hall ISRs |
+-------------------------------------------------------------------+
                                 ↓
+-------------------------------------------------------------------+
| PLATFORM LAYER (ESP-IDF 5.x / Arduino-ESP32 3.x)                  |
| - <driver/mcpwm_prelude.h>, LEDC, GPIO ISR, FreeRTOS, LittleFS    |
+-------------------------------------------------------------------+
```

## Dependency Direction Rules

Allowed dependency direction (strictly top-down):

```text
APP → MODULE → INTERFACE → DRIVER / BSP → PLATFORM
```

1. **Zero HAL Leakage in Business Logic**:
   - [`RunLoopEngine`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/engine/RunLoopEngine.h) never calls ESP32 LEDC, MCPWM, or `digitalRead()` APIs. It interacts exclusively with [`IOInterface`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/IOInterface.h).
2. **Bus Abstraction for External Peripheral Chips**:
   - [`pcf8575.cpp`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/drivers/pcf8575.cpp) never includes `<Wire.h>` or calls `Wire.*` directly. It operates on a `pcf8575_t` context struct holding a pointer to [`i2c_if_t`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/interface/i2c_if.h).
3. **Control Loop Timing Isolation**:
   - Real-time I/O ramping, Hall edge debouncing, and `RunLoopEngine` step timing execute in a dedicated 500 Hz FreeRTOS task (`ControlTask`) using `vTaskDelayUntil`, decoupled from network/HTTP/WebSocket operations.

## End-to-End Data Flow Diagram

```text
A3144 Hall Sensor (Active LOW)
    ↓ (Hardware FALLING Interrupt < 2 µs)
hall_gpio_isr_handler (IRAM_ATTR)
    ↓ (s_isrHallEdgeMask bitmask)
RealIO::update() [ControlTask @ 500 Hz]
    ↓ (Multi-magnet train debounce lockout: 1500 ms)
RunLoopEngine::onHallTriggered(hallId)
    ├──→ IOInterface::setMotor() ──→ RealIO (LEDC 20 kHz PWM)
    ├──→ IOInterface::setServo() ──→ RealIO (MCPWM Group 0 @ 50 Hz)
    └──→ WledManager::triggerAll() ──→ FreeRTOS Queue ──→ WledWorker (Core 0 HTTP GET)
```

