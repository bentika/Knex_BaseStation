/**
 * Canonical Hardware Channel Configuration for ESP32-S3 Coaster Station.
 * Single source of truth for all motor, servo, and Hall sensor names and roles.
 */

export interface MotorChannel {
  id: number
  name: string
  role: string
  driver: 'hbridge' | 'fet'
  driverName: string
  reversible: boolean
  desc: string
}

export interface ServoChannel {
  id: number
  name: string
  role: string
  desc: string
  home: number
}

export interface HallChannel {
  id: number
  name: string
  pin: string
  zone: string
}

export const MOTORS: MotorChannel[] = [
  {
    id: 1,
    name: 'Motor 1',
    role: 'H-Bridge',
    driver: 'hbridge',
    driverName: 'DRV8833 Reversible',
    reversible: true,
    desc: 'Reversible H-Bridge motor channel 1 (FWD / REV)',
  },
  {
    id: 2,
    name: 'Motor 2',
    role: 'H-Bridge',
    driver: 'hbridge',
    driverName: 'DRV8833 Reversible',
    reversible: true,
    desc: 'Reversible H-Bridge motor channel 2 (FWD / REV)',
  },
  {
    id: 3,
    name: 'Motor 3',
    role: 'MOSFET',
    driver: 'fet',
    driverName: 'CH-03 Unidirectional FET',
    reversible: false,
    desc: 'Single-direction MOSFET PWM output 3',
  },
  {
    id: 4,
    name: 'Motor 4',
    role: 'MOSFET',
    driver: 'fet',
    driverName: 'CH-04 Unidirectional FET',
    reversible: false,
    desc: 'Single-direction MOSFET PWM output 4',
  },
  {
    id: 5,
    name: 'Motor 5',
    role: 'MOSFET',
    driver: 'fet',
    driverName: 'CH-05 Unidirectional FET',
    reversible: false,
    desc: 'Single-direction MOSFET PWM output 5',
  },
  {
    id: 6,
    name: 'Motor 6',
    role: 'MOSFET',
    driver: 'fet',
    driverName: 'CH-06 Unidirectional FET',
    reversible: false,
    desc: 'Single-direction MOSFET PWM output 6',
  },
]

export const SERVOS: ServoChannel[] = [
  { id: 1, name: 'Servo 1', role: 'Servo 1', desc: '50Hz PWM Servo Channel 1 (GPIO 4)', home: 90 },
  { id: 2, name: 'Servo 2', role: 'Servo 2', desc: '50Hz PWM Servo Channel 2 (GPIO 5)', home: 90 },
  { id: 3, name: 'Servo 3', role: 'Servo 3', desc: '50Hz PWM Servo Channel 3 (GPIO 6)', home: 90 },
  { id: 4, name: 'Servo 4', role: 'Servo 4', desc: '50Hz PWM Servo Channel 4 (GPIO 7)', home: 90 },
  { id: 5, name: 'Servo 5', role: 'Servo 5', desc: '50Hz PWM Servo Channel 5 (GPIO 43)', home: 90 },
  { id: 6, name: 'Servo 6', role: 'Servo 6', desc: '50Hz PWM Servo Channel 6 (GPIO 15)', home: 90 },
]

export const HALL_SENSORS: Record<number, HallChannel> = {
  1: { id: 1, name: 'Hall 1', pin: 'GPIO 13', zone: 'Hall 1' },
  2: { id: 2, name: 'Hall 2', pin: 'GPIO 47', zone: 'Hall 2' },
  3: { id: 3, name: 'Hall 3', pin: 'GPIO 41', zone: 'Hall 3' },
  4: { id: 4, name: 'Hall 4', pin: 'GPIO 2', zone: 'Hall 4' },
  5: { id: 5, name: 'Hall 5', pin: 'GPIO 1', zone: 'Hall 5' },
  6: { id: 6, name: 'Hall 6', pin: 'GPIO 44', zone: 'Hall 6' },
  7: { id: 7, name: 'Hall 7', pin: 'GPIO 14', zone: 'Hall 7' },
  8: { id: 8, name: 'Hall 8', pin: 'GPIO 21', zone: 'Hall 8' },
  9: { id: 9, name: 'Hall 9', pin: 'GPIO 40', zone: 'Hall 9' },
  10: { id: 10, name: 'Hall 10', pin: 'GPIO 42', zone: 'Hall 10' },
  11: { id: 11, name: 'Hall 11', pin: 'GPIO 17', zone: 'Hall 11' },
  12: { id: 12, name: 'Hall 12', pin: 'GPIO 16', zone: 'Hall 12' },
}

export function getMotorRole(id: number): string {
  const m = MOTORS.find((x) => x.id === id)
  return m ? m.name : `Motor ${id}`
}

export function getServoRole(id: number): string {
  const s = SERVOS.find((x) => x.id === id)
  return s ? s.name : `Servo ${id}`
}

export function getHallInfo(id: number): HallChannel {
  return HALL_SENSORS[id] || { id, name: `Hall ${id}`, pin: `GPIO ${id}`, zone: `Hall ${id}` }
}
