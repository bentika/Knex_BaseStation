#include "PanelManager.h"
#include "../engine/RunLoopEngine.h"
#include "../config/ConfigManager.h"
#include <Wire.h>
#include <LittleFS.h>

/**
 * @brief Board-specific I2C bus adapter implementing `i2c_if_t` via Arduino Wire HAL.
 *        Isolated at the BSP/adapter boundary so `pcf8575_t` remains HAL-independent.
 */
static fw_err_t bsp_i2c_probe(uint8_t addr) {
    Wire.beginTransmission(addr);
    uint8_t err = Wire.endTransmission();
    return (err == 0U) ? FW_OK : FW_ERR_COMMUNICATION;
}

static fw_err_t bsp_i2c_write(uint8_t addr, const uint8_t *data, uint32_t len) {
    if (data == nullptr || len == 0U) {
        return FW_ERR_INVALID_PARAM;
    }
    Wire.beginTransmission(addr);
    size_t written = Wire.write(data, (size_t)len);
    uint8_t err = Wire.endTransmission();
    if (err != 0U || written != (size_t)len) {
        return FW_ERR_COMMUNICATION;
    }
    return FW_OK;
}

static fw_err_t bsp_i2c_read(uint8_t addr, uint8_t *data, uint32_t len) {
    if (data == nullptr || len == 0U) {
        return FW_ERR_INVALID_PARAM;
    }
    uint8_t received = Wire.requestFrom(addr, (uint8_t)len);
    if (received != (uint8_t)len) {
        return FW_ERR_COMMUNICATION;
    }
    for (uint32_t i = 0U; i < len; i++) {
        data[i] = (uint8_t)Wire.read();
    }
    return FW_OK;
}

static const i2c_if_t s_board_i2c_if = {
    .probe = bsp_i2c_probe,
    .write = bsp_i2c_write,
    .read  = bsp_i2c_read
};

PanelManager& PanelManager::instance() {
    static PanelManager inst;
    return inst;
}

PanelManager::PanelManager()
    : _io(nullptr),
      _expander{&s_board_i2c_if, PCF8575_I2C_ADDR, PCF8575_ALL_INPUT_MASK, false},
      _detected(false),
      _currentState(PCF8575_ALL_INPUT_MASK),
      _lastState(PCF8575_ALL_INPUT_MASK),
      _lastReadMs(0U),
      _lastProbeMs(0U),
      _readFailures(0U) {
    for (uint8_t i = 0U; i < NUM_PANEL_PINS; i++) {
        _lastDebounceMs[i] = 0U;
    }
}

bool PanelManager::begin(IOInterface* io) {
    _io = io;

    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, PANEL_I2C_FREQ_HZ);

    _expander.i2c = &s_board_i2c_if;
    _expander.i2c_addr = PCF8575_I2C_ADDR;
    fw_err_t initRet = pcf8575_init(&_expander);
    _detected = (initRet == FW_OK);

    if (!loadConfig()) {
        loadDefaultMappings();
        (void)saveConfig();
    }

    return _detected;
}

void PanelManager::loadDefaultMappings() {
    for (uint8_t i = 0U; i < NUM_PANEL_PINS; i++) {
        _pinConfigs[i].pin = i;
        _pinConfigs[i].action = "none";
        _pinConfigs[i].label = "Panel Button " + String(i + 1U);
    }

    // Pin 0: Manual Dispatch Button
    _pinConfigs[0].action = "dispatch";
    _pinConfigs[0].label = "Dispatch";

    // Pin 1: Servo 1 Toggle
    _pinConfigs[1].action = "servoToggle_1";
    _pinConfigs[1].label = "Servo 1";

    // Pin 2: Motor 2 Toggle
    _pinConfigs[2].action = "motorToggle_2";
    _pinConfigs[2].label = "Motor 2";

    // Pin 3: Emergency Stop
    _pinConfigs[3].action = "estop";
    _pinConfigs[3].label = "Emergency Stop";

    // Pin 4: Start/Stop Run Loop
    _pinConfigs[4].action = "startStopLoop";
    _pinConfigs[4].label = "Run Loop Toggle";
}

bool PanelManager::isPinPressed(uint8_t pin) const {
    if (pin >= NUM_PANEL_PINS) {
        return false;
    }
    // Active LOW (0 = pressed)
    return ((_currentState & (uint16_t)(1U << pin)) == 0U);
}

const PanelPinConfig& PanelManager::getPinConfig(uint8_t pin) const {
    if (pin >= NUM_PANEL_PINS) {
        return _pinConfigs[0];
    }
    return _pinConfigs[pin];
}

void PanelManager::setPinConfig(uint8_t pin, const String& action, const String& label) {
    if (pin >= NUM_PANEL_PINS) {
        return;
    }
    _pinConfigs[pin].action = action;
    _pinConfigs[pin].label = label;
    (void)saveConfig();
}

void PanelManager::update() {
    uint32_t now = (uint32_t)millis();

    if (!_detected) {
        // Hot-plug support: re-probe the panel every few seconds so the user does not
        // have to reboot the board after plugging the control panel in.
        if ((now - _lastProbeMs) >= PANEL_REPROBE_INTERVAL_MS) {
            _lastProbeMs = now;
            if (pcf8575_init(&_expander) == FW_OK) {
                _detected = true;
                _currentState = PCF8575_ALL_INPUT_MASK;
                _lastState = PCF8575_ALL_INPUT_MASK;
            }
        }
        return;
    }

    if ((now - _lastReadMs) < PANEL_POLL_INTERVAL_MS) {
        return; // 50 Hz poll
    }
    _lastReadMs = now;

    uint16_t raw = PCF8575_ALL_INPUT_MASK;
    if (pcf8575_read_port(&_expander, &raw) != FW_OK) {
        // Panel unplugged or bus fault: fall back to re-probe mode instead of freezing on stale state.
        if (++_readFailures >= PANEL_MAX_READ_FAILURES) {
            _detected = false;
            _readFailures = 0U;
            _expander.initialized = false;
            _currentState = PCF8575_ALL_INPUT_MASK;
            _lastState = PCF8575_ALL_INPUT_MASK;
        }
        return;
    }
    _readFailures = 0U;

    {
        for (uint8_t pin = 0U; pin < NUM_PANEL_PINS; pin++) {
            uint16_t bitMask = (uint16_t)(1U << pin);
            bool wasPressed = ((_currentState & bitMask) == 0U); // previous poll result
            bool isPressed = ((raw & bitMask) == 0U);

            // On transition to pressed (leading active-low edge)
            if (isPressed && !wasPressed) {
                if ((now - _lastDebounceMs[pin]) >= PANEL_DEBOUNCE_MS) {
                    _lastDebounceMs[pin] = now;
                    executePinAction(pin);
                }
            }
        }

        _lastState = _currentState;
        _currentState = raw;
    }
}

void PanelManager::executePinAction(uint8_t pin) {
    if (pin >= NUM_PANEL_PINS || _io == nullptr) {
        return;
    }
    const String& act = _pinConfigs[pin].action;

    if (act == "dispatch" || act == "dispatchBoth") {
        RunLoopEngine::instanceA().dispatch();
        if (ConfigManager::instance().config().duelingMode) {
            RunLoopEngine::instanceB().dispatch();
        }
    } else if (act == "dispatchA") {
        RunLoopEngine::instanceA().dispatch();
    } else if (act == "dispatchB") {
        RunLoopEngine::instanceB().dispatch();
    } else if (act == "estop") {
        _io->setEstop(true);
    } else if (act == "reset") {
        _io->setEstop(false);
    } else if (act == "startStopLoop") {
        if (RunLoopEngine::instanceA().isRunning()) {
            RunLoopEngine::instanceA().stopEngine();
            if (ConfigManager::instance().config().duelingMode) {
                RunLoopEngine::instanceB().stopEngine();
            }
        } else {
            RunLoopEngine::instanceA().startEngine();
            if (ConfigManager::instance().config().duelingMode) {
                RunLoopEngine::instanceB().startEngine();
            }
        }
    } else if (act.startsWith("motorToggle_")) {
        int32_t mId = act.substring(12).toInt();
        if (mId >= 1 && mId <= (int32_t)NUM_MOTORS) {
            MotorStatus ms = _io->getMotorStatus((uint8_t)mId);
            if (ms.target > 0 || ms.pwm > 0) {
                _io->stopMotor((uint8_t)mId);
            } else {
                _io->setMotor((uint8_t)mId, PANEL_DEFAULT_MOTOR_PWM, MotorDir::FWD);
            }
        }
    } else if (act.startsWith("servoToggle_")) {
        int32_t sId = act.substring(12).toInt();
        if (sId >= 1 && sId <= (int32_t)NUM_SERVOS) {
            ServoStatus ss = _io->getServoStatus((uint8_t)sId);
            int32_t nextAngle = (ss.target > PANEL_SERVO_THRESHOLD_DEG)
                                    ? PANEL_SERVO_MIN_DEG
                                    : PANEL_SERVO_MAX_DEG;
            _io->setServo((uint8_t)sId, nextAngle, PANEL_SERVO_DEFAULT_SPEED);
        }
    } else if (act.startsWith("hall_")) {
        int32_t h = act.substring(5).toInt();
        if (h >= 1 && h <= (int32_t)NUM_HALLS) {
            if (ConfigManager::instance().config().duelingMode) {
                if (h <= 6) {
                    RunLoopEngine::instanceA().testFireHall((uint8_t)h);
                } else {
                    RunLoopEngine::instanceB().testFireHall((uint8_t)(h - 6));
                }
            } else {
                RunLoopEngine::instanceA().testFireHall((uint8_t)h);
            }
        }
    }
}

void PanelManager::serializeStatus(JsonObject& obj) const {
    obj["detected"] = _detected;
    JsonArray pins = obj["pins"].to<JsonArray>();
    for (uint8_t i = 0U; i < NUM_PANEL_PINS; i++) {
        JsonObject p = pins.add<JsonObject>();
        p["pin"] = i;
        p["pressed"] = isPinPressed(i);
        p["action"] = _pinConfigs[i].action;
        p["label"] = _pinConfigs[i].label;
    }
}

bool PanelManager::loadConfig() {
    if (!LittleFS.exists("/panel.json")) {
        return false;
    }

    File f = LittleFS.open("/panel.json", "r");
    if (!f) {
        return false;
    }

    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, f);
    f.close();

    if (err || !doc["pins"].is<JsonArray>()) {
        return false;
    }

    for (JsonObject p : doc["pins"].as<JsonArray>()) {
        uint8_t pin = p["pin"] | PANEL_INVALID_PIN;
        if (pin < NUM_PANEL_PINS) {
            _pinConfigs[pin].pin = pin;
            _pinConfigs[pin].action = p["action"] | "none";
            String defLbl = "Pin " + String(pin + 1U);
            _pinConfigs[pin].label = p["label"].is<String>() ? p["label"].as<String>() : defLbl;
        }
    }

    return true;
}

bool PanelManager::saveConfig() {
    JsonDocument doc;
    JsonArray arr = doc["pins"].to<JsonArray>();
    for (uint8_t i = 0U; i < NUM_PANEL_PINS; i++) {
        JsonObject p = arr.add<JsonObject>();
        p["pin"] = _pinConfigs[i].pin;
        p["action"] = _pinConfigs[i].action;
        p["label"] = _pinConfigs[i].label;
    }

    File f = LittleFS.open("/panel.json", "w");
    if (!f) {
        return false;
    }

    serializeJson(doc, f);
    f.close();
    return true;
}
