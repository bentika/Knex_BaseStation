# IOInterface Specification (`embedded-documentation` L3)

## Purpose

[`IOInterface`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/IOInterface.h) defines the hardware-independent contract for all coaster actuation and sensing:
- 6 DC Motor channels (`1..6`, PWM `0–100%`, direction `FWD`/`REV`, soft ramp `rampMs`)
- 6 RC Servo channels (`1..6`, angle `0–180°`, angular slew speed `deg/s`)
- 12 Hall Effect block-zone sensors (`1..12`, active state, pass counter, train debounce lockout)
- Emergency Stop (`setEstop`, `isEstop`) and Simulation Mode (`setSimMode`, `isSimMode`)

## Public API

```cpp
void begin();
void update();

void setMotor(uint8_t id, int pwm, MotorDir dir = MotorDir::FWD, int rampMs = 0);
void stopMotor(uint8_t id);
void stopAllMotors();

void setServo(uint8_t id, int angle, int speed = 0);

MotorStatus getMotorStatus(uint8_t id) const;
ServoStatus getServoStatus(uint8_t id) const;

bool getHallActive(uint8_t id) const;
uint32_t getHallCount(uint8_t id) const;
void resetHallCounts();
void simulateHall(uint8_t id);

void setEstop(bool active);
bool isEstop() const;

void setHallCallback(HallCallback cb);
void setHallDebounceMs(uint32_t ms);
uint32_t getHallDebounceMs() const;

void setSimMode(bool sim);
bool isSimMode() const;
```

## Ownership

- **Implemented by**: [`RealIO`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/RealIO.h) (`firmware/src/io/RealIO.cpp`).
- **Consumed by**: [`RunLoopEngine`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/engine/RunLoopEngine.h), [`PanelManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/drivers/PanelManager.h), and [`WebServerManager`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/net/WebServerManager.h).

## Thread & ISR Safety

- Hardware GPIO interrupts (`hall_gpio_isr_handler`) synchronize with `RealIO::update()` using a `portMUX_TYPE` critical section (`s_hallIsrMux`).
- Periodic ramping and deferred ISR callbacks execute deterministically inside `ControlTask` (500 Hz).

