#pragma once

#include <Arduino.h>

/**
 * ============================================================================
 * Wi-Fi Pre-Flash Configuration (Home Network & Access Point)
 * ============================================================================
 * Enter your home 2.4 GHz Wi-Fi credentials here BEFORE flashing to have the
 * ESP32-S3 connect to your home network automatically upon initial boot!
 *
 * - If DEFAULT_WIFI_SSID is left blank (""), the board defaults to Access Point
 *   mode (broadcasts "Coaster-Setup" hotspot on http://192.168.4.1).
 * - If DEFAULT_WIFI_SSID is configured, the board connects to your home
 * network, and also keeps the "Coaster-Setup" Access Point active
 * simultaneously so you can always connect directly from phone/tablet even if
 * router is off.
 * - Set FORCE_PINS_WIFI_CONFIG to true if you want these values to always
 *   overwrite any previously saved LittleFS settings on boot.
 * ============================================================================
 */
#define DEFAULT_WIFI_SSID "" // 2.4 GHz Home Wi-Fi SSID (leave "" for default Access Point mode)
#define DEFAULT_WIFI_PASS "" // Home Wi-Fi Password (leave "" for default Access Point mode)
#define DEFAULT_AP_SSID "Coaster-Setup" // Controller Hotspot Name (192.168.4.1)
#define DEFAULT_AP_PASS "" // Hotspot Password ("" for open, or min 8 chars)
#define DEFAULT_HOSTNAME "coaster" // mDNS URL: http://coaster.local
#define DEFAULT_AP_ALWAYS_ON true  // Keep Hotspot active alongside Home Wi-Fi
#define FORCE_PINS_WIFI_CONFIG                                                 \
  false // true = always force pins.h credentials on boot

/**
 * ============================================================================
 * K'nex Roller Coaster Base Station – Pinout Mapping
 * Board: ESP32-S3-DevKitC-1 N16R8
 * Matches "BaseStationPinsAfterLayout - RunLoop.pdf" (Human View) & KiCad sch.
 * ============================================================================
 */

// --- Motors ---
// Motors 1 & 2 driven by DRV8833 Dual H-Bridge (Forward & Reverse)
#define PIN_M1_IN1 19
#define PIN_M1_IN2 20
#define PIN_M2_IN1 12
#define PIN_M2_IN2 11

// Motors 3, 4, 5, 6 driven by Blue FET modules (Single-direction PWM)
#define PIN_M3_PWM 10
#define PIN_M4_PWM 38
#define PIN_M5_PWM 18
#define PIN_M6_PWM 39

#define NUM_MOTORS 6

// --- Servos ---
// 60Hz / 50Hz RC Servos (500 - 2500 us)
#define PIN_SERVO_1 4
#define PIN_SERVO_2 5
#define PIN_SERVO_3 6
#define PIN_SERVO_4 7
#define PIN_SERVO_5 43
#define PIN_SERVO_6 15

#define NUM_SERVOS 6

// --- Hall Effect Sensors (A3144, active LOW) ---
#define PIN_HALL_1 13
#define PIN_HALL_2 47
#define PIN_HALL_3 41
#define PIN_HALL_4 2
#define PIN_HALL_5 1
#define PIN_HALL_6 44
#define PIN_HALL_7 14
#define PIN_HALL_8 21
#define PIN_HALL_9 40
#define PIN_HALL_10 42
#define PIN_HALL_11 17
#define PIN_HALL_12 16

#define NUM_HALLS 12

// --- I2C Expansion (PCF8575 16-bit Button/Panel Expander) ---
#define PIN_I2C_SDA 8
#define PIN_I2C_SCL 9

// --- Pin Arrays for iterative setup ---
static const uint8_t MOTOR_PINS[NUM_MOTORS][2] = {
    {PIN_M1_IN1, PIN_M1_IN2}, // H-bridge
    {PIN_M2_IN1, PIN_M2_IN2}, // H-bridge
    {PIN_M3_PWM, 255},        // FET PWM only
    {PIN_M4_PWM, 255},        // FET PWM only
    {PIN_M5_PWM, 255},        // FET PWM only
    {PIN_M6_PWM, 255}         // FET PWM only
};

static const uint8_t SERVO_PINS[NUM_SERVOS] = {PIN_SERVO_1, PIN_SERVO_2,
                                               PIN_SERVO_3, PIN_SERVO_4,
                                               PIN_SERVO_5, PIN_SERVO_6};

static const uint8_t HALL_PINS[NUM_HALLS] = {
    PIN_HALL_1, PIN_HALL_2, PIN_HALL_3, PIN_HALL_4,  PIN_HALL_5,  PIN_HALL_6,
    PIN_HALL_7, PIN_HALL_8, PIN_HALL_9, PIN_HALL_10, PIN_HALL_11, PIN_HALL_12};
