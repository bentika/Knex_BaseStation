import { useEffect, useState, useRef } from 'react'
import {
  Play,
  Pause,
  Zap,
  Save,
  RotateCcw,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  Edit2,
  X,
  Gauge,
  Compass,
  Timer,
  Palette,
  Radio,
  Move,
  Eye,
  EyeOff,
  Upload,
  Shield,
  Magnet,
} from 'lucide-react'
import { Button } from '../components/Button'
import { useBoard } from '../store/boardStore'
import { toast } from '../store/toastStore'
import { href } from '../hooks/useRoute'
import {
  MOTORS,
  SERVOS,
  getMotorRole,
  getServoRole,
  getHallInfo,
} from '../config/hardware'
import type { HallProgram, StepAction, ActionType, TrainTrackerStatus } from '../api/types'
import styles from './RunLoopPage.module.css'

interface CustomSvgTrack {
  name: string
  pathD: string
  samples: Array<{ x: number; y: number }>
}

// Default Landmark SVG coordinates (cx, cy) along the track path (0 = Dispatch)
const DEFAULT_SENSOR_COORDS: Record<number, { x: number; y: number }> = {
  0: { x: 110, y: 24 }, // Dispatch intro node pointing into H1
  1: { x: 185, y: 46 },
  2: { x: 340, y: 40 },
  3: { x: 510, y: 44 },
  4: { x: 680, y: 48 },
  5: { x: 820, y: 65 },
  6: { x: 855, y: 115 },
  7: { x: 780, y: 152 },
  8: { x: 640, y: 155 },
  9: { x: 500, y: 155 },
  10: { x: 360, y: 155 },
  11: { x: 220, y: 152 },
  12: { x: 105, y: 115 },
}

const LEGACY_DEFAULT_NAMES = new Set([
  'Station Approach',
  'Station Stop & Dispatch',
  'Switch Track Turn',
  'Switch Track Straight',
  'Lift Hill Crest',
  'Brake Run',
])

function isLegacyHallName(name: string): boolean {
  if (!name) return true
  if (LEGACY_DEFAULT_NAMES.has(name)) return true
  if (name.startsWith('Hall Sensor ')) return true
  if (name.startsWith('Track A ') || name.startsWith('Track B ')) return true
  return false
}

/** Build a smooth closed Catmull-Rom -> Cubic Bezier SVG path through the given points */
function buildClosedSplinePath(pts: { x: number; y: number }[], tension = 0.22): string {
  const n = pts.length
  if (n === 0) return ''
  if (n === 1) {
    const p = pts[0]
    return `M ${p.x - 40} ${p.y} a 40 40 0 1 0 80 0 a 40 40 0 1 0 -80 0`
  }
  if (n === 2) {
    const [p1, p2] = pts
    const mx = (p1.x + p2.x) / 2
    const my = (p1.y + p2.y) / 2
    return `M ${p1.x} ${p1.y} Q ${mx} ${my - 45}, ${p2.x} ${p2.y} Q ${mx} ${my + 45}, ${p1.x} ${p1.y} Z`
  }
  let d = `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n]
    const p1 = pts[i]
    const p2 = pts[(i + 1) % n]
    const p3 = pts[(i + 2) % n]
    const cp1x = p1.x + (p2.x - p0.x) * tension
    const cp1y = p1.y + (p2.y - p0.y) * tension
    const cp2x = p2.x - (p3.x - p1.x) * tension
    const cp2y = p2.y - (p3.y - p1.y) * tension
    d += ` C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`
  }
  return d + ' Z'
}

export function RunLoopPage({ coaster }: { coaster?: 'a' | 'b' } = {}) {
  const { link, state, send } = useBoard()

  const isDueling = !!coaster || (state?.duelingMode ?? false)
  const effectiveCoaster = coaster ?? (state?.duelingMode ? 'a' : undefined)
  const isCoasterB = effectiveCoaster === 'b'
  const isCoasterA = effectiveCoaster === 'a'

  const [programs, setPrograms] = useState<HallProgram[]>([])
  const [trainCount, setTrainCount] = useState<1 | 2>(1)
  const [selectedHallId, setSelectedHallId] = useState(1)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Configurable time for "Add Timed Stage" (in seconds)
  const [newStageDelaySec, setNewStageDelaySec] = useState<number>(1.0)

  // Custom Imported SVG Track Vector State
  const [customSvgTrack, setCustomSvgTrack] = useState<CustomSvgTrack | null>(() => {
    try {
      const saved = localStorage.getItem('coaster_custom_svg_v1')
      if (saved) return JSON.parse(saved)
    } catch {
      // ignore storage errors
    }
    return null
  })
  const [snapToVector, setSnapToVector] = useState<boolean>(true)
  const svgFileInputRef = useRef<HTMLInputElement | null>(null)

  // Editable Track Schematic Vector State
  const [sensorCoords, setSensorCoords] = useState<Record<number, { x: number; y: number }>>(() => {
    try {
      const saved = localStorage.getItem('coaster_schematic_coords_v1')
      if (saved) {
        return { ...DEFAULT_SENSOR_COORDS, ...JSON.parse(saved) }
      }
    } catch {
      // ignore storage errors
    }
    return { ...DEFAULT_SENSOR_COORDS }
  })
  const [editingVector, setEditingVector] = useState(false)
  const [draggingNodeId, setDraggingNodeId] = useState<number | null>(null)
  const svgRef = useRef<SVGSVGElement | null>(null)

  // Local fallback train tracker (synced with live board runloop.trains telemetry)
  const [localTrains, setLocalTrains] = useState<TrainTrackerStatus[]>([
    { id: 1, currentHall: 1, nextHall: 2, held: false },
    { id: 2, currentHall: 4, nextHall: 1, held: false },
  ])

  // Interactive Track & Monitoring Accordion States
  const [trainPos, setTrainPos] = useState<{ x: number; y: number }>(DEFAULT_SENSOR_COORDS[1])
  const [schematicOpen, setSchematicOpen] = useState(
    typeof window !== 'undefined' ? window.innerWidth > 768 : true
  )
  const [consoleOpen, setConsoleOpen] = useState(
    typeof window !== 'undefined' ? window.innerWidth > 768 : true
  )

  const [consoleLogs, setConsoleLogs] = useState<
    Array<{ id: number; time: string; tag: string; tagColor: string; msg: string }>
  >([
    {
      id: 1,
      time: '00:00:01',
      tag: 'ESP32-CORE',
      tagColor: '#38bdf8',
      msg: 'Hall sensor inputs ready (active-low debounced). Select Dispatch or any Hall sensor to configure stages.',
    },
  ])

  const animTimerRef = useRef<number | null>(null)

  // Action Modal State (Default Motor PWM = 100%)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalStepIdx, setModalStepIdx] = useState<number | null>(null)
  const [editingActionIdx, setEditingActionIdx] = useState<number | null>(null)
  const [actionType, setActionType] = useState<ActionType>('motor')
  const [actionMotor, setActionMotor] = useState(isCoasterB ? 5 : 1)
  const [actionMotorOp, setActionMotorOp] = useState<'start' | 'stop' | 'runTime'>('start')
  const [actionPwm, setActionPwm] = useState(100)
  const [actionDir, setActionDir] = useState<'fwd' | 'rev'>('fwd')
  const [actionDurationMs, setActionDurationMs] = useState(2000)
  const [actionServo, setActionServo] = useState(isCoasterB ? 4 : 1)
  const [actionAngle, setActionAngle] = useState(90)
  const [actionServoSpeed, setActionServoSpeed] = useState(100)
  const [actionTimeoutMs, setActionTimeoutMs] = useState(10000)
  const [actionWledPreset, setActionWledPreset] = useState(1)

  useEffect(() => {
    loadPrograms()
    setSelectedHallId(1)
    if (isCoasterB) {
      setActionMotor(5)
      setActionServo(4)
    } else {
      setActionMotor(1)
      setActionServo(1)
    }
  }, [effectiveCoaster])

  // Move train to active sensor when hardware triggers & sync board train trackers
  useEffect(() => {
    const rls = isCoasterB ? state?.runloopB : isCoasterA ? (state?.runloopA ?? state?.runloop) : state?.runloop
    if (rls?.trains && rls.trains.length > 0) {
      setLocalTrains(rls.trains)
    }
    const activeId = rls?.activeHall
    const activeStep = rls?.activeStep ?? -1
    if (activeId !== undefined && activeId >= 0 && activeStep >= 0 && sensorCoords[activeId]) {
      setTrainPos(sensorCoords[activeId])
      const label = activeId === 0 ? 'Dispatch' : `Hall ${activeId}`
      addConsoleLog('TRIGGER', '#34d399', `${label} triggered sequence stage ${activeStep + 1}`)
    }
  }, [
    state?.runloop?.activeHall,
    state?.runloop?.activeStep,
    state?.runloop?.trains,
    state?.runloopA?.activeHall,
    state?.runloopA?.trains,
    state?.runloopB?.activeHall,
    state?.runloopB?.trains,
  ])

  const saveCoordsToStorage = (next: Record<number, { x: number; y: number }>) => {
    setSensorCoords(next)
    try {
      localStorage.setItem('coaster_schematic_coords_v1', JSON.stringify(next))
    } catch {
      // ignore storage errors
    }
  }

  const saveCustomSvgToStorage = (next: CustomSvgTrack | null) => {
    setCustomSvgTrack(next)
    try {
      if (next) {
        localStorage.setItem('coaster_custom_svg_v1', JSON.stringify(next))
      } else {
        localStorage.removeItem('coaster_custom_svg_v1')
      }
    } catch {
      // ignore storage errors
    }
  }

  /** Snap a coordinate (x, y) to the closest point on the active track curve (imported SVG or spline) */
  const snapCoordToTrackVector = (x: number, y: number, samples: Array<{ x: number; y: number }>): { x: number; y: number } => {
    if (!samples || samples.length === 0) return { x, y }
    let best = samples[0]
    let bestDistSq = Infinity
    for (const pt of samples) {
      const dx = pt.x - x
      const dy = pt.y - y
      const d2 = dx * dx + dy * dy
      if (d2 < bestDistSq) {
        bestDistSq = d2
        best = pt
      }
    }
    return { x: Math.round(best.x), y: Math.round(best.y) }
  }

  /** Import a user-drawn single-loop SVG file, normalize it into the 920x180 schematic, and place active halls along it */
  const handleImportSvgFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    e.target.value = ''

    try {
      const rawText = await file.text()
      const parser = new DOMParser()
      const doc = parser.parseFromString(rawText, 'image/svg+xml')
      const svgEl = doc.querySelector('svg')
      if (!svgEl) {
        toast.error('Invalid SVG file: no <svg> root element found')
        return
      }

      // Mount offscreen SVG so browser geometry engine can sample any <path>, <polygon>, <polyline>, <ellipse>, <rect>, or <circle>
      const sandbox = document.createElement('div')
      sandbox.style.position = 'fixed'
      sandbox.style.left = '-9999px'
      sandbox.style.top = '-9999px'
      sandbox.style.width = '1000px'
      sandbox.style.height = '1000px'
      sandbox.style.visibility = 'hidden'
      sandbox.style.pointerEvents = 'none'
      const clonedSvg = svgEl.cloneNode(true) as SVGSVGElement
      sandbox.appendChild(clonedSvg)
      document.body.appendChild(sandbox)

      const candidates = Array.from(
        clonedSvg.querySelectorAll('path, polygon, polyline, ellipse, circle, rect')
      ) as SVGGeometryElement[]

      let bestGeom: SVGGeometryElement | null = null
      let bestLen = 0
      for (const geom of candidates) {
        try {
          const len = geom.getTotalLength()
          if (len > bestLen) {
            bestLen = len
            bestGeom = geom
          }
        } catch {
          // ignore non-measurable elements
        }
      }

      if (!bestGeom || bestLen <= 0) {
        document.body.removeChild(sandbox)
        toast.error('Could not find a vector loop/path in the uploaded SVG')
        return
      }

      const SAMPLE_COUNT = 240
      const rawPts: Array<{ x: number; y: number }> = []
      const ctm = bestGeom.getCTM()
      for (let i = 0; i < SAMPLE_COUNT; i++) {
        const pt = bestGeom.getPointAtLength((i / SAMPLE_COUNT) * bestLen)
        if (ctm) {
          rawPts.push({
            x: pt.x * ctm.a + pt.y * ctm.c + ctm.e,
            y: pt.x * ctm.b + pt.y * ctm.d + ctm.f,
          })
        } else {
          rawPts.push({ x: pt.x, y: pt.y })
        }
      }

      document.body.removeChild(sandbox)

      let minX = Infinity
      let maxX = -Infinity
      let minY = Infinity
      let maxY = -Infinity
      for (const p of rawPts) {
        if (p.x < minX) minX = p.x
        if (p.x > maxX) maxX = p.x
        if (p.y < minY) minY = p.y
        if (p.y > maxY) maxY = p.y
      }

      const spanX = Math.max(1, maxX - minX)
      const spanY = Math.max(1, maxY - minY)
      const targetLeft = 100
      const targetWidth = 740
      const targetTop = 26
      const targetHeight = 132

      // Normalize into 920x180 schematic canvas
      const normSamples = rawPts.map((p) => ({
        x: Number((targetLeft + ((p.x - minX) / spanX) * targetWidth).toFixed(1)),
        y: Number((targetTop + ((p.y - minY) / spanY) * targetHeight).toFixed(1)),
      }))

      const pathD =
        normSamples
          .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`)
          .join(' ') + ' Z'

      const imported: CustomSvgTrack = {
        name: file.name,
        pathD,
        samples: normSamples,
      }
      saveCustomSvgToStorage(imported)

      // Automatically distribute active Halls evenly around the imported SVG vector
      const activeHalls = programs.filter((p) => p.id > 0 && p.enabled !== false)
      const nextCoords: Record<number, { x: number; y: number }> = { ...sensorCoords }
      if (activeHalls.length > 0) {
        activeHalls.forEach((h, idx) => {
          const sampleIdx = Math.floor((idx / activeHalls.length) * normSamples.length) % normSamples.length
          const pt = normSamples[sampleIdx]
          nextCoords[h.id] = { x: Math.round(pt.x), y: Math.round(pt.y) }
        })
        const h1Pt = nextCoords[activeHalls[0].id] || normSamples[0]
        nextCoords[0] = {
          x: Math.max(45, Math.min(875, h1Pt.x - 55)),
          y: Math.max(18, h1Pt.y - 22),
        }
        saveCoordsToStorage(nextCoords)
      }

      setEditingVector(true)
      setSnapToVector(true)
      toast.success(`Imported SVG track "${file.name}"! Drag Hall nodes around the vector to position them.`)
      addConsoleLog('SVG-TRACK', '#38bdf8', `Imported custom SVG vector "${file.name}" (${normSamples.length} vector samples)`)
    } catch {
      toast.error('Failed to parse SVG file')
    }
  }

  const applyVectorPreset = (preset: 'oval' | 'loop4' | 'figure8') => {
    const activeHalls = programs.filter((p) => p.id > 0 && p.enabled)
    const count = activeHalls.length || 4
    const next: Record<number, { x: number; y: number }> = { ...sensorCoords }

    if (preset === 'loop4') {
      // Matches the client's Paint sketch: Dispatch -> H1 (top-right) -> H2 (bottom-right) -> H3 (bottom-left) -> H4 (top-left) -> H1
      next[0] = { x: 430, y: 20 }
      const cx = 460
      const cy = 98
      const rx = 220
      const ry = 55
      activeHalls.forEach((h, idx) => {
        // Start at top-right (-45 deg) and go clockwise
        const angle = -Math.PI / 4 + (idx / count) * Math.PI * 2
        next[h.id] = {
          x: Math.round(cx + rx * Math.cos(angle)),
          y: Math.round(cy + ry * Math.sin(angle)),
        }
      })
    } else if (preset === 'figure8') {
      next[0] = { x: 140, y: 24 }
      const cx = 460
      const cy = 96
      activeHalls.forEach((h, idx) => {
        const t = (idx / count) * Math.PI * 2
        next[h.id] = {
          x: Math.round(cx + 340 * Math.sin(t)),
          y: Math.round(cy + 56 * Math.sin(2 * t)),
        }
      })
    } else {
      // Default Stadium Oval evenly spacing active halls
      next[0] = { x: 120, y: 22 }
      const cx = 465
      const cy = 98
      const rx = 350
      const ry = 56
      activeHalls.forEach((h, idx) => {
        const angle = -Math.PI * 0.75 + (idx / count) * Math.PI * 2
        next[h.id] = {
          x: Math.round(cx + rx * Math.cos(angle)),
          y: Math.round(cy + ry * Math.sin(angle)),
        }
      })
    }
    saveCoordsToStorage(next)
    toast.info('Updated coaster track vector layout')
  }

  const handleSvgPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (draggingNodeId === null || !svgRef.current) return
    const rect = svgRef.current.getBoundingClientRect()
    if (rect.width === 0 || rect.height === 0) return
    const rawX = Math.max(28, Math.min(892, Math.round(((e.clientX - rect.left) / rect.width) * 920)))
    const rawY = Math.max(20, Math.min(164, Math.round(((e.clientY - rect.top) / rect.height) * 180)))
    const finalCoord =
      draggingNodeId > 0 && customSvgTrack && snapToVector
        ? snapCoordToTrackVector(rawX, rawY, customSvgTrack.samples)
        : { x: rawX, y: rawY }
    const next = { ...sensorCoords, [draggingNodeId]: finalCoord }
    setSensorCoords(next)
  }

  const handleSvgPointerUp = () => {
    if (draggingNodeId !== null) {
      saveCoordsToStorage(sensorCoords)
      setDraggingNodeId(null)
    }
  }

  const addConsoleLog = (tag: string, tagColor: string, msg: string) => {
    const now = new Date()
    const time = `${now.toTimeString().split(' ')[0]}.${String(now.getMilliseconds()).padStart(3, '0')}`
    setConsoleLogs((prev) => [
      { id: Date.now() + Math.random(), time, tag, tagColor, msg },
      ...prev.slice(0, 49),
    ])
  }

  const normalizeLoadedPrograms = (raw: HallProgram[]): HallProgram[] => {
    const list = [...raw]
    // Ensure Dispatch (id = 0) exists at the start of the list
    if (!list.some((p) => p.id === 0)) {
      list.unshift({
        id: 0,
        name: 'Dispatch',
        enabled: true,
        wledPreset: 0,
        lockoutMs: 500,
        steps: [],
      })
    }
    return list.map((p) => {
      if (p.id === 0) {
        return {
          ...p,
          name: p.name && p.name !== 'Hall 0' ? p.name : 'Dispatch',
          enabled: p.enabled ?? true,
          steps: (p.steps || []).map((st, idx) => ({
            ...st,
            delayMs: idx === 0 ? 0 : (st.delayMs ?? 500),
          })),
        }
      }
      const cleanName = isLegacyHallName(p.name) ? `Hall ${p.id}` : p.name
      return {
        ...p,
        name: cleanName,
        isBlockHold: p.isBlockHold ?? false,
        blockMotorId: p.blockMotorId ?? 1,
        blockMotorPwm: p.blockMotorPwm ?? 100,
        blockMotorDir: p.blockMotorDir ?? 'fwd',
        blockServoId: p.blockServoId ?? 0,
        blockHoldAngle: p.blockHoldAngle ?? 0,
        blockReleaseAngle: p.blockReleaseAngle ?? 90,
        steps: (p.steps || []).map((st, idx) => ({
          ...st,
          delayMs: idx === 0 ? 0 : (st.delayMs ?? 500),
        })),
      }
    })
  }

  const initDefaultTrainLocations = (progs: HallProgram[]) => {
    const activeIds = progs.filter((p) => p.id > 0 && p.enabled !== false).map((p) => p.id)
    if (activeIds.length >= 2) {
      setLocalTrains([
        { id: 1, currentHall: activeIds[0], nextHall: activeIds[1], held: false },
        { id: 2, currentHall: activeIds[activeIds.length - 1], nextHall: activeIds[0], held: false },
      ])
    } else if (activeIds.length === 1) {
      setLocalTrains([
        { id: 1, currentHall: activeIds[0], nextHall: activeIds[0], held: false },
        { id: 2, currentHall: activeIds[0], nextHall: activeIds[0], held: false },
      ])
    }
  }

  const loadPrograms = async () => {
    try {
      setLoading(true)
      const data = await link.getRunLoop(effectiveCoaster)
      const norm = normalizeLoadedPrograms(data.halls || [])
      setPrograms(norm)
      setTrainCount(data.trainCount === 2 ? 2 : 1)
      initDefaultTrainLocations(norm)
    } catch {
      toast.error(`Failed to load ${isCoasterB ? 'Coaster B' : isCoasterA ? 'Coaster A' : 'run loop'} from board`)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    try {
      setSaving(true)
      await link.saveRunLoop({ trainCount, halls: programs }, effectiveCoaster)
      toast.success(`${isCoasterB ? 'Coaster B' : isCoasterA ? 'Coaster A' : 'Run loop'} (${trainCount}-Train Mode) saved to board`)
      addConsoleLog('STORAGE', '#38bdf8', `Program & ${trainCount}-Train Block Zone config written to LittleFS flash.`)
    } catch {
      toast.error('Failed to save run loop')
    } finally {
      setSaving(false)
    }
  }

  const [templateModalOpen, setTemplateModalOpen] = useState(false)

  const handleLoadTemplate = () => {
    setTemplateModalOpen(true)
  }

  const executeLoadTemplate = async () => {
    setTemplateModalOpen(false)
    const targetName = isCoasterB ? 'Coaster B' : isCoasterA ? 'Coaster A' : 'Run Loop'
    try {
      await link.loadDefaultTemplate(effectiveCoaster)
      await loadPrograms()
      toast.success(`${targetName} reset to clean defaults`)
      addConsoleLog('TEMPLATE', '#c084fc', `Reset ${targetName} to clean defaults`)
    } catch {
      toast.error('Failed to reset defaults')
    }
  }

  const currentProg = programs.find((p) => p.id === selectedHallId) || programs[0]

  const updateCurrentProgram = (updated: Partial<HallProgram>) => {
    setPrograms(
      programs.map((p) => (p.id === selectedHallId ? { ...p, ...updated } : p))
    )
  }

  const toggleHallEnabled = (hallId: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation()
    if (hallId === 0) return // Dispatch stays available
    setPrograms((prev) =>
      prev.map((p) => (p.id === hallId ? { ...p, enabled: !p.enabled } : p))
    )
  }

  const setActiveHallCount = (count: number) => {
    const clamped = Math.max(1, Math.min(12, count))
    setPrograms((prev) =>
      prev.map((p) => (p.id === 0 ? p : { ...p, enabled: p.id <= clamped }))
    )
    if (selectedHallId > clamped) {
      setSelectedHallId(clamped)
    }
  }

  const handleAddStep = () => {
    if (!currentProg) return
    const isFirstStage = currentProg.steps.length === 0
    const delayMs = isFirstStage ? 0 : Math.max(100, Math.round(newStageDelaySec * 1000))
    const newSteps = [...currentProg.steps, { delayMs, actions: [] }]
    updateCurrentProgram({ steps: newSteps })
    const targetLabel = selectedHallId === 0 ? 'Dispatch' : `Hall ${selectedHallId}`
    addConsoleLog(
      'PIPELINE',
      '#38bdf8',
      `Added Stage ${newSteps.length} (${isFirstStage ? 'T+0s' : `+${(delayMs / 1000).toFixed(1)}s`}) to ${targetLabel}`
    )
  }

  const handleStepDelayChange = (stepIdx: number, delaySec: number) => {
    if (!currentProg || stepIdx <= 0) return
    const delayMs = Math.max(0, Math.round(delaySec * 1000))
    const steps = currentProg.steps.map((st, idx) =>
      idx === stepIdx ? { ...st, delayMs } : st
    )
    updateCurrentProgram({ steps })
  }

  const handleDeleteStep = (stepIdx: number) => {
    if (!currentProg) return
    const newSteps = currentProg.steps
      .filter((_, idx) => idx !== stepIdx)
      .map((st, idx) => (idx === 0 ? { ...st, delayMs: 0 } : st))
    updateCurrentProgram({ steps: newSteps })
    const targetLabel = selectedHallId === 0 ? 'Dispatch' : `Hall ${selectedHallId}`
    addConsoleLog('PIPELINE', '#94a3b8', `Removed Stage ${stepIdx + 1} from ${targetLabel}`)
  }

  const handleMoveStep = (stepIdx: number, direction: 'up' | 'down') => {
    if (!currentProg) return
    const targetIdx = direction === 'up' ? stepIdx - 1 : stepIdx + 1
    if (targetIdx < 0 || targetIdx >= currentProg.steps.length) return
    const steps = [...currentProg.steps]
    const temp = steps[stepIdx]
    steps[stepIdx] = steps[targetIdx]
    steps[targetIdx] = temp
    steps[0] = { ...steps[0], delayMs: 0 }
    updateCurrentProgram({ steps })
  }

  const openAddActionModal = (stepIdx: number) => {
    setModalStepIdx(stepIdx)
    setEditingActionIdx(null)
    setActionType('motor')
    setActionMotor(isCoasterB ? 5 : 1)
    setActionMotorOp('start')
    setActionPwm(100)
    setActionDir('fwd')
    setActionDurationMs(2000)
    setActionServo(isCoasterB ? 4 : 1)
    setActionAngle(90)
    setActionServoSpeed(100)
    setActionTimeoutMs(10000)
    setActionWledPreset(1)
    setModalOpen(true)
  }

  const openEditActionModal = (stepIdx: number, actIdx: number, act: StepAction) => {
    setModalStepIdx(stepIdx)
    setEditingActionIdx(actIdx)
    setActionType(act.type)
    if (act.type === 'motor') {
      setActionMotor(act.motor || (isCoasterB ? 5 : 1))
      const op = act.op === 'stop' || act.op === 'runTime' ? act.op : 'start'
      setActionMotorOp(op)
      setActionPwm(act.pwm ?? 100)
      setActionDir(act.dir || 'fwd')
      setActionDurationMs(act.durationMs || 2000)
    } else if (act.type === 'servo') {
      setActionServo(act.servo || (isCoasterB ? 4 : 1))
      setActionAngle(act.angle ?? 90)
      setActionServoSpeed(act.speed || 100)
    } else if (act.type === 'delay') {
      setActionDurationMs(act.durationMs || 1000)
    } else if (act.type === 'waitDispatch') {
      setActionTimeoutMs(act.timeoutMs || 0)
    } else if (act.type === 'wled') {
      setActionWledPreset(act.preset || 1)
    }
    setModalOpen(true)
  }

  const handleConfirmAddAction = () => {
    if (modalStepIdx === null || !currentProg) return

    let act: StepAction
    if (actionType === 'motor') {
      act = {
        type: 'motor',
        motor: actionMotor,
        op: actionMotorOp,
        pwm: actionPwm,
        dir: actionDir,
        durationMs: actionMotorOp === 'runTime' ? actionDurationMs : 0,
      }
    } else if (actionType === 'servo') {
      act = {
        type: 'servo',
        servo: actionServo,
        op: 'set',
        angle: actionAngle,
        speed: actionServoSpeed,
        durationMs: 600,
      }
    } else if (actionType === 'delay') {
      act = {
        type: 'delay',
        durationMs: actionDurationMs,
      }
    } else if (actionType === 'waitDispatch') {
      act = {
        type: 'waitDispatch',
        timeoutMs: actionTimeoutMs,
      }
    } else {
      act = {
        type: 'wled',
        target: 'all',
        preset: actionWledPreset,
      }
    }

    const steps = [...currentProg.steps]
    if (editingActionIdx !== null) {
      steps[modalStepIdx].actions[editingActionIdx] = act
      addConsoleLog('ACTION', '#38bdf8', `Updated action in Stage ${modalStepIdx + 1}`)
    } else {
      steps[modalStepIdx] = {
        ...steps[modalStepIdx],
        actions: [...steps[modalStepIdx].actions, act],
      }
      addConsoleLog('ACTION', '#38bdf8', `Appended ${act.type.toUpperCase()} action to Stage ${modalStepIdx + 1}`)
    }

    updateCurrentProgram({ steps })
    setModalOpen(false)
  }

  const handleDeleteAction = (stepIdx: number, actionIdx: number) => {
    if (!currentProg) return
    const steps = [...currentProg.steps]
    steps[stepIdx] = {
      ...steps[stepIdx],
      actions: steps[stepIdx].actions.filter((_, idx) => idx !== actionIdx),
    }
    updateCurrentProgram({ steps })
  }

  const handleDispatch = () => {
    if (isCoasterB) {
      send({ c: 'dispatchB' })
      toast.success('Coaster B Dispatch triggered!')
      addConsoleLog('DISPATCH', '#f59e0b', 'Coaster B manual dispatch initiated')
    } else if (isCoasterA) {
      send({ c: 'dispatchA' })
      toast.success('Coaster A Dispatch triggered!')
      addConsoleLog('DISPATCH', '#f59e0b', 'Coaster A manual dispatch initiated')
    } else {
      send({ c: 'dispatch' })
      toast.success('Dispatch triggered!')
      addConsoleLog('DISPATCH', '#f59e0b', 'Manual dispatch initiated.')
    }

    if (animTimerRef.current) clearTimeout(animTimerRef.current)
    const activeHalls = programs.filter((p) => p.id > 0 && p.enabled)
    if (sensorCoords[0]) setTrainPos(sensorCoords[0])
    activeHalls.slice(0, 4).forEach((h, idx) => {
      setTimeout(() => {
        if (sensorCoords[h.id]) setTrainPos(sensorCoords[h.id])
      }, (idx + 1) * 750)
    })
  }

  const handleTestHall = () => {
    if (selectedHallId === 0) {
      handleDispatch()
      return
    }
    if (isCoasterB) {
      send({ c: 'testHallB', id: selectedHallId })
      toast.info(`Test-firing Coaster B Hall ${selectedHallId} (Physical H${selectedHallId + 6})`)
    } else if (isCoasterA) {
      send({ c: 'testHallA', id: selectedHallId })
      toast.info(`Test-firing Coaster A Hall ${selectedHallId} (Physical H${selectedHallId})`)
    } else {
      send({ c: 'testHall', id: selectedHallId })
      toast.info(`Test-fired Hall ${selectedHallId} (${getHallInfo(selectedHallId).pin})`)
    }
    addConsoleLog('SIMULATE', '#34d399', `Manual test pulse triggered for Hall ${selectedHallId}`)

    if (sensorCoords[selectedHallId]) {
      setTrainPos(sensorCoords[selectedHallId])
    }

    // Immediate local block-zone preview update
    const activeIds = programs.filter((p) => p.id > 0 && p.enabled !== false).map((p) => p.id)
    if (activeIds.length > 0) {
      const idxInActive = activeIds.indexOf(selectedHallId)
      const nextH = idxInActive >= 0 ? activeIds[(idxInActive + 1) % activeIds.length] : activeIds[0]
      setLocalTrains((prev) => {
        if (trainCount <= 1) {
          return [
            { id: 1, currentHall: selectedHallId, nextHall: nextH, held: false },
            prev[1] || { id: 2, currentHall: activeIds[activeIds.length - 1], nextHall: activeIds[0], held: false },
          ]
        }
        const t0 = prev[0] || { id: 1, currentHall: activeIds[0], nextHall: activeIds[1] ?? activeIds[0], held: false }
        const t1 = prev[1] || { id: 2, currentHall: activeIds[activeIds.length - 1], nextHall: activeIds[0], held: false }
        const nextArr = [{ ...t0 }, { ...t1 }]
        let arrivingIdx = 0
        if (nextArr[0].nextHall === selectedHallId && !nextArr[0].held) arrivingIdx = 0
        else if (nextArr[1].nextHall === selectedHallId && !nextArr[1].held) arrivingIdx = 1
        else if (nextArr[0].currentHall === selectedHallId) arrivingIdx = 0
        else if (nextArr[1].currentHall === selectedHallId) arrivingIdx = 1
        const otherIdx = arrivingIdx === 0 ? 1 : 0
        nextArr[arrivingIdx] = { id: arrivingIdx + 1, currentHall: selectedHallId, nextHall: nextH, held: false }
        if (nextArr[otherIdx].held && nextArr[arrivingIdx].currentHall !== nextArr[otherIdx].currentHall) {
          const holdH = nextArr[otherIdx].currentHall
          const holdIdx = activeIds.indexOf(holdH)
          nextArr[otherIdx].held = false
          nextArr[otherIdx].nextHall = holdIdx >= 0 ? activeIds[(holdIdx + 1) % activeIds.length] : activeIds[0]
        }
        const nextOccupied =
          nextArr[otherIdx].currentHall === selectedHallId ||
          (nextArr[otherIdx].currentHall === nextH && nextArr[otherIdx].held)
        if (nextOccupied && currentProg?.isBlockHold) {
          nextArr[arrivingIdx].held = true
        }
        return nextArr
      })
    }
  }

  // Software Quick-Toggle for any Motor (1..6) or Servo (1..6)
  const handleQuickMotorToggle = (mId: number) => {
    const mState = state?.motors?.[mId - 1]
    const isOn = (mState?.pwm ?? 0) > 0 || (mState?.target ?? 0) > 0
    if (isOn) {
      send({ c: 'motorStop', id: mId })
      toast.info(`Motor ${mId} toggled OFF`)
    } else {
      send({ c: 'motor', id: mId, pwm: 100, dir: 'fwd' })
      toast.info(`Motor ${mId} toggled ON (100% PWM)`)
    }
  }

  const handleQuickServoToggle = (sId: number) => {
    const sState = state?.servos?.[sId - 1]
    const nextAngle = (sState?.target ?? 0) > 90 ? 0 : 180
    send({ c: 'servo', id: sId, angle: nextAngle, speed: 100 })
    toast.info(`Servo ${sId} toggled to ${nextAngle}°`)
  }

  // Live Sequencer Status
  const runloopState = isCoasterB ? state?.runloopB : isCoasterA ? (state?.runloopA ?? state?.runloop) : state?.runloop
  const isRunning = runloopState?.running ?? false
  const isWaitingDispatch = runloopState?.waitingDispatch ?? false
  const activeHallNow = (runloopState?.activeStep ?? -1) >= 0 ? (runloopState?.activeHall ?? -1) : -1

  const isCoasterAWaiting = (state?.runloopA?.waitingDispatch ?? false) || (state?.runloop?.waitingDispatch ?? false)
  const isCoasterBWaiting = state?.runloopB?.waitingDispatch ?? false
  const bothWaiting = isDueling && isCoasterAWaiting && isCoasterBWaiting

  const motorOptions = isCoasterB
    ? [
        { id: 4, label: 'Motor 4 (MOSFET)' },
        { id: 5, label: 'Motor 5 (MOSFET)' },
        { id: 6, label: 'Motor 6 (MOSFET)' },
      ]
    : isCoasterA
    ? [
        { id: 1, label: 'Motor 1 (Reversible H-Bridge)' },
        { id: 2, label: 'Motor 2 (Reversible H-Bridge)' },
        { id: 3, label: 'Motor 3 (MOSFET)' },
      ]
    : MOTORS.map((m) => ({
        id: m.id,
        label: m.reversible ? `${m.name} (Reversible H-Bridge)` : `${m.name} (MOSFET)`,
      }))

  const servoOptions = isCoasterB
    ? [
        { id: 4, label: 'Servo 4' },
        { id: 5, label: 'Servo 5' },
        { id: 6, label: 'Servo 6' },
      ]
    : isCoasterA
    ? [
        { id: 1, label: 'Servo 1' },
        { id: 2, label: 'Servo 2' },
        { id: 3, label: 'Servo 3' },
      ]
    : SERVOS.map((s) => ({ id: s.id, label: s.name }))

  const selectedHallMeta =
    selectedHallId === 0
      ? { id: 0, name: 'Dispatch', pin: 'Main Bar / Panel Pin', zone: 'Intro Trigger' }
      : getHallInfo(selectedHallId)

  // Only active halls (enabled !== false) are drawn on the Track Schematic SVG
  const activeHallPrograms = programs.filter((p) => p.id > 0 && p.enabled !== false)
  const activeTrackPoints = activeHallPrograms.map(
    (p) => sensorCoords[p.id] || DEFAULT_SENSOR_COORDS[p.id] || { x: 460, y: 90 }
  )
  const dynamicTrackPath = customSvgTrack
    ? customSvgTrack.pathD
    : activeTrackPoints.length >= 3
    ? buildClosedSplinePath(activeTrackPoints, 0.22)
    : 'M 70 90 C 150 20, 240 20, 340 60 C 440 100, 540 145, 640 130 C 740 110, 840 40, 860 85 C 880 125, 830 155, 680 155 C 480 155, 200 155, 70 90 Z'

  const dispatchCoord = sensorCoords[0] || DEFAULT_SENSOR_COORDS[0]
  const firstActiveHallCoord = activeTrackPoints[0] || sensorCoords[1] || DEFAULT_SENSOR_COORDS[1]

  /**
   * Compute the exact coordinate IN BETWEEN `fromHallId` and `toHallId` along the curved coaster rail
   * (either on the user's imported SVG vector or on the Catmull-Rom cubic Bezier spline).
   */
  const getBlockZoneMidpoint = (fromHallId: number, toHallId: number): { x: number; y: number } => {
    const p1 = sensorCoords[fromHallId] || DEFAULT_SENSOR_COORDS[fromHallId] || { x: 185, y: 46 }
    const p2 = sensorCoords[toHallId] || DEFAULT_SENSOR_COORDS[toHallId] || p1
    if (fromHallId === toHallId) return p1

    // 1. If a custom SVG track vector is loaded, walk halfway along its sampled points from p1 to p2
    if (customSvgTrack && customSvgTrack.samples.length > 4) {
      const samples = customSvgTrack.samples
      const n = samples.length
      let idx1 = 0
      let idx2 = 0
      let best1 = Infinity
      let best2 = Infinity
      for (let i = 0; i < n; i++) {
        const d1 = (samples[i].x - p1.x) ** 2 + (samples[i].y - p1.y) ** 2
        if (d1 < best1) {
          best1 = d1
          idx1 = i
        }
        const d2 = (samples[i].x - p2.x) ** 2 + (samples[i].y - p2.y) ** 2
        if (d2 < best2) {
          best2 = d2
          idx2 = i
        }
      }
      const fwdSteps = (idx2 - idx1 + n) % n
      const midIdx = (idx1 + Math.floor(fwdSteps / 2)) % n
      return { x: Math.round(samples[midIdx].x), y: Math.round(samples[midIdx].y) }
    }

    // 2. Otherwise evaluate the exact Catmull-Rom Cubic Bezier midpoint (t = 0.5) between active halls
    const n = activeHallPrograms.length
    const idx = activeHallPrograms.findIndex((p) => p.id === fromHallId)
    if (idx !== -1 && n >= 3) {
      const pt0 = activeTrackPoints[(idx - 1 + n) % n]
      const pt1 = activeTrackPoints[idx]
      const pt2 = activeTrackPoints[(idx + 1) % n]
      const pt3 = activeTrackPoints[(idx + 2) % n]
      const tension = 0.22
      const cp1x = pt1.x + (pt2.x - pt0.x) * tension
      const cp1y = pt1.y + (pt2.y - pt0.y) * tension
      const cp2x = pt2.x - (pt3.x - pt1.x) * tension
      const cp2y = pt2.y - (pt3.y - pt1.y) * tension
      return {
        x: Math.round(0.125 * pt1.x + 0.375 * cp1x + 0.375 * cp2x + 0.125 * pt2.x),
        y: Math.round(0.125 * pt1.y + 0.375 * cp1y + 0.375 * cp2y + 0.125 * pt2.y),
      }
    }

    return {
      x: Math.round((p1.x + p2.x) / 2),
      y: Math.round((p1.y + p2.y) / 2),
    }
  }

  /** Build cubic Bezier path string for a single block zone segment (from activeHall[idx] to activeHall[idx+1]) */
  const getBlockSegmentPath = (idx: number): string => {
    const n = activeTrackPoints.length
    if (n < 2 || idx < 0 || idx >= n) return ''
    if (customSvgTrack && customSvgTrack.samples.length > 4) {
      const p1 = activeTrackPoints[idx]
      const p2 = activeTrackPoints[(idx + 1) % n]
      const samples = customSvgTrack.samples
      const sn = samples.length
      let idx1 = 0
      let idx2 = 0
      let b1 = Infinity
      let b2 = Infinity
      for (let i = 0; i < sn; i++) {
        const d1 = (samples[i].x - p1.x) ** 2 + (samples[i].y - p1.y) ** 2
        if (d1 < b1) {
          b1 = d1
          idx1 = i
        }
        const d2 = (samples[i].x - p2.x) ** 2 + (samples[i].y - p2.y) ** 2
        if (d2 < b2) {
          b2 = d2
          idx2 = i
        }
      }
      const fwdSteps = (idx2 - idx1 + sn) % sn
      if (fwdSteps === 0) return ''
      let d = `M ${samples[idx1].x} ${samples[idx1].y}`
      for (let s = 1; s <= fwdSteps; s++) {
        const pt = samples[(idx1 + s) % sn]
        d += ` L ${pt.x} ${pt.y}`
      }
      return d
    }
    if (n === 2) {
      const p1 = activeTrackPoints[idx]
      const p2 = activeTrackPoints[(idx + 1) % 2]
      const mx = (p1.x + p2.x) / 2
      const my = (p1.y + p2.y) / 2 + (idx === 0 ? -45 : 45)
      return `M ${p1.x} ${p1.y} Q ${mx} ${my}, ${p2.x} ${p2.y}`
    }
    const p0 = activeTrackPoints[(idx - 1 + n) % n]
    const p1 = activeTrackPoints[idx]
    const p2 = activeTrackPoints[(idx + 1) % n]
    const p3 = activeTrackPoints[(idx + 2) % n]
    const tension = 0.22
    const cp1x = p1.x + (p2.x - p0.x) * tension
    const cp1y = p1.y + (p2.y - p0.y) * tension
    const cp2x = p2.x - (p3.x - p1.x) * tension
    const cp2y = p2.y - (p3.y - p1.y) * tension
    return `M ${p1.x.toFixed(1)} ${p1.y.toFixed(1)} C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`
  }

  // Active trains to render on the schematic (1 Train or 2 Trains)
  const displayedTrains: TrainTrackerStatus[] = (
    runloopState?.trains && runloopState.trains.length > 0 ? runloopState.trains : localTrains
  ).slice(0, trainCount)

  // Helper to compute cumulative time offset (ms) up to stepIdx
  const getCumulativeOffsetMs = (stepIdx: number): number => {
    if (!currentProg) return 0
    let total = 0
    for (let i = 1; i <= stepIdx; i++) {
      total += currentProg.steps[i]?.delayMs ?? 500
    }
    return total
  }

  return (
    <div className={styles.page}>
      {/* ---------------- Top Command Center Hero Strip ---------------- */}
      <div className={styles.heroCard}>
        <div className={styles.heroContent}>
          <div className={styles.heroLeft}>
            <div className={styles.heroIconBox}>
              <Zap className={styles.heroIcon} />
            </div>
            <div>
              <div className={styles.heroTitleRow}>
                <h1 className={styles.heroTitle}>
                  {isCoasterB ? 'Coaster B Sequencer' : isCoasterA ? 'Coaster A Sequencer' : 'Run Loop Sequence Editor'}
                </h1>
                <span className={styles.runningBadge}>
                  <span className={styles.runningDot} />
                  {isWaitingDispatch ? 'WAITING FOR DISPATCH' : isRunning ? 'RUNNING' : 'STANDBY / PAUSED'}
                </span>
                <span className={styles.syncedBadge}>LittleFS // Synced</span>
              </div>
              <p className={styles.heroSub}>
                {isCoasterB
                  ? 'Track B: Motors 4–6, Servos 4–6, Dispatch + Sensor Triggers 1–6 (Physical Halls 7–12)'
                  : isCoasterA
                  ? 'Track A: Motors 1–3, Servos 1–3, Dispatch + Sensor Triggers 1–6 (Physical Halls 1–6)'
                  : 'Configure Dispatch intro actions and Hall 1–12 sensor stages with customizable timing.'}
              </p>
            </div>
          </div>

          {/* Global Sequencer Actions */}
          <div className={styles.heroActions}>
            <button
              type="button"
              id="dispatch-btn"
              className={styles.dispatchBtn}
              onClick={handleDispatch}
              title="Trigger Dispatch sequence or release a station hold"
              aria-label="Dispatch train"
            >
              <Zap className={styles.dispatchBtnIcon} />
              <span className={styles.dispatchTextDesktop}>
                {isCoasterB ? 'Dispatch B' : isCoasterA ? 'Dispatch A' : 'Dispatch'}
              </span>
              <span className={styles.dispatchTextMobile}>Dispatch</span>
            </button>

            {/* In Dueling Mode: Duel Launch Button */}
            {isDueling && (
              <button
                type="button"
                className={styles.duelLaunchNowBtn}
                onClick={async () => {
                  await link.dispatchBoth()
                  send({ c: 'dispatchBoth' })
                  toast.success('🏁 DUEL DISPATCH: Both coasters launched!')
                }}
              >
                Duel Dispatch (Both)
              </button>
            )}

            {/* Pause / Start Loop Button */}
            <button
              type="button"
              className={`${styles.secondaryBtn} ${isRunning ? styles.pauseToggleRunning : styles.pauseTogglePaused}`}
              onClick={() => {
                if (isRunning) {
                  if (isCoasterB) send({ c: 'stopLoopB' })
                  else if (isCoasterA) send({ c: 'stopLoopA' })
                  else send({ c: 'stopLoop' })
                  toast.info('Run loop paused')
                  addConsoleLog('SEQUENCER', '#f59e0b', 'Run loop paused by operator')
                } else {
                  if (isCoasterB) send({ c: 'startLoopB' })
                  else if (isCoasterA) send({ c: 'startLoopA' })
                  else send({ c: 'startLoop' })
                  toast.success('Run loop started')
                  addConsoleLog('SEQUENCER', '#34d399', 'Run loop active')
                }
              }}
              title={isRunning ? 'Pause automatic sensor execution' : 'Start automatic sensor execution'}
              aria-label={isRunning ? 'Pause automatic sequencer' : 'Start automatic sequencer'}
            >
              {isRunning ? <Pause size={15} /> : <Play size={15} />}
              <span className={styles.btnLabelDesktop}>{isRunning ? 'Pause Loop' : 'Start Loop'}</span>
            </button>

            {/* Clear / Reset Defaults Button */}
            <button
              type="button"
              className={styles.secondaryBtn}
              onClick={handleLoadTemplate}
              title="Reset all sensor stages and names to clean defaults"
              aria-label="Reset to clean defaults"
            >
              <RotateCcw size={15} />
              <span className={styles.btnLabelDesktop}>Reset Clean</span>
            </button>

            {/* Save Button */}
            <button
              type="button"
              className={styles.secondaryBtn}
              onClick={handleSave}
              disabled={saving}
              title="Persist sequence configuration to ESP32-S3 LittleFS"
              aria-label="Save sequence configuration"
            >
              <Save size={15} />
              <span className={styles.btnLabelDesktop}>{saving ? 'Saving...' : 'Save'}</span>
            </button>
          </div>
        </div>

        {/* Coaster Switcher Tabs in Dueling Mode */}
        {isDueling && (
          <div className={styles.coasterSwitcher}>
            <a
              href={href('run-a')}
              className={`${styles.coasterTab} ${isCoasterA ? styles.coasterTabActive : ''}`}
            >
              <span>🔵 Coaster A (Track 1)</span>
            </a>
            <a
              href={href('run-b')}
              className={`${styles.coasterTab} ${isCoasterB ? styles.coasterTabActive : ''}`}
            >
              <span>🔴 Coaster B (Track 2)</span>
            </a>
          </div>
        )}
      </div>

      {/* Duel Dispatch Ready Alert Banner */}
      {bothWaiting && (
        <div className={styles.duelBanner}>
          <div className={styles.duelBannerLeft}>
            <span className={styles.duelIcon}>🏁</span>
            <div>
              <div className={styles.duelTitle}>READY TO DUEL! BOTH TRAINS LOCKED AT STATION</div>
              <div className={styles.duelSub}>
                Both Track A and Track B trains are holding for dispatch. Press below for synchronous launch!
              </div>
            </div>
          </div>
          <button
            type="button"
            className={styles.duelLaunchNowBtn}
            onClick={async () => {
              await link.dispatchBoth()
              send({ c: 'dispatchBoth' })
              toast.success('🏁 DUEL DISPATCH: Both coasters launched!')
            }}
          >
            Launch Duel Dispatch Now
          </button>
        </div>
      )}

      {/* Mobile Horizontal Sensor Selector Chips */}
      <div className={styles.mobileSensorChipsScroll}>
        {programs.map((prog) => {
          const isSelected = prog.id === selectedHallId
          const hasSteps = prog.steps && prog.steps.length > 0
          return (
            <button
              key={prog.id}
              type="button"
              className={`${styles.mobileChip} ${isSelected ? styles.mobileChipSelected : ''}`}
              onClick={() => setSelectedHallId(prog.id)}
              style={prog.id > 0 && !prog.enabled ? { opacity: 0.45 } : undefined}
            >
              {hasSteps && <span className={styles.configuredDot} />}
              <span>{prog.id === 0 ? '⚡ Dispatch' : `H${prog.id}`}</span>
            </button>
          )
        })}
      </div>
      <div className={styles.mobileSelectedSensorLabel}>
        Selected: {selectedHallId === 0 ? 'Dispatch Button' : `Hall ${selectedHallId}`} · {currentProg?.name || selectedHallMeta.name} ({selectedHallMeta.pin})
      </div>

      {/* ==========================================================================
         Desktop 2-Column Workspace Grid / Mobile Workflow
         ========================================================================== */}
      <div className={styles.workspaceGrid}>
        {/* ================= RIGHT COLUMN / MOBILE PRIMARY: SEQUENCE PIPELINE EDITOR ================= */}
        <div className={styles.rightCol}>
          {loading ? (
            <div className={styles.panel}>Loading sequence definitions from board...</div>
          ) : currentProg ? (
            <div className={styles.editorCard}>
              {/* Header: Badge, Inline Editable Heading, Interrupt Pin Info */}
              <div className={styles.editorHeader}>
                <div className={styles.editorHeaderLeft}>
                  <div
                    className={styles.editorHallBadge}
                    style={
                      currentProg.id === 0
                        ? { background: 'linear-gradient(135deg, #f59e0b, #ea580c)', color: '#fff', minWidth: '88px', padding: '0 10px' }
                        : undefined
                    }
                  >
                    {currentProg.id === 0 ? '⚡ DISP' : `H${currentProg.id}`}
                  </div>
                  <div className={styles.editorNameGroup}>
                    <div className={styles.inlineNameWrap}>
                      <input
                        type="text"
                        className={styles.inlineNameHeading}
                        value={currentProg.name}
                        onChange={(e) => updateCurrentProgram({ name: e.target.value })}
                        placeholder={selectedHallMeta.name}
                        aria-label="Sensor Name"
                      />
                      <Edit2 size={15} className={styles.namePencilIcon} />
                    </div>
                    <span className={styles.editorPinNote}>
                      {currentProg.id === 0
                        ? 'Intro Trigger: Runs when you press the Dispatch button on the top bar or control panel'
                        : `Input: ${selectedHallMeta.pin} · Active-Low Hall Sensor`}
                    </span>
                  </div>
                </div>

                {/* Right Controls: Active Toggle + WLED Preset Dropdown + Test Fire */}
                <div className={styles.editorHeaderRight}>
                  {currentProg.id > 0 && (
                    <button
                      type="button"
                      className={styles.secondaryBtn}
                      onClick={() => updateCurrentProgram({ enabled: !currentProg.enabled })}
                      style={{
                        height: '34px',
                        padding: '0 10px',
                        fontSize: '12px',
                        borderColor: currentProg.enabled ? 'rgba(16, 185, 129, 0.45)' : 'var(--border)',
                        color: currentProg.enabled ? '#10b981' : 'var(--text-3)',
                      }}
                      title={
                        currentProg.enabled
                          ? 'Hall is Active (shown on Track Schematic). Click to disable & hide from schematic.'
                          : 'Hall is Inactive (hidden from Track Schematic). Click to enable.'
                      }
                    >
                      {currentProg.enabled ? <Eye size={14} /> : <EyeOff size={14} />}
                      <span>{currentProg.enabled ? 'Active on Track' : 'Hidden / Inactive'}</span>
                    </button>
                  )}

                  <div className={styles.wledSelectorWrap}>
                    <Palette className={styles.wledIcon} />
                    <span className={styles.wledLabel}>WLED Preset:</span>
                    <select
                      className={styles.wledSelect}
                      value={currentProg.wledPreset}
                      onChange={(e) => updateCurrentProgram({ wledPreset: parseInt(e.target.value, 10) || 0 })}
                    >
                      <option value={0}>None</option>
                      <option value={1}>Preset 1</option>
                      <option value={2}>Preset 2</option>
                      <option value={3}>Preset 3</option>
                      <option value={4}>Preset 4</option>
                      <option value={5}>Preset 5</option>
                      <option value={6}>Preset 6</option>
                    </select>
                  </div>

                  <button
                    type="button"
                    className={styles.testFireBtn}
                    onClick={handleTestHall}
                    title="Test-fire this sequence right now"
                  >
                    <Radio size={14} />
                    <span>{currentProg.id === 0 ? 'Test Dispatch' : `Test Fire H${currentProg.id}`}</span>
                  </button>
                </div>
              </div>

              {/* Block Zone Stop/Start Hold Point Configuration Bar (for Hall 1..12) */}
              {currentProg.id > 0 && (
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px',
                    padding: '10px 16px',
                    borderBottom: '1px solid var(--border)',
                    background: currentProg.isBlockHold
                      ? 'rgba(245, 158, 11, 0.08)'
                      : 'var(--surface-container-high)',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      flexWrap: 'wrap',
                      gap: '10px',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                      <Shield size={15} color={currentProg.isBlockHold ? '#f59e0b' : 'var(--text-3)'} />
                      <span style={{ fontSize: '12.5px', fontWeight: 700, color: 'var(--text)' }}>
                        Block Zone Hold Point (Stop &amp; Start Train):
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          updateCurrentProgram({
                            isBlockHold: !currentProg.isBlockHold,
                            blockMotorId: currentProg.blockMotorId || (isCoasterB ? 5 : 1),
                            blockMotorPwm: currentProg.blockMotorPwm || 100,
                          })
                        }
                        style={{
                          padding: '4px 10px',
                          borderRadius: '6px',
                          fontSize: '12px',
                          fontWeight: 700,
                          cursor: 'pointer',
                          border: currentProg.isBlockHold
                            ? '1px solid #f59e0b'
                            : '1px solid var(--border-strong)',
                          background: currentProg.isBlockHold
                            ? 'rgba(245, 158, 11, 0.18)'
                            : 'var(--surface)',
                          color: currentProg.isBlockHold ? '#fbbf24' : 'var(--text-2)',
                        }}
                      >
                        {currentProg.isBlockHold
                          ? '🛑 Block Hold Point: ENABLED'
                          : 'Off (Pass-Through Sensor)'}
                      </button>
                    </div>

                    <span style={{ fontSize: '11.5px', color: 'var(--text-3)' }}>
                      {currentProg.isBlockHold
                        ? 'Holds approaching train here if the next block zone ahead is occupied, then auto-starts when clear.'
                        : 'Enable to let this Hall stop & hold a train until the next block zone ahead is clear.'}
                    </span>
                  </div>

                  {currentProg.isBlockHold && (
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        gap: '12px',
                        paddingTop: '4px',
                        fontSize: '12px',
                      }}
                    >
                      <label style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>Hold/Drive Motor:</span>
                        <select
                          value={currentProg.blockMotorId ?? 1}
                          onChange={(e) =>
                            updateCurrentProgram({ blockMotorId: parseInt(e.target.value, 10) })
                          }
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            border: '1px solid var(--border-strong)',
                            background: 'var(--surface)',
                            color: 'var(--text)',
                            fontWeight: 700,
                            fontSize: '12px',
                          }}
                        >
                          <option value={0}>Auto (From Stages)</option>
                          {motorOptions.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.label}
                            </option>
                          ))}
                        </select>
                      </label>

                      {(currentProg.blockMotorId ?? 1) > 0 && (
                        <>
                          <label style={{ display: 'inline-flex', alignItems: 'center', gap: '5px' }}>
                            <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>Release PWM:</span>
                            <input
                              type="number"
                              min={10}
                              max={100}
                              step={5}
                              value={currentProg.blockMotorPwm ?? 100}
                              onChange={(e) =>
                                updateCurrentProgram({
                                  blockMotorPwm: Math.max(10, Math.min(100, parseInt(e.target.value, 10) || 100)),
                                })
                              }
                              style={{
                                width: '56px',
                                padding: '3px 6px',
                                borderRadius: '6px',
                                border: '1px solid var(--border-strong)',
                                background: 'var(--surface)',
                                color: 'var(--text)',
                                fontWeight: 700,
                                fontSize: '12px',
                              }}
                            />
                            <span>%</span>
                          </label>

                          {(currentProg.blockMotorId ?? 1) <= 2 && (
                            <label style={{ display: 'inline-flex', alignItems: 'center', gap: '5px' }}>
                              <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>Dir:</span>
                              <select
                                value={currentProg.blockMotorDir ?? 'fwd'}
                                onChange={(e) =>
                                  updateCurrentProgram({ blockMotorDir: e.target.value as 'fwd' | 'rev' })
                                }
                                style={{
                                  padding: '4px 8px',
                                  borderRadius: '6px',
                                  border: '1px solid var(--border-strong)',
                                  background: 'var(--surface)',
                                  color: 'var(--text)',
                                  fontWeight: 700,
                                  fontSize: '12px',
                                }}
                              >
                                <option value="fwd">FWD</option>
                                <option value="rev">REV</option>
                              </select>
                            </label>
                          )}
                        </>
                      )}

                      <label style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>Brake Servo:</span>
                        <select
                          value={currentProg.blockServoId ?? 0}
                          onChange={(e) =>
                            updateCurrentProgram({ blockServoId: parseInt(e.target.value, 10) })
                          }
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            border: '1px solid var(--border-strong)',
                            background: 'var(--surface)',
                            color: 'var(--text)',
                            fontWeight: 700,
                            fontSize: '12px',
                          }}
                        >
                          <option value={0}>None</option>
                          {servoOptions.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.label}
                            </option>
                          ))}
                        </select>
                      </label>

                      {(currentProg.blockServoId ?? 0) > 0 && (
                        <>
                          <label style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                            <span style={{ color: 'var(--text-2)' }}>Hold°:</span>
                            <input
                              type="number"
                              min={0}
                              max={180}
                              value={currentProg.blockHoldAngle ?? 0}
                              onChange={(e) =>
                                updateCurrentProgram({ blockHoldAngle: parseInt(e.target.value, 10) || 0 })
                              }
                              style={{
                                width: '50px',
                                padding: '3px 5px',
                                borderRadius: '6px',
                                border: '1px solid var(--border-strong)',
                                background: 'var(--surface)',
                                color: 'var(--text)',
                                fontWeight: 700,
                                fontSize: '12px',
                              }}
                            />
                          </label>
                          <label style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                            <span style={{ color: 'var(--text-2)' }}>Release°:</span>
                            <input
                              type="number"
                              min={0}
                              max={180}
                              value={currentProg.blockReleaseAngle ?? 90}
                              onChange={(e) =>
                                updateCurrentProgram({ blockReleaseAngle: parseInt(e.target.value, 10) || 90 })
                              }
                              style={{
                                width: '50px',
                                padding: '3px 5px',
                                borderRadius: '6px',
                                border: '1px solid var(--border-strong)',
                                background: 'var(--surface)',
                                color: 'var(--text)',
                                fontWeight: 700,
                                fontSize: '12px',
                              }}
                            />
                          </label>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Horizontal Time Axis / Stage Offset Timeline */}
              {currentProg.steps.length > 0 && (
                <div className={styles.timelineStrip}>
                  <div className={styles.timelineHead}>
                    <Timer size={13} className={styles.timelineIcon} />
                    <span className={styles.timelineTitle}>CONCURRENT STAGE TIMELINE</span>
                  </div>
                  <div className={styles.timelineRuler}>
                    {currentProg.steps.map((st, sIdx) => {
                      const offsetMs = getCumulativeOffsetMs(sIdx)
                      const isCurrentActive = activeHallNow === selectedHallId && (runloopState?.activeStep ?? 0) === sIdx
                      return (
                        <div
                          key={sIdx}
                          className={`${styles.timelineNode} ${isCurrentActive ? styles.timelineNodeActive : ''}`}
                        >
                          <div className={styles.timelineDotWrap}>
                            <span className={styles.timelineDot} />
                            {sIdx < currentProg.steps.length - 1 && <span className={styles.timelineConnector} />}
                          </div>
                          <div className={styles.timelineLabelGroup}>
                            <span className={styles.timelineTime}>
                              T+{(offsetMs / 1000).toFixed(offsetMs % 1000 === 0 ? 1 : 2)}s ({offsetMs}ms)
                            </span>
                            <span className={styles.timelineStageName}>
                              Stage {sIdx + 1} ({st.actions.length} act{st.actions.length === 1 ? '' : 's'})
                            </span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Timed Stages Pipeline */}
              <div className={styles.stagesList}>
                {currentProg.steps.length === 0 ? (
                  <div className={styles.emptyStages}>
                    No actions configured for {currentProg.id === 0 ? 'Dispatch' : currentProg.name || `Hall ${selectedHallId}`}. Add a stage below to configure what happens when triggered.
                  </div>
                ) : (
                  currentProg.steps.map((step, stepIdx) => {
                    const isStepActive = activeHallNow === selectedHallId && (runloopState?.activeStep ?? 0) === stepIdx
                    const cumulativeMs = getCumulativeOffsetMs(stepIdx)
                    const stepDelaySec = ((step.delayMs ?? 500) / 1000)
                    return (
                      <div
                        key={stepIdx}
                        className={`${styles.stageBlock} ${isStepActive ? styles.stageBlockActive : ''}`}
                      >
                        <div className={styles.stageHead}>
                          <div className={styles.stageTitleGroup}>
                            <span className={styles.stageNumber}>{stepIdx + 1}</span>
                            <div className={styles.stageLabels} style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                              <h3 className={styles.stageTitle}>Stage {stepIdx + 1}</h3>
                              <span className={styles.stageOffsetBadge}>
                                {stepIdx === 0
                                  ? 'Immediate · T+0.0s'
                                  : `Triggers at T+${(cumulativeMs / 1000).toFixed(2)}s (${cumulativeMs}ms)`}
                              </span>
                              {stepIdx > 0 && (
                                <label
                                  style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '5px',
                                    fontSize: '12px',
                                    color: 'var(--text-2)',
                                    background: 'var(--surface-container-high)',
                                    padding: '2px 8px',
                                    borderRadius: '6px',
                                    border: '1px solid var(--border)',
                                  }}
                                  title="Delay after previous stage before this stage executes"
                                >
                                  <span>Wait +</span>
                                  <input
                                    type="number"
                                    min={0.1}
                                    max={120}
                                    step={0.1}
                                    value={stepDelaySec}
                                    onChange={(e) => handleStepDelayChange(stepIdx, parseFloat(e.target.value) || 0.5)}
                                    style={{
                                      width: '54px',
                                      background: 'var(--surface)',
                                      color: 'var(--text)',
                                      border: '1px solid var(--border-strong)',
                                      borderRadius: '4px',
                                      padding: '1px 4px',
                                      fontSize: '12px',
                                      fontWeight: 700,
                                    }}
                                  />
                                  <span>sec</span>
                                </label>
                              )}
                            </div>
                          </div>

                          <div className={styles.stageControls}>
                            <button
                              type="button"
                              className={styles.stageIconBtn}
                              onClick={() => handleMoveStep(stepIdx, 'up')}
                              disabled={stepIdx === 0}
                              title="Move stage up"
                              aria-label="Move stage up"
                            >
                              <ChevronUp size={16} />
                            </button>
                            <button
                              type="button"
                              className={styles.stageIconBtn}
                              onClick={() => handleMoveStep(stepIdx, 'down')}
                              disabled={stepIdx === currentProg.steps.length - 1}
                              title="Move stage down"
                              aria-label="Move stage down"
                            >
                              <ChevronDown size={16} />
                            </button>
                            <button
                              type="button"
                              className={`${styles.stageIconBtn} ${styles.stageIconBtnDanger}`}
                              onClick={() => handleDeleteStep(stepIdx)}
                              title="Delete stage"
                              aria-label="Delete stage"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>

                        {/* Full-Width Action Rows */}
                        <div className={styles.actionRowsList}>
                          {step.actions.map((act, actIdx) => (
                            <div
                              key={actIdx}
                              className={`${styles.actionRow} ${
                                act.type === 'motor'
                                  ? styles.rowMotor
                                  : act.type === 'servo'
                                  ? styles.rowServo
                                  : act.type === 'delay'
                                  ? styles.rowDelay
                                  : act.type === 'waitDispatch'
                                  ? styles.rowDispatch
                                  : styles.rowWled
                              }`}
                            >
                              <div className={styles.actionRowLeft}>
                                <div className={styles.actionIconBox}>
                                  {act.type === 'motor' ? (
                                    <Gauge size={16} color="var(--primary)" />
                                  ) : act.type === 'servo' ? (
                                    <Compass size={16} color="var(--secondary)" />
                                  ) : act.type === 'delay' ? (
                                    <Timer size={16} color="var(--tertiary)" />
                                  ) : act.type === 'waitDispatch' ? (
                                    <Zap size={16} color="#f59e0b" />
                                  ) : (
                                    <Palette size={16} color="#ec4899" />
                                  )}
                                </div>
                                <div className={styles.actionRowContent}>
                                  <span className={styles.actionMainLabel}>
                                    {act.type === 'motor' && (
                                      act.op === 'start'
                                        ? `${getMotorRole(act.motor || 1)} · Start · ${act.pwm ?? 100}% ${act.dir?.toUpperCase() || 'FWD'}`
                                        : act.op === 'stop'
                                        ? `${getMotorRole(act.motor || 1)} · Stop`
                                        : `${getMotorRole(act.motor || 1)} · Run ${act.pwm ?? 100}% (${act.durationMs || 1000}ms)`
                                    )}
                                    {act.type === 'servo' && (
                                      `${getServoRole(act.servo || 1)} · Set Angle · ${act.angle ?? 90}° (${act.speed || 100}°/s)`
                                    )}
                                    {act.type === 'delay' && (
                                      `Pause Delay · ${act.durationMs}ms`
                                    )}
                                    {act.type === 'waitDispatch' && (
                                      act.timeoutMs
                                        ? `Wait for Dispatch · Timeout ${act.timeoutMs / 1000}s`
                                        : 'Wait for Dispatch · Infinite'
                                    )}
                                    {act.type === 'wled' && (
                                      `WLED Lighting Scene · Preset #${act.preset}`
                                    )}
                                  </span>
                                  <span className={styles.actionSubLabel}>
                                    {act.type === 'motor'
                                      ? `Duty Cycle: ${act.pwm ?? 100}% · Polarity: ${act.dir?.toUpperCase() || 'FWD'}`
                                      : act.type === 'servo'
                                      ? '50Hz MCPWM Positioner'
                                      : act.type === 'delay'
                                      ? 'Non-blocking timer delay'
                                      : act.type === 'waitDispatch'
                                      ? 'Physical push button or web Dispatch release'
                                      : 'UDP Network Broadcast'}
                                  </span>
                                </div>
                              </div>

                              <div className={styles.actionRowActions}>
                                <button
                                  type="button"
                                  className={styles.actionRowBtn}
                                  onClick={() => openEditActionModal(stepIdx, actIdx, act)}
                                  title="Edit action"
                                  aria-label="Edit action"
                                >
                                  <Edit2 size={14} />
                                </button>
                                <button
                                  type="button"
                                  className={`${styles.actionRowBtn} ${styles.actionRowBtnDanger}`}
                                  onClick={() => handleDeleteAction(stepIdx, actIdx)}
                                  title="Remove action"
                                  aria-label="Remove action"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                          ))}

                          {/* Full-Width Dashed Add Action Button */}
                          <button
                            type="button"
                            className={styles.addActionButton}
                            onClick={() => openAddActionModal(stepIdx)}
                          >
                            <Plus size={16} />
                            <span>Add Action</span>
                          </button>
                        </div>
                      </div>
                    )
                  })
                )}

                {/* Add Timed Stage Bar with Selectable Time Duration */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '10px',
                    padding: '10px 12px',
                    borderRadius: 'var(--radius)',
                    background: 'var(--surface-container-high)',
                    border: '1px dashed var(--border-strong)',
                  }}
                >
                  {currentProg.steps.length > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                      <Timer size={15} color="var(--primary)" />
                      <span style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-2)' }}>
                        Stage Delay:
                      </span>
                      {[0.5, 1, 2, 3, 5].map((sec) => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => setNewStageDelaySec(sec)}
                          style={{
                            padding: '3px 8px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: 700,
                            cursor: 'pointer',
                            border:
                              newStageDelaySec === sec
                                ? '1px solid var(--primary)'
                                : '1px solid var(--border)',
                            background:
                              newStageDelaySec === sec
                                ? 'var(--accent-soft)'
                                : 'var(--surface)',
                            color: newStageDelaySec === sec ? 'var(--primary)' : 'var(--text-2)',
                          }}
                        >
                          +{sec}s
                        </button>
                      ))}
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                        <input
                          type="number"
                          min={0.1}
                          max={120}
                          step={0.1}
                          value={newStageDelaySec}
                          onChange={(e) => setNewStageDelaySec(Math.max(0.1, parseFloat(e.target.value) || 0.5))}
                          aria-label="Custom stage delay in seconds"
                          style={{
                            width: '62px',
                            padding: '4px 6px',
                            borderRadius: '6px',
                            border: '1px solid var(--border-strong)',
                            background: 'var(--surface)',
                            color: 'var(--text)',
                            fontSize: '12.5px',
                            fontWeight: 700,
                          }}
                        />
                        <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>sec</span>
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    className={styles.addStageBtn}
                    onClick={handleAddStep}
                    style={{ flex: currentProg.steps.length === 0 ? 1 : undefined, margin: 0 }}
                  >
                    <Plus size={16} />
                    <span>
                      {currentProg.steps.length === 0
                        ? 'Add First Stage (Immediate · T+0s)'
                        : `Add Timed Stage (+${newStageDelaySec}s)`}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* ================= LEFT COLUMN / COLLAPSIBLE ON MOBILE: MONITORING & SELECTION ================= */}
        <div className={styles.leftCol}>
          {/* 1. Track Schematic Card (Editable Vector + Active Hall Filtering) */}
          <div className={styles.panel}>
            <div
              className={styles.panelHead}
              onClick={() => setSchematicOpen(!schematicOpen)}
              style={{ cursor: 'pointer' }}
              title={schematicOpen ? 'Collapse schematic' : 'Expand schematic'}
            >
              <div className={styles.panelTitleGroup}>
                <span className={styles.panelIcon}>🛤️</span>
                <h2 className={styles.panelTitle}>Track Schematic & Carrier</h2>
              </div>
              <div className={styles.panelHeadRight}>
                <span className={styles.panelSubtitle}>
                  {activeHallPrograms.length} Active Hall{activeHallPrograms.length === 1 ? '' : 's'}
                </span>
                {schematicOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </div>
            </div>

            {schematicOpen && (
              <>
                {/* Hidden File Input for Custom SVG Track Import */}
                <input
                  ref={svgFileInputRef}
                  type="file"
                  accept=".svg,image/svg+xml"
                  style={{ display: 'none' }}
                  onChange={handleImportSvgFile}
                />

                {/* Vector Editor, Train Count, Custom SVG Import & Active Hall Filter Toolbar */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '8px',
                    padding: '8px 14px',
                    borderBottom: '1px solid var(--border)',
                    background: 'var(--surface-container-high)',
                    fontSize: '12px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 700, color: 'var(--text-2)' }}>Active Halls:</span>
                    <select
                      value={activeHallPrograms.length}
                      onChange={(e) => setActiveHallCount(parseInt(e.target.value, 10))}
                      style={{
                        padding: '3px 8px',
                        borderRadius: '6px',
                        border: '1px solid var(--border-strong)',
                        background: 'var(--surface)',
                        color: 'var(--text)',
                        fontWeight: 700,
                        fontSize: '12px',
                      }}
                      title="Choose how many Hall sensors are active on the track schematic"
                    >
                      {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
                        <option key={n} value={n}>
                          {n} Hall{n === 1 ? '' : 's'} (H1{n > 1 ? `–H${n}` : ''})
                        </option>
                      ))}
                    </select>

                    {/* 1-Train vs 2-Train Operations Selector */}
                    <div
                      style={{
                        display: 'inline-flex',
                        borderRadius: '6px',
                        overflow: 'hidden',
                        border: '1px solid var(--border-strong)',
                      }}
                      title="Select 1-Train or 2-Train Block Zone operations"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setTrainCount(1)
                          initDefaultTrainLocations(programs)
                          toast.info('Switched to 1-Train Operation Mode (remember to Save)')
                        }}
                        style={{
                          padding: '3px 9px',
                          fontSize: '11.5px',
                          fontWeight: 700,
                          cursor: 'pointer',
                          border: 'none',
                          background: trainCount === 1 ? 'var(--primary)' : 'var(--surface)',
                          color: trainCount === 1 ? '#0b1120' : 'var(--text-2)',
                        }}
                      >
                        🚆 1 Train
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTrainCount(2)
                          initDefaultTrainLocations(programs)
                          toast.info('Switched to 2-Train Block Zone Mode! Designate Block Hold Points on any Hall sensor.')
                        }}
                        style={{
                          padding: '3px 9px',
                          fontSize: '11.5px',
                          fontWeight: 700,
                          cursor: 'pointer',
                          border: 'none',
                          borderLeft: '1px solid var(--border)',
                          background: trainCount === 2 ? '#f59e0b' : 'var(--surface)',
                          color: trainCount === 2 ? '#0b1120' : 'var(--text-2)',
                        }}
                      >
                        🚆🚆 2 Trains (Block Zones)
                      </button>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                    {/* Import Custom SVG Track Vector Button */}
                    <button
                      type="button"
                      onClick={() => svgFileInputRef.current?.click()}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        border: customSvgTrack ? '1px solid #38bdf8' : '1px solid var(--border-strong)',
                        background: customSvgTrack ? 'rgba(56, 189, 248, 0.14)' : 'var(--surface)',
                        color: customSvgTrack ? '#38bdf8' : 'var(--text)',
                      }}
                      title="Import a custom SVG file containing a single-loop coaster track vector"
                    >
                      <Upload size={13} />
                      <span>{customSvgTrack ? `SVG: ${customSvgTrack.name}` : 'Import SVG'}</span>
                    </button>

                    {customSvgTrack && (
                      <button
                        type="button"
                        onClick={() => {
                          saveCustomSvgToStorage(null)
                          toast.info('Cleared custom SVG track')
                        }}
                        style={{
                          padding: '4px 7px',
                          borderRadius: '6px',
                          fontSize: '11px',
                          fontWeight: 600,
                          cursor: 'pointer',
                          border: '1px solid var(--border)',
                          background: 'var(--surface)',
                          color: 'var(--text-3)',
                        }}
                        title="Remove imported SVG and return to spline track"
                      >
                        Clear SVG
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setEditingVector(!editingVector)}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        border: editingVector ? '1px solid #f59e0b' : '1px solid var(--border-strong)',
                        background: editingVector ? 'rgba(245, 158, 11, 0.16)' : 'var(--surface)',
                        color: editingVector ? '#f59e0b' : 'var(--text)',
                      }}
                      title="Drag nodes on the schematic to edit the coaster track vector"
                    >
                      <Move size={13} />
                      <span>{editingVector ? 'Done Editing Vector' : 'Edit Track Vector'}</span>
                    </button>

                    {editingVector && customSvgTrack && (
                      <button
                        type="button"
                        onClick={() => setSnapToVector(!snapToVector)}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          padding: '4px 8px',
                          borderRadius: '6px',
                          fontSize: '11.5px',
                          fontWeight: 700,
                          cursor: 'pointer',
                          border: snapToVector ? '1px solid #10b981' : '1px solid var(--border)',
                          background: snapToVector ? 'rgba(16, 185, 129, 0.16)' : 'var(--surface)',
                          color: snapToVector ? '#10b981' : 'var(--text-3)',
                        }}
                        title="Snap dragged Hall sensors directly onto your imported SVG loop vector"
                      >
                        <Magnet size={12} />
                        <span>{snapToVector ? 'Snap to SVG: ON' : 'Snap to SVG: OFF'}</span>
                      </button>
                    )}

                    {editingVector && !customSvgTrack && (
                      <>
                        <button
                          type="button"
                          onClick={() => applyVectorPreset('loop4')}
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '11.5px',
                            fontWeight: 600,
                            cursor: 'pointer',
                            border: '1px solid var(--border)',
                            background: 'var(--surface)',
                            color: 'var(--text-2)',
                          }}
                          title="Arrange active halls in a loop with Dispatch feeding H1"
                        >
                          Loop Shape
                        </button>
                        <button
                          type="button"
                          onClick={() => applyVectorPreset('oval')}
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '11.5px',
                            fontWeight: 600,
                            cursor: 'pointer',
                            border: '1px solid var(--border)',
                            background: 'var(--surface)',
                            color: 'var(--text-2)',
                          }}
                        >
                          Oval
                        </button>
                        <button
                          type="button"
                          onClick={() => applyVectorPreset('figure8')}
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '11.5px',
                            fontWeight: 600,
                            cursor: 'pointer',
                            border: '1px solid var(--border)',
                            background: 'var(--surface)',
                            color: 'var(--text-2)',
                          }}
                        >
                          Figure-8
                        </button>
                        <button
                          type="button"
                          onClick={() => saveCoordsToStorage({ ...DEFAULT_SENSOR_COORDS })}
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '11.5px',
                            fontWeight: 600,
                            cursor: 'pointer',
                            border: '1px solid var(--border)',
                            background: 'var(--surface)',
                            color: 'var(--text-3)',
                          }}
                        >
                          Reset
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {editingVector && (
                  <div
                    style={{
                      padding: '6px 14px',
                      fontSize: '11.5px',
                      color: '#f59e0b',
                      background: 'rgba(245, 158, 11, 0.08)',
                      borderBottom: '1px solid rgba(245, 158, 11, 0.2)',
                    }}
                  >
                    ✋ {customSvgTrack
                      ? `Drag any active H1–H12 sensor around your imported "${customSvgTrack.name}" vector! (Toggle "Snap to SVG" to place sensors on or off the curve.)`
                      : 'Drag DISPATCH or any active H1–H12 node below to reshape your coaster track vector, or click "Import SVG" to load a custom loop.'}
                  </div>
                )}

                {/* Compact SVG Canvas */}
                <div className={styles.schematicSvgWrapper}>
                  <svg
                    ref={svgRef}
                    className={styles.trackSvg}
                    viewBox="0 0 920 180"
                    fill="none"
                    stroke="currentColor"
                    aria-label="Interactive track schematic"
                    onPointerMove={handleSvgPointerMove}
                    onPointerUp={handleSvgPointerUp}
                    onPointerLeave={handleSvgPointerUp}
                    style={{ touchAction: editingVector ? 'none' : 'auto' }}
                  >
                    <defs>
                      <linearGradient id="trackGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#0284c7" stopOpacity="0.9" />
                        <stop offset="35%" stopColor="#7c3aed" stopOpacity="0.9" />
                        <stop offset="70%" stopColor="#10b981" stopOpacity="0.85" />
                        <stop offset="100%" stopColor="#0284c7" stopOpacity="0.9" />
                      </linearGradient>
                      <marker
                        id="dispatchArrow"
                        viewBox="0 0 10 10"
                        refX="8"
                        refY="5"
                        markerWidth="6"
                        markerHeight="6"
                        orient="auto-start-reverse"
                      >
                        <path d="M 0 1 L 10 5 L 0 9 z" fill="#f59e0b" />
                      </marker>
                    </defs>

                    {/* Roadbed ties */}
                    <path
                      d={dynamicTrackPath}
                      stroke="#182234"
                      strokeWidth="16"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {/* Dual Rail Glow Path */}
                    <path
                      d={dynamicTrackPath}
                      stroke="url(#trackGradient)"
                      strokeWidth="3.2"
                    />

                    {/* Block Zone Occupied Segment Highlights */}
                    {activeHallPrograms.map((prog, idx) => {
                      const occupyingTrain = displayedTrains.find(
                        (t) => t.currentHall === prog.id && !t.held
                      )
                      if (!occupyingTrain) return null
                      const segPath = getBlockSegmentPath(idx)
                      if (!segPath) return null
                      return (
                        <path
                          key={`blk-seg-${prog.id}`}
                          d={segPath}
                          stroke={occupyingTrain.id === 2 ? '#a855f7' : '#f59e0b'}
                          strokeWidth="5"
                          strokeDasharray="8 5"
                          opacity="0.85"
                        />
                      )
                    })}

                    {/* Dispatch Intro Connector Arrow (Dispatch -> H1) */}
                    <line
                      x1={dispatchCoord.x}
                      y1={dispatchCoord.y}
                      x2={firstActiveHallCoord.x}
                      y2={firstActiveHallCoord.y}
                      stroke="#f59e0b"
                      strokeWidth="2.2"
                      strokeDasharray="5 4"
                      markerEnd="url(#dispatchArrow)"
                    />

                    {/* Dispatch Intro Node (id = 0) */}
                    <g
                      className={styles.schematicLandmark}
                      style={{ cursor: editingVector ? 'grab' : 'pointer' }}
                      onPointerDown={(e) => {
                        if (editingVector) {
                          e.stopPropagation()
                          setDraggingNodeId(0)
                        }
                      }}
                      onClick={() => setSelectedHallId(0)}
                    >
                      <rect
                        x={dispatchCoord.x - 32}
                        y={dispatchCoord.y - 11}
                        width="64"
                        height="22"
                        rx="6"
                        fill={activeHallNow === 0 ? '#10b981' : selectedHallId === 0 ? '#f59e0b' : '#1e293b'}
                        stroke={selectedHallId === 0 ? '#ffffff' : '#f59e0b'}
                        strokeWidth={selectedHallId === 0 ? 2.2 : 1.5}
                      />
                      <text
                        x={dispatchCoord.x}
                        y={dispatchCoord.y + 4}
                        textAnchor="middle"
                        fill={selectedHallId === 0 ? '#ffffff' : '#fbbf24'}
                        fontFamily="Raleway, sans-serif"
                        fontSize="10"
                        fontWeight="800"
                      >
                        DISPATCH
                      </text>
                    </g>

                    {/* Active Hall Sensor Landmarks Only (Inactive Halls Disappear) */}
                    {activeHallPrograms.map((prog) => {
                      const sId = prog.id
                      const coord = sensorCoords[sId] || DEFAULT_SENSOR_COORDS[sId] || { x: 70, y: 90 }
                      const isSelected = selectedHallId === sId
                      const isActive = activeHallNow === sId
                      const isBlock = !!prog.isBlockHold
                      const heldTrainHere = displayedTrains.find(
                        (t) => t.currentHall === sId && t.held
                      )
                      return (
                        <g
                          key={sId}
                          className={styles.schematicLandmark}
                          style={{ cursor: editingVector ? 'grab' : 'pointer' }}
                          onPointerDown={(e) => {
                            if (editingVector) {
                              e.stopPropagation()
                              setDraggingNodeId(sId)
                            }
                          }}
                          onClick={() => setSelectedHallId(sId)}
                        >
                          {isBlock && (
                            <circle
                              cx={coord.x}
                              cy={coord.y}
                              r={editingVector ? 14 : 12}
                              fill="none"
                              stroke={heldTrainHere ? '#ef4444' : '#f59e0b'}
                              strokeWidth="1.8"
                              strokeDasharray="3 2"
                            />
                          )}
                          <circle
                            cx={coord.x}
                            cy={coord.y}
                            r={editingVector ? 10 : isSelected ? 9 : 6.5}
                            fill={
                              heldTrainHere
                                ? '#ef4444'
                                : isActive
                                ? '#10b981'
                                : isSelected
                                ? '#38bdf8'
                                : isBlock
                                ? '#78350f'
                                : '#1e293b'
                            }
                            stroke={
                              editingVector
                                ? '#f59e0b'
                                : isSelected
                                ? '#ffffff'
                                : isBlock
                                ? '#f59e0b'
                                : '#64748b'
                            }
                            strokeWidth={isSelected || editingVector ? 2.5 : 1.5}
                          />
                          <text
                            x={coord.x}
                            y={coord.y - (isBlock ? 16 : 13)}
                            textAnchor="middle"
                            fill={isSelected ? '#38bdf8' : isBlock ? '#fbbf24' : '#e2e8f0'}
                            fontFamily="Raleway, sans-serif"
                            fontSize="11"
                            fontWeight={isSelected || isBlock ? '800' : '600'}
                          >
                            {isBlock ? '🛑 ' : ''}
                            {prog.name && prog.name !== `Hall ${sId}` ? `H${sId} (${prog.name})` : `H${sId}`}
                          </text>
                        </g>
                      )
                    })}

                    {/* Moving / Holding Train Carriers (Shown IN BETWEEN Hall Dots when traveling, or at Hall when held) */}
                    {!editingVector &&
                      displayedTrains.map((tr, idx) => {
                        const curH = tr.currentHall > 0 ? tr.currentHall : (activeHallPrograms[0]?.id ?? 1)
                        const nxtH =
                          tr.nextHall > 0
                            ? tr.nextHall
                            : activeHallPrograms[
                                (activeHallPrograms.findIndex((p) => p.id === curH) + 1) %
                                  Math.max(1, activeHallPrograms.length)
                              ]?.id ?? curH
                        const pos = tr.held
                          ? sensorCoords[curH] || DEFAULT_SENSOR_COORDS[curH] || trainPos
                          : getBlockZoneMidpoint(curH, nxtH)
                        const isTrain2 = tr.id === 2 || idx === 1
                        const fillCol = tr.held ? '#ef4444' : isTrain2 ? '#a855f7' : '#f59e0b'
                        const glowCol = tr.held ? '#ef4444' : isTrain2 ? '#c084fc' : '#38bdf8'
                        const labelText = tr.held
                          ? `T${tr.id} HOLD @ H${curH}`
                          : trainCount === 2
                          ? `T${tr.id} (H${curH}→H${nxtH})`
                          : `TRAIN (H${curH}→H${nxtH})`

                        return (
                          <g
                            key={`train-${tr.id}`}
                            style={{
                              transform: `translate(${pos.x - 70}px, ${pos.y - 90}px)`,
                              transition: 'transform 0.65s cubic-bezier(0.25, 1, 0.5, 1)',
                              pointerEvents: 'none',
                            }}
                          >
                            <circle cx="70" cy="90" r="13" fill={glowCol} opacity="0.32" />
                            <rect
                              x="59"
                              y="83"
                              width="22"
                              height="14"
                              rx="4"
                              fill={fillCol}
                              stroke="#ffffff"
                              strokeWidth="1.5"
                            />
                            <text
                              x="70"
                              y="93"
                              textAnchor="middle"
                              fill="#ffffff"
                              fontFamily="Raleway, sans-serif"
                              fontSize="8.5"
                              fontWeight="900"
                            >
                              T{tr.id}
                            </text>
                            <rect
                              x="32"
                              y="99"
                              width="76"
                              height="14"
                              rx="4"
                              fill="rgba(15, 23, 42, 0.88)"
                              stroke={fillCol}
                              strokeWidth="1"
                            />
                            <text
                              x="70"
                              y="109"
                              textAnchor="middle"
                              fill={tr.held ? '#fca5a5' : '#f8fafc'}
                              fontFamily="Raleway, sans-serif"
                              fontSize="8.5"
                              fontWeight="800"
                            >
                              {labelText}
                            </text>
                          </g>
                        )
                      })}
                  </svg>
                </div>

                {/* Telemetry Strip Below Canvas */}
                <div className={styles.schematicTelemetryStrip}>
                  <div className={styles.schematicStatusTag}>
                    <span className={styles.dotCyan} />
                    <span>
                      Mode: {trainCount === 2 ? '2-Train Block Zones' : '1-Train Loop'}
                    </span>
                  </div>
                  {displayedTrains.map((tr) => (
                    <div key={`tag-t-${tr.id}`} className={styles.schematicStatusTag}>
                      <span
                        className={styles.dotMint}
                        style={{
                          background: tr.held ? '#ef4444' : tr.id === 2 ? '#a855f7' : '#10b981',
                        }}
                      />
                      <span>
                        Train {tr.id}:{' '}
                        {tr.held
                          ? `🛑 HOLDING at H${tr.currentHall} (Waiting for H${tr.currentHall}→H${tr.nextHall} clear)`
                          : `In Block H${tr.currentHall} → H${tr.nextHall}`}
                      </span>
                    </div>
                  ))}
                  <div className={styles.telemetryTriggerTag}>
                    <span className={styles.trackPulseDot} />
                    <span>
                      Block Holds:{' '}
                      {activeHallPrograms
                        .filter((p) => p.isBlockHold)
                        .map((p) => `H${p.id}`)
                        .join(', ') || 'None designated'}
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* 2. Actuator Quick Bus (Clickable Software Motor & Servo Toggle Buttons) */}
          <div className={styles.panel}>
            <div className={styles.panelHead}>
              <div className={styles.panelTitleGroup}>
                <span className={styles.panelIcon}>⚡</span>
                <h2 className={styles.panelTitle}>Quick Motor & Servo Toggles</h2>
              </div>
              <span className={styles.panelSubtitle}>Click any channel to toggle ON (100%) / OFF</span>
            </div>

            <div className={styles.quickBusGrid}>
              {MOTORS.map((m) => {
                const mState = state?.motors?.[m.id - 1]
                const isOn = (mState?.pwm ?? 0) > 0 || (mState?.target ?? 0) > 0
                return (
                  <button
                    key={`m-${m.id}`}
                    type="button"
                    onClick={() => handleQuickMotorToggle(m.id)}
                    className={`${styles.busTile} ${isOn ? styles.busTileActive : ''}`}
                    style={{ textAlign: 'left', cursor: 'pointer' }}
                    title={`Click to toggle ${m.name} ${isOn ? 'OFF' : 'ON at 100% PWM'}`}
                  >
                    <div className={styles.busTileHead}>
                      <span className={styles.busTileLabel}>{m.name}</span>
                      <span className={`${styles.busTileDot} ${isOn ? styles.busTileDotActive : ''}`} />
                    </div>
                    <span className={styles.busTileVal}>
                      {isOn ? `${mState?.pwm || mState?.target || 100}%` : 'OFF'}
                    </span>
                    <span className={styles.busTileSub}>
                      {isOn ? 'Click to Stop' : 'Click -> 100% ON'}
                    </span>
                  </button>
                )
              })}

              {SERVOS.map((s) => {
                const sState = state?.servos?.[s.id - 1]
                const angle = sState?.angle ?? 0
                return (
                  <button
                    key={`s-${s.id}`}
                    type="button"
                    onClick={() => handleQuickServoToggle(s.id)}
                    className={`${styles.busTile} ${angle > 0 ? styles.busTileActive : ''}`}
                    style={{ textAlign: 'left', cursor: 'pointer' }}
                    title={`Click to toggle ${s.name} between 0° and 180°`}
                  >
                    <div className={styles.busTileHead}>
                      <span className={styles.busTileLabel}>{s.name}</span>
                      <span className={`${styles.busTileDot} ${angle > 0 ? styles.busTileDotActive : ''}`} />
                    </div>
                    <span className={styles.busTileVal}>{angle}°</span>
                    <span className={styles.busTileSub}>Click 0° / 180°</span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* 3. Sensor Matrix (Includes Dispatch Intro Block + Hall 1–12 with Show/Hide Toggle) */}
          <div className={styles.panel}>
            <div className={styles.panelHead}>
              <div className={styles.panelTitleGroup}>
                <Radio className={styles.panelIcon} size={16} />
                <h2 className={styles.panelTitle}>Dispatch & Hall Pipelines</h2>
              </div>
              <span className={styles.panelSubtitle}>Tap to configure · Eye icon toggles schematic visibility</span>
            </div>

            <div className={styles.sensorMatrixGrid}>
              {programs.map((prog) => {
                const isSelected = prog.id === selectedHallId
                const isDispatch = prog.id === 0
                const meta = isDispatch
                  ? { id: 0, name: 'Dispatch', pin: 'Button / Panel', zone: 'Intro' }
                  : getHallInfo(prog.id)
                const hasSteps = prog.steps && prog.steps.length > 0
                return (
                  <div
                    key={prog.id}
                    role="button"
                    tabIndex={0}
                    className={`${styles.sensorCard} ${isSelected ? styles.sensorCardSelected : ''}`}
                    onClick={() => setSelectedHallId(prog.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') setSelectedHallId(prog.id)
                    }}
                    style={{
                      opacity: !isDispatch && !prog.enabled ? 0.5 : 1,
                      borderColor: isDispatch && isSelected ? '#f59e0b' : undefined,
                    }}
                  >
                    <div className={styles.sensorCardTop}>
                      <span
                        className={styles.sensorIdBadge}
                        style={
                          isDispatch
                            ? { background: 'rgba(245, 158, 11, 0.18)', color: '#f59e0b', borderColor: 'rgba(245, 158, 11, 0.4)' }
                            : undefined
                        }
                      >
                        {hasSteps && <span className={styles.configuredDot} />}
                        {isDispatch ? '⚡ DISPATCH' : `H${prog.id}`}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span className={styles.sensorStepCount}>
                          {prog.steps.length} {prog.steps.length === 1 ? 'stage' : 'stages'}
                        </span>
                        {!isDispatch && (
                          <button
                            type="button"
                            onClick={(e) => toggleHallEnabled(prog.id, e)}
                            style={{
                              background: 'transparent',
                              border: 'none',
                              padding: '2px',
                              cursor: 'pointer',
                              color: prog.enabled ? 'var(--primary)' : 'var(--text-3)',
                              display: 'inline-flex',
                            }}
                            title={prog.enabled ? 'Active on Track Schematic (click to hide)' : 'Hidden from Track Schematic (click to show)'}
                          >
                            {prog.enabled ? <Eye size={13} /> : <EyeOff size={13} />}
                          </button>
                        )}
                      </div>
                    </div>
                    <div className={styles.sensorCardName}>{prog.name || meta.name}</div>
                    <div className={styles.sensorCardPin}>
                      {isDispatch
                        ? 'Main Bar / Control Panel'
                        : `${meta.pin} · ${prog.enabled ? 'Active' : 'Hidden'}${prog.isBlockHold ? ' · 🛑 Block Hold' : ''}`}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* 4. Real-time Console Log */}
          <div className={styles.consoleContainer}>
            <div className={styles.consoleHead}>
              <div
                className={styles.consoleHeadLeft}
                onClick={() => setConsoleOpen(!consoleOpen)}
                style={{ cursor: 'pointer' }}
                title={consoleOpen ? 'Collapse console' : 'Expand console'}
              >
                <span className={styles.consoleDot} />
                <span>REALTIME HALL BUS CONSOLE</span>
                {consoleOpen ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </div>
              <button
                type="button"
                className={styles.consoleClearBtn}
                onClick={() => setConsoleLogs([])}
              >
                Clear
              </button>
            </div>
            {consoleOpen && (
              <div className={styles.consoleOutput}>
                {consoleLogs.length === 0 ? (
                  <div className={styles.consoleEmpty}>Console cleared. Awaiting hardware trigger events...</div>
                ) : (
                  consoleLogs.map((log) => (
                    <div key={log.id} className={styles.consoleRow}>
                      <span className={styles.consoleTime}>[{log.time}]</span>
                      <span className={styles.consoleTag} style={{ color: log.tagColor }}>
                        [{log.tag}]
                      </span>
                      <span className={styles.consoleMsg}>{log.msg}</span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ================= Action Modal (Add or Edit) ================= */}
      {modalOpen && (
        <div className={styles.modalOverlay} onClick={() => setModalOpen(false)}>
          <div className={styles.modalCard} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalHeaderLeft}>
                <Gauge className={styles.modalHeaderIcon} />
                <h3 className={styles.modalTitle}>
                  {editingActionIdx !== null ? 'Edit Stage Action' : 'Add Action to Stage'}
                </h3>
              </div>
              <button
                type="button"
                className={styles.modalClose}
                onClick={() => setModalOpen(false)}
                aria-label="Close dialog"
              >
                <X size={18} />
              </button>
            </div>

            <div className={styles.modalBody}>
              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Actuator Type</label>
                <select
                  className={styles.modalSelect}
                  value={actionType}
                  onChange={(e) => setActionType(e.target.value as ActionType)}
                >
                  <option value="motor">DC Motor (DRV8833 / FET PWM)</option>
                  <option value="servo">Micro Servo (50Hz PWM)</option>
                  <option value="delay">Time Delay Pause (ms)</option>
                  <option value="waitDispatch">Wait for Dispatch Button</option>
                  <option value="wled">WLED Scenic Lighting Scene</option>
                </select>
              </div>

              {actionType === 'motor' && (
                <>
                  <div className={styles.modalRow2}>
                    <div className={styles.modalField}>
                      <label className={styles.modalLabel}>Channel / ID</label>
                      <select
                        className={styles.modalSelect}
                        value={actionMotor}
                        onChange={(e) => setActionMotor(parseInt(e.target.value, 10))}
                      >
                        {motorOptions.map((opt) => (
                          <option key={opt.id} value={opt.id}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className={styles.modalField}>
                      <label className={styles.modalLabel}>Operation</label>
                      <select
                        className={styles.modalSelect}
                        value={actionMotorOp}
                        onChange={(e) => setActionMotorOp(e.target.value as any)}
                      >
                        <option value="start">Start (Continuous Run)</option>
                        <option value="runTime">Run for Duration (Auto-Stop)</option>
                        <option value="stop">Stop Motor</option>
                      </select>
                    </div>
                  </div>

                  {actionMotorOp !== 'stop' && (
                    <>
                      <div className={styles.modalField}>
                        <div className={styles.sliderHeadRow}>
                          <label className={styles.modalLabel}>PWM Speed Duty</label>
                          <span className={styles.sliderHeadVal}>{actionPwm}%</span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={actionPwm}
                          onChange={(e) => setActionPwm(parseInt(e.target.value, 10))}
                          className={styles.modalSlider}
                        />
                      </div>

                      {actionMotor <= 2 && (
                        <div className={styles.modalField}>
                          <label className={styles.modalLabel}>H-Bridge Polarity Direction</label>
                          <select
                            className={styles.modalSelect}
                            value={actionDir}
                            onChange={(e) => setActionDir(e.target.value as any)}
                          >
                            <option value="fwd">Forward (FWD)</option>
                            <option value="rev">Reverse (REV)</option>
                          </select>
                        </div>
                      )}

                      {actionMotorOp === 'runTime' && (
                        <div className={styles.modalField}>
                          <label className={styles.modalLabel}>Run Duration (ms)</label>
                          <input
                            type="number"
                            step={100}
                            className={styles.modalInput}
                            value={actionDurationMs}
                            onChange={(e) => setActionDurationMs(parseInt(e.target.value, 10) || 1000)}
                          />
                        </div>
                      )}
                    </>
                  )}
                </>
              )}

              {actionType === 'servo' && (
                <>
                  <div className={styles.modalRow2}>
                    <div className={styles.modalField}>
                      <label className={styles.modalLabel}>Select Servo</label>
                      <select
                        className={styles.modalSelect}
                        value={actionServo}
                        onChange={(e) => setActionServo(parseInt(e.target.value, 10))}
                      >
                        {servoOptions.map((opt) => (
                          <option key={opt.id} value={opt.id}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className={styles.modalField}>
                      <label className={styles.modalLabel}>Transition Speed (deg/s)</label>
                      <input
                        type="number"
                        step={10}
                        className={styles.modalInput}
                        value={actionServoSpeed}
                        onChange={(e) => setActionServoSpeed(parseInt(e.target.value, 10) || 0)}
                      />
                    </div>
                  </div>

                  <div className={styles.modalField}>
                    <div className={styles.sliderHeadRow}>
                      <label className={styles.modalLabel}>Target Sweep Angle</label>
                      <span className={styles.sliderHeadVal}>{actionAngle}°</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={180}
                      value={actionAngle}
                      onChange={(e) => setActionAngle(parseInt(e.target.value, 10))}
                      className={styles.modalSlider}
                    />
                  </div>
                </>
              )}

              {actionType === 'delay' && (
                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>Pause Delay Offset (ms)</label>
                  <input
                    type="number"
                    step={200}
                    className={styles.modalInput}
                    value={actionDurationMs}
                    onChange={(e) => setActionDurationMs(parseInt(e.target.value, 10) || 1000)}
                  />
                </div>
              )}

              {actionType === 'waitDispatch' && (
                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>Auto-Dispatch Timeout (ms, 0 = Wait Indefinitely)</label>
                  <input
                    type="number"
                    step={1000}
                    className={styles.modalInput}
                    value={actionTimeoutMs}
                    onChange={(e) => setActionTimeoutMs(parseInt(e.target.value, 10) || 0)}
                  />
                </div>
              )}

              {actionType === 'wled' && (
                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>Trigger Preset Number (1–250)</label>
                  <input
                    type="number"
                    min={1}
                    max={250}
                    className={styles.modalInput}
                    value={actionWledPreset}
                    onChange={(e) => setActionWledPreset(parseInt(e.target.value, 10) || 1)}
                  />
                </div>
              )}
            </div>

            <div className={styles.modalFoot}>
              <Button variant="secondary" onClick={() => setModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleConfirmAddAction}>
                {editingActionIdx !== null ? 'Save Changes' : 'Append Action'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Resetting Clean Defaults */}
      {templateModalOpen && (
        <div className={styles.modalBackdrop} onClick={() => setTemplateModalOpen(false)}>
          <div className={styles.modalCard} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHead}>
              <h3 className={styles.modalTitle}>
                Reset {isCoasterB ? 'Coaster B' : isCoasterA ? 'Coaster A' : 'Run Loop'} to Clean Defaults?
              </h3>
              <button
                type="button"
                className={styles.modalClose}
                onClick={() => setTemplateModalOpen(false)}
              >
                ✕
              </button>
            </div>
            <div className={styles.modalBody}>
              <p style={{ margin: 0, color: 'var(--text-2)', fontSize: '13.5px', lineHeight: 1.5 }}>
                This will reset all sensor names to <strong>Dispatch</strong> and <strong>Hall 1–12</strong> with empty stages so you can build your sequence from a clean slate.
              </p>
            </div>
            <div className={styles.modalFoot}>
              <Button variant="secondary" onClick={() => setTemplateModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={executeLoadTemplate}>
                Reset Clean
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
