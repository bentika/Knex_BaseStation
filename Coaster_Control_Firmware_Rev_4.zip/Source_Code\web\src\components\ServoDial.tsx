import { useRef, useState, type PointerEvent } from 'react'
import styles from './ServoDial.module.css'

interface Props {
  /** Commanded angle (0–180). */
  target: number
  /** Live angle reported by the board. */
  angle: number
  onChange: (angle: number) => void
  onCommit: (angle: number) => void
  disabled?: boolean
  id?: string
}

const CX = 100
const CY = 104
const R = 78

function point(a: number, r = R) {
  const t = ((180 - a) * Math.PI) / 180
  return { x: CX + r * Math.cos(t), y: CY - r * Math.sin(t) }
}

function arc(a: number) {
  const s = point(0)
  const e = point(Math.max(0.01, a))
  return `M ${s.x} ${s.y} A ${R} ${R} 0 0 1 ${e.x} ${e.y}`
}

/** Half-circle "virtual knob" for a servo: drag anywhere on it to set the angle. */
export function ServoDial({ target, angle, onChange, onCommit, disabled, id }: Props) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [dragging, setDragging] = useState(false)

  const angleFromPointer = (e: PointerEvent) => {
    const rect = svgRef.current!.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 200
    const y = ((e.clientY - rect.top) / rect.height) * 120
    const dx = x - CX
    const dy = CY - y
    if (dy < 0) return dx < 0 ? 0 : 180
    const theta = (Math.atan2(dy, dx) * 180) / Math.PI
    return Math.round(Math.min(180, Math.max(0, 180 - theta)))
  }

  const onDown = (e: PointerEvent<SVGSVGElement>) => {
    if (disabled) return
    e.currentTarget.setPointerCapture(e.pointerId)
    setDragging(true)
    onChange(angleFromPointer(e))
  }
  const onMove = (e: PointerEvent<SVGSVGElement>) => dragging && onChange(angleFromPointer(e))
  const onUp = (e: PointerEvent<SVGSVGElement>) => {
    if (!dragging) return
    setDragging(false)
    onCommit(angleFromPointer(e))
  }

  const needle = point(angle, R - 18)
  const knob = point(target)

  return (
    <svg
      id={id}
      ref={svgRef}
      viewBox="0 0 200 120"
      className={`${styles.dial} ${dragging ? styles.dragging : ''} ${disabled ? styles.disabled : ''}`}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      role="slider"
      aria-valuemin={0}
      aria-valuemax={180}
      aria-valuenow={target}
      aria-label="Servo angle"
    >
      <defs>
        <linearGradient id="dialGrad" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0%" stopColor="hsl(189 96% 56%)" />
          <stop offset="100%" stopColor="hsl(266 92% 70%)" />
        </linearGradient>
      </defs>

      {[0, 30, 60, 90, 120, 150, 180].map((a) => {
        const p1 = point(a, R + 9)
        const p2 = point(a, R + (a % 90 === 0 ? 15 : 12))
        return <line key={a} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} className={styles.tick} />
      })}

      <path d={arc(180)} className={styles.track} />
      <path d={arc(target)} className={styles.fill} stroke="url(#dialGrad)" />

      <line x1={CX} y1={CY} x2={needle.x} y2={needle.y} className={styles.needle} />
      <circle cx={CX} cy={CY} r={6} className={styles.hub} />
      <circle cx={knob.x} cy={knob.y} r={9} className={styles.knob} />
    </svg>
  )
}
