import type { CSSProperties } from 'react'
import styles from './Slider.module.css'

interface Props {
  value: number
  min?: number
  max?: number
  step?: number
  onChange: (value: number) => void
  /** Fired when the user releases the thumb. */
  onCommit?: (value: number) => void
  disabled?: boolean
  tone?: 'accent' | 'success' | 'violet'
  'aria-label'?: string
  id?: string
}

export function Slider({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  onCommit,
  disabled,
  tone = 'accent',
  id,
  ...aria
}: Props) {
  const pct = ((value - min) / (max - min)) * 100
  const commit = (e: { currentTarget: HTMLInputElement }) => onCommit?.(Number(e.currentTarget.value))
  return (
    <input
      id={id}
      type="range"
      className={`${styles.slider} ${styles[tone]}`}
      style={{ '--fill': `${pct}%` } as CSSProperties}
      min={min}
      max={max}
      step={step}
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(Number(e.target.value))}
      onPointerUp={commit}
      onKeyUp={commit}
      {...aria}
    />
  )
}
