#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <LittleFS.h>

struct AppConfig {
    String wifiMode;      // "home" or "coaster"
    String wifiSsid;
    String wifiPassword;
    String apSsid;
    String apPassword;
    String hostname;
    bool apAlwaysOn;         // Keep AP active alongside Home Wi-Fi (default true)
    bool simMode;
    bool duelingMode;
    uint32_t hallDebounceMs; // Multi-magnet train debounce lockout (default 1500 ms)
};

class ConfigManager {
public:
    static ConfigManager& instance();

    bool begin();
    bool load();
    bool save();

    AppConfig& config() { return _config; }
    const AppConfig& config() const { return _config; }

private:
    ConfigManager();
    AppConfig _config;
};
