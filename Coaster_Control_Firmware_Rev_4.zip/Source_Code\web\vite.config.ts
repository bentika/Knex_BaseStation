import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'fs'
import path from 'path'
import zlib from 'zlib'

// Custom plugin to compress dist files to .gz for LittleFS
function gzipPlugin() {
  return {
    name: 'gzip-dist',
    closeBundle: async () => {
      const outDir = path.resolve(import.meta.dirname, '../firmware/data')
      if (!fs.existsSync(outDir)) return

      function processDir(dir: string) {
        const files = fs.readdirSync(dir)
        for (const file of files) {
          const fullPath = path.join(dir, file)
          const stat = fs.statSync(fullPath)
          if (stat.isDirectory()) {
            processDir(fullPath)
          } else if (!file.endsWith('.gz')) {
            const data = fs.readFileSync(fullPath)
            const gzipped = zlib.gzipSync(data, { level: 9 })
            fs.writeFileSync(`${fullPath}.gz`, gzipped)
          }
        }
      }

      processDir(outDir)
      console.log('Successfully gzipped web build for LittleFS.')
    },
  }
}

export default defineConfig({
  plugins: [react(), gzipPlugin()],
  build: {
    outDir: '../firmware/data',
    emptyOutDir: true,
    assetsInlineLimit: 4096,
  },
})
