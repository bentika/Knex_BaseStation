import { useEffect, useState } from 'react'

/**
 * Tiny hash router (#/manual, #/settings …). Hash routes work with the
 * ESP32's static file server without any rewrite rules.
 */
export type Route = 'run' | 'run-a' | 'run-b' | 'manual' | 'panel' | 'wled' | 'settings'

const ROUTES: Route[] = ['run', 'run-a', 'run-b', 'manual', 'panel', 'wled', 'settings']
export const DEFAULT_ROUTE: Route = 'manual'

function parse(): Route {
  const r = location.hash.replace(/^#\/?/, '') as Route
  return ROUTES.includes(r) ? r : DEFAULT_ROUTE
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(parse)
  useEffect(() => {
    const onChange = () => setRoute(parse())
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return route
}

export const href = (r: Route) => `#/${r}`
