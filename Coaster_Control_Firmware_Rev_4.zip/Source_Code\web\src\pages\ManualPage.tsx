import { useEffect } from 'react'
import { Compass, Gauge, Radio, Square, Terminal } from 'lucide-react'
import { Card } from '../components/Card'
import { useBoard } from '../store/boardStore'
import { MotorCard } from './manual/MotorCard'
import { ServoCard } from './manual/ServoCard'
import { HallGrid } from './manual/HallGrid'
import { EventLog } from './manual/EventLog'
import { MOTORS, SERVOS } from '../config/hardware'
import type { MotorDir } from '../api/types'
import styles from './ManualPage.module.css'

export function ManualPage() {
  const state = useBoard((s) => s.state)
  const info = useBoard((s) => s.info)
  const events = useBoard((s) => s.events)
  const hallFlash = useBoard((s) => s.hallFlash)
  const send = useBoard((s) => s.send)
  const clearEvents = useBoard((s) => s.clearEvents)

  const isEstop = state?.estop ?? false
  const motorsRunning = state?.motors ? state.motors.some((m) => m.pwm > 0 || m.target > 0) : false

  // Ensure Run Loop sequencer is paused while on the Manual Control page so physical
  // Hall sensor tests never phantom-trigger Run Loop motor/servo sequences.
  useEffect(() => {
    if (state?.runloop?.running) {
      send({ c: 'stopLoop' })
    }
  }, [])

  const handleMotorSet = (id: number, pwm: number, dir: MotorDir) => {
    send({ c: 'motor', id, pwm, dir })
  }

  const handleMotorStop = (id: number) => {
    send({ c: 'motorStop', id })
  }

  const handleServoSet = (id: number, angle: number) => {
    send({ c: 'servo', id, angle })
  }

  const handleStopAll = () => {
    send({ c: 'allStop' })
  }

  const handleCenterServos = () => {
    for (let i = 1; i <= 6; i++) {
      send({ c: 'servo', id: i, angle: 90 })
    }
  }

  const handleResetHalls = () => {
    send({ c: 'resetCounts' })
  }

  const handleSimHall = (id: number) => {
    send({ c: 'simHall', id })
  }

  return (
    <div className={styles.page}>
      {/* Top Context & Action Bar */}
      <header className={styles.header}>
        <div className={styles.contextInfo}>
          <div className={styles.contextTag}>
            <span className={styles.contextDot} />
            <span className={styles.contextTagText}>IO BUS CONTROLLER // DIRECT ACTUATION</span>
          </div>
          <h1 className={styles.title}>Manual Control</h1>
          <p className={styles.subtitle}>
            Direct hardware diagnostics: trigger reversible H-Bridges, set FET PWM duty cycles, sweep 50Hz servos, and probe real-time A3144 Hall latching arrays.
          </p>
        </div>

        {/* Global Actuator Quick-Actions */}
        <div className={styles.quickBar}>
          <button
            type="button"
            className={`${styles.stopAllBtn} ${motorsRunning ? styles.stopAllBtnRunning : ''}`}
            onClick={handleStopAll}
            disabled={isEstop}
            id="btn-stop-all"
            title="Stop all 6 motors immediately"
          >
            <Square className={styles.quickBtnIcon} />
            <span>{motorsRunning ? 'STOP ALL RUNNING MOTORS' : 'Stop All Motors'}</span>
          </button>

          <button
            type="button"
            className={styles.centerServosBtn}
            onClick={handleCenterServos}
            disabled={isEstop}
            id="btn-center-servos"
            title="Center all 6 servos to 90 degrees"
          >
            <Compass className={styles.quickBtnIcon} />
            <span>Center Servos (90°)</span>
          </button>
        </div>
      </header>

      <div className={styles.sections}>
        {/* SECTION 1: MOTOR OUTPUTS (1-6) */}
        <Card
          title={
            <div className={styles.sectionHeaderTitle}>
              <span>Motor Outputs (1–6)</span>
              <span className={styles.sectionBadge}>6 CHANNELS</span>
            </div>
          }
          subtitle="Motors 1 & 2 driven by DRV8833 dual H-Bridge (bidirectional polarity). Motors 3–6 driven by Logic-Level N-FET PWM stages."
          icon={<Gauge />}
          actions={
            <div className={styles.motorLegend}>
              <span className={styles.legendItem}>
                <span className={styles.legendDotCyan} />
                H-BRIDGE ACTIVE
              </span>
              <span className={styles.legendDivider}>/</span>
              <span className={styles.legendItem}>
                <span className={styles.legendDotViolet} />
                PWM FET
              </span>
            </div>
          }
        >
          <div className={styles.motorGrid}>
            {(info?.hw.motors ?? MOTORS).map((m, idx) => {
              const motorState = state?.motors[idx] ?? { pwm: 0, target: 0, dir: 'fwd' }
              return (
                <MotorCard
                  key={m.id}
                  id={m.id}
                  name={m.name}
                  driver={m.driver}
                  reversible={m.reversible}
                  state={motorState}
                  onSet={(pwm, dir) => handleMotorSet(m.id, pwm, dir)}
                  onStop={() => handleMotorStop(m.id)}
                  disabled={isEstop}
                />
              )
            })}
          </div>
        </Card>

        {/* SECTION 2: SERVOS (1-6) WITH TACTILE GAUGES */}
        <Card
          title={
            <div className={styles.sectionHeaderTitle}>
              <span>Servos (1–6)</span>
              <span className={styles.sectionBadgeViolet}>50Hz PWM SERVO BANK</span>
            </div>
          }
          subtitle="Precision 50Hz PWM servos with virtual knob control. Position each servo from 0 to 180 degrees with the virtual knob, or use the quick toggle."
          icon={<Compass />}
          actions={
            <span className={styles.servoResolution}>
              RESOLUTION: 1.0° (1000µs – 2000µs)
            </span>
          }
        >
          <div className={styles.servoGrid}>
            {(info?.hw.servos ?? SERVOS).map((s, idx) => {
              const servoState = state?.servos[idx] ?? { angle: 90, target: 90 }
              return (
                <ServoCard
                  key={s.id}
                  id={s.id}
                  name={s.name}
                  state={servoState}
                  onSet={(angle) => handleServoSet(s.id, angle)}
                  disabled={isEstop}
                />
              )
            })}
          </div>
        </Card>

        {/* SECTION 3: HALL EFFECT INPUTS (1-12) */}
        <Card
          title={
            <div className={styles.sectionHeaderTitle}>
              <span>Hall Effect Inputs (1–12)</span>
              <span className={styles.sectionBadgeMint}>A3144 ARRAYS</span>
            </div>
          }
          subtitle="A3144 open-collector hall sensors (active LOW interrupter). Luminous green beacon indicates magnetic presence / train bogey passage."
          icon={<Radio />}
        >
          <HallGrid
            halls={state?.halls ?? Array(12).fill(false)}
            hallCounts={state?.hallCounts ?? Array(12).fill(0)}
            hallFlash={hallFlash}
            onSimulate={handleSimHall}
            onResetCounts={handleResetHalls}
            disabled={isEstop}
          />
        </Card>

        {/* SECTION 4: LIVE DIAGNOSTIC CONSOLE */}
        <Card
          title="Live Diagnostic Console"
          subtitle="Real-time stream of triggers, motor commands, and physical system interlocks."
          icon={<Terminal />}
        >
          <EventLog events={events} onClear={clearEvents} />
        </Card>
      </div>
    </div>
  )
}
