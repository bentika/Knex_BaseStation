#include "WebServerManager.h"
#include <ArduinoJson.h>
#include <esp_system.h>
#include <esp_chip_info.h>
#include <esp_wifi.h>
#include "../pins.h"
#include "WledManager.h"
#include "../engine/RunLoopEngine.h"
#include "../drivers/PanelManager.h"

WebServerManager& WebServerManager::instance() {
    static WebServerManager inst;
    return inst;
}

WebServerManager::WebServerManager()
    : _io(nullptr),
      _server(80),
      _ws("/ws"),
      _lastStateBroadcast(0),
      _wifiConnectStart(0),
      _lastStaRetry(0),
      _scheduledReboot(0),
      _apActive(false),
      _dnsActive(false),
      _staConnected(false),
      _stateDirty(false),
      _nextEventId(0),
      _logCount(0) {}

void WebServerManager::begin(IOInterface* io) {
    _io = io;

    setupWiFi();
    setupWebSocket();
    setupRoutes();

    _server.begin();

    logEvent("system", "Base Station initialized. Web server running.");
}

void WebServerManager::startAP() {
    const AppConfig& cfg = ConfigManager::instance().config();

    IPAddress apIP(192, 168, 4, 1);
    IPAddress apGateway(192, 168, 4, 1);
    IPAddress apSubnet(255, 255, 255, 0);

    WiFi.softAPConfig(apIP, apGateway, apSubnet);

    bool ok;
    if (cfg.apPassword.length() >= 8) {
        ok = WiFi.softAP(cfg.apSsid.c_str(), cfg.apPassword.c_str(), 1, false, 4);
    } else {
        ok = WiFi.softAP(cfg.apSsid.c_str(), nullptr, 1, false, 4);
    }

    if (ok) {
        _apActive = true;
        _dnsServer.stop();
        _dnsServer.start(53, "*", apIP);
        _dnsActive = true;
        WiFi.setSleep(false);
        esp_wifi_set_ps(WIFI_PS_NONE);
        logEvent("system", "Hotspot active: " + cfg.apSsid + " (http://192.168.4.1)");
    }
}

void WebServerManager::stopAP() {
    if (_apActive) {
        _dnsServer.stop();
        _dnsActive = false;
        WiFi.softAPdisconnect(true);
        _apActive = false;
        logEvent("system", "Hotspot deactivated.");
    }
}

void WebServerManager::applyWiFiConfig(const String& oldMode, const String& oldSsid, const String& oldPass, const String& oldApSsid, const String& oldApPass, const String& oldHost) {
    const AppConfig& cfg = ConfigManager::instance().config();

    // If hostname changed, re-init mDNS
    if (oldHost != cfg.hostname) {
        MDNS.end();
        if (MDNS.begin(cfg.hostname.c_str())) {
            MDNS.addService("http", "tcp", 80);
        }
    }

    // If AP credentials changed or AP is not running, update AP
    if (oldApSsid != cfg.apSsid || oldApPass != cfg.apPassword || !_apActive) {
        startAP();
    }

    if (cfg.wifiMode == "coaster" || cfg.wifiSsid.length() == 0) {
        if (WiFi.status() == WL_CONNECTED || _staConnected) {
            WiFi.disconnect(true);
            _staConnected = false;
        }
        WiFi.mode(WIFI_AP);
        if (!_apActive) startAP();
        logEvent("system", "Switched to Standalone Hotspot mode: " + cfg.apSsid);
    } else {
        // Home Wi-Fi Mode: concurrent AP+STA
        WiFi.mode(WIFI_AP_STA);
        if (!_apActive) startAP();

        WiFi.disconnect();
        WiFi.begin(cfg.wifiSsid.c_str(), cfg.wifiPassword.c_str());
        _wifiConnectStart = millis();
        _lastStaRetry = millis();
        _staConnected = false;
        logEvent("system", "Connecting to Home Wi-Fi: " + cfg.wifiSsid + " (Hotspot active at 192.168.4.1)...");
    }

    WiFi.setSleep(false);
    esp_wifi_set_ps(WIFI_PS_NONE);
    _stateDirty = true;
}

void WebServerManager::setupWiFi() {
    const AppConfig& cfg = ConfigManager::instance().config();

    WiFi.disconnect(true);
    delay(100);

    WiFi.setSleep(false);
    esp_wifi_set_ps(WIFI_PS_NONE);
    WiFi.setTxPower(WIFI_POWER_18_5dBm);
    WiFi.setAutoReconnect(true);

    // Register event callbacks for immediate asynchronous notification
    WiFi.onEvent([this](WiFiEvent_t event, WiFiEventInfo_t info) {
        const AppConfig& c = ConfigManager::instance().config();
        if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
            _staConnected = true;
            esp_wifi_set_ps(WIFI_PS_NONE);
            logEvent("system", "Connected to " + WiFi.SSID() + "! IP: " + WiFi.localIP().toString());
            MDNS.end();
            if (MDNS.begin(c.hostname.c_str())) {
                MDNS.addService("http", "tcp", 80);
            }
            _stateDirty = true;
        } else if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
            if (_staConnected) {
                _staConnected = false;
                logEvent("warn", "Lost connection to " + c.wifiSsid + ". Retrying...");
                _stateDirty = true;
            }
            if (!_apActive) {
                startAP();
            }
        }
    });

    if (cfg.wifiMode == "coaster" || cfg.wifiSsid.length() == 0) {
        WiFi.mode(WIFI_AP);
        startAP();
        _staConnected = false;
    } else {
        // Home Wi-Fi Mode:
        // Run in concurrent WIFI_AP_STA mode so the user ALWAYS has access
        // to the controller directly via Coaster-Setup (192.168.4.1) as well
        // as over their local home network.
        WiFi.mode(WIFI_AP_STA);
        startAP();
        WiFi.begin(cfg.wifiSsid.c_str(), cfg.wifiPassword.c_str());
        _wifiConnectStart = millis();
        _lastStaRetry = millis();
        _staConnected = false;
        logEvent("system", "Connecting to Home Wi-Fi: " + cfg.wifiSsid + " (Hotspot active at 192.168.4.1)...");
    }

    if (MDNS.begin(cfg.hostname.c_str())) {
        MDNS.addService("http", "tcp", 80);
    }
}

void WebServerManager::setupWebSocket() {
    _ws.onEvent([this](AsyncWebSocket* server, AsyncWebSocketClient* client, AwsEventType type, void* arg, uint8_t* data, size_t len) {
        if (type == WS_EVT_CONNECT) {
            Serial.printf("[WS] Client #%u connected from %s\r\n", client->id(), client->remoteIP().toString().c_str());
            // Send current state
            broadcastState();

            // Send past events
            JsonDocument doc;
            doc["t"] = "events";
            JsonArray arr = doc["d"].to<JsonArray>();
            for (size_t i = 0; i < _logCount; i++) {
                JsonObject obj = arr.add<JsonObject>();
                obj["id"] = _logs[i].id;
                obj["ms"] = _logs[i].ms;
                obj["kind"] = _logs[i].kind;
                obj["msg"] = _logs[i].msg;
            }
            String out;
            serializeJson(doc, out);
            client->text(out);
        } else if (type == WS_EVT_DISCONNECT) {
            Serial.printf("[WS] Client #%u disconnected\r\n", client->id());
        } else if (type == WS_EVT_DATA) {
            handleWsMessage(client, arg, data, len);
        }
    });

    _server.addHandler(&_ws);
}

void WebServerManager::setupRoutes() {
    DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");
    DefaultHeaders::Instance().addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
    DefaultHeaders::Instance().addHeader("Access-Control-Allow-Headers", "*");

    // Captive Portal Redirects for iOS, Android, and Windows
    _server.on("/hotspot-detect.html", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/canonical.html", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/generate_204", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/gen_204", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/ncsi.txt", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/connecttest.txt", HTTP_GET, [](AsyncWebServerRequest* request) {
        request->redirect("http://192.168.4.1/");
    });

    // Pre-flight OPTIONS & Captive Redirect & SPA routing fallback
    _server.onNotFound([this](AsyncWebServerRequest* request) {
        if (request->method() == HTTP_OPTIONS) {
            request->send(200);
            return;
        }
        String host = request->host();
        if (_apActive && host.length() > 0 && host != "192.168.4.1" && host != "coaster.local" && !host.startsWith("192.168.")) {
            request->redirect("http://192.168.4.1/");
            return;
        }

        // SPA HTML5 fallback for client-side routing (/settings, /manual, /panel, etc.)
        String url = request->url();
        if (!url.startsWith("/api/") && !url.startsWith("/assets/")) {
            if (LittleFS.exists("/index.html.gz")) {
                AsyncWebServerResponse *response = request->beginResponse(LittleFS, "/index.html.gz", "text/html");
                response->addHeader("Content-Encoding", "gzip");
                request->send(response);
                return;
            } else if (LittleFS.exists("/index.html")) {
                request->send(LittleFS, "/index.html", "text/html");
                return;
            } else {
                // Emergency built-in recovery page if LittleFS was not flashed
                const char* fallbackHtml =
                    "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                    "<title>K'nex Coaster Base Station</title>"
                    "<style>body{background:#0b1120;color:#f8fafc;font-family:system-ui,-apple-system,sans-serif;padding:2rem;text-align:center;margin:0}"
                    ".card{max-width:540px;margin:3rem auto;background:#1e293b;padding:2.5rem;border-radius:16px;border:1px solid #334155;box-shadow:0 20px 25px -5px rgba(0,0,0,0.5)}"
                    "h1{color:#38bdf8;font-size:1.6rem;margin-top:0}p{color:#94a3b8;line-height:1.6;font-size:0.95rem}"
                    ".badge{display:inline-block;background:#059669;color:#ecfdf5;font-weight:600;padding:4px 12px;border-radius:999px;font-size:0.8rem;margin-bottom:1rem}"
                    ".alert{background:#1e1b4b;border:1px solid #4338ca;padding:1rem;border-radius:8px;color:#c7d2fe;margin:1.5rem 0;text-align:left;font-size:0.9rem}"
                    ".btn{display:inline-block;background:#38bdf8;color:#0b1120;font-weight:700;padding:10px 22px;border-radius:8px;text-decoration:none;margin-top:0.5rem}</style></head>"
                    "<body><div class='card'>"
                    "<span class='badge'>&#10003; ESP32-S3 Firmware Running</span>"
                    "<h1>K'nex Coaster Base Station</h1>"
                    "<p>Your controller is powered on and running production firmware v0.1.0.</p>"
                    "<div class='alert'><b>Notice:</b> The Web Dashboard LittleFS partition (0xC90000) has not been flashed yet. Run <code>flash_firmware_windows.bat</code> to flash the complete package, or upload <b>littlefs.bin</b> via OTA below:</div>"
                    "<a class='btn' href='/update'>Upload Web UI via OTA &rarr;</a>"
                    "</div></body></html>";
                request->send(200, "text/html", fallbackHtml);
                return;
            }
        }

        request->send(404, "text/plain", "Not Found");
    });

    // Captive Portal Assistant Handlers (iOS, Android, Windows)
    _server.on("/generate_204", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/hotspot-detect.html", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/canonical.html", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->redirect("http://192.168.4.1/");
    });
    _server.on("/connecttest.txt", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->redirect("http://192.168.4.1/");
    });

    // 1. GET /api/v1/info
    _server.on("/api/v1/info", HTTP_GET, [this](AsyncWebServerRequest* request) {
        JsonDocument doc;
        doc["fw"] = "0.1.0";
        doc["build"] = __DATE__ " " __TIME__;

        esp_chip_info_t chip_info;
        esp_chip_info(&chip_info);
        doc["chip"] = "ESP32-S3 (Rev " + String(chip_info.revision) + ")";

        doc["sim"] = _io->isSimMode();
#ifdef COASTER_FORCE_SIM
        doc["simForced"] = true;
#else
        doc["simForced"] = false;
#endif
        doc["uptimeMs"] = millis();
        doc["heapFree"] = ESP.getFreeHeap();
        doc["psramFree"] = psramFound() ? ESP.getFreePsram() : 0;
        doc["fsUsed"] = LittleFS.usedBytes();
        doc["fsTotal"] = LittleFS.totalBytes();

        const AppConfig& cfg = ConfigManager::instance().config();
        doc["hostname"] = cfg.hostname;

        JsonObject wifi = doc["wifi"].to<JsonObject>();
        wifi["mode"] = cfg.wifiMode;
        wifi["connected"] = (WiFi.status() == WL_CONNECTED);
        wifi["ssid"] = WiFi.SSID();
        wifi["ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : "";
        wifi["rssi"] = WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0;
        wifi["apActive"] = _apActive;
        wifi["apSsid"] = cfg.apSsid;
        wifi["apIp"] = WiFi.softAPIP().toString();

        JsonObject hw = doc["hw"].to<JsonObject>();
        JsonArray motors = hw["motors"].to<JsonArray>();
        for (int i = 0; i < NUM_MOTORS; i++) {
            JsonObject m = motors.add<JsonObject>();
            m["id"] = i + 1;
            m["name"] = "Motor " + String(i + 1);
            m["reversible"] = (i < 2);
            m["driver"] = (i < 2) ? "hbridge" : "fet";
        }

        JsonArray servos = hw["servos"].to<JsonArray>();
        for (int i = 0; i < NUM_SERVOS; i++) {
            JsonObject s = servos.add<JsonObject>();
            s["id"] = i + 1;
            s["name"] = "Servo " + String(i + 1);
            s["home"] = 0;
        }

        JsonArray halls = hw["halls"].to<JsonArray>();
        for (int i = 0; i < NUM_HALLS; i++) {
            JsonObject h = halls.add<JsonObject>();
            h["id"] = i + 1;
            h["name"] = "Hall " + String(i + 1);
            h["lockoutMs"] = _io->getHallDebounceMs();
        }

        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    // 2. GET & PUT /api/v1/config/wifi
    _server.on("/api/v1/config/wifi", HTTP_GET, [](AsyncWebServerRequest* request) {
        const AppConfig& cfg = ConfigManager::instance().config();
        JsonDocument doc;
        doc["mode"] = cfg.wifiMode;
        doc["ssid"] = cfg.wifiSsid;
        doc["password"] = "";
        doc["hasPassword"] = (cfg.wifiPassword.length() > 0);
        doc["apSsid"] = cfg.apSsid;
        doc["hostname"] = cfg.hostname;
        doc["apAlwaysOn"] = cfg.apAlwaysOn;
        doc["connected"] = (WiFi.status() == WL_CONNECTED);
        doc["staIp"] = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "";
        doc["apIp"] = WiFi.softAPIP().toString();
        doc["rssi"] = (WiFi.status() == WL_CONNECTED) ? WiFi.RSSI() : 0;
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setWifiHandler = new AsyncCallbackJsonWebHandler("/api/v1/config/wifi", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (!json.is<JsonObject>()) {
            request->send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
            return;
        }
        JsonObject obj = json.as<JsonObject>();
        AppConfig& cfg = ConfigManager::instance().config();

        String oldMode = cfg.wifiMode;
        String oldSsid = cfg.wifiSsid;
        String oldPass = cfg.wifiPassword;
        String oldApSsid = cfg.apSsid;
        String oldApPass = cfg.apPassword;
        String oldHost = cfg.hostname;

        if (obj["mode"].is<String>()) cfg.wifiMode = obj["mode"].as<String>();
        if (obj["ssid"].is<String>()) cfg.wifiSsid = obj["ssid"].as<String>();
        if (obj["password"].is<String>()) {
            String p = obj["password"].as<String>();
            if (p.length() > 0) {
                cfg.wifiPassword = p;
            }
        }
        if (obj["apSsid"].is<String>()) cfg.apSsid = obj["apSsid"].as<String>();
        if (obj["apPassword"].is<String>()) {
            cfg.apPassword = obj["apPassword"].as<String>();
        }
        if (obj["hostname"].is<String>()) cfg.hostname = obj["hostname"].as<String>();
        if (obj["apAlwaysOn"].is<bool>()) cfg.apAlwaysOn = obj["apAlwaysOn"].as<bool>();

        ConfigManager::instance().save();
        request->send(200, "application/json", "{\"ok\":true,\"message\":\"Wi-Fi settings saved\"}");

        // Apply network settings dynamically without an MCU reboot
        applyWiFiConfig(oldMode, oldSsid, oldPass, oldApSsid, oldApPass, oldHost);
    });
    setWifiHandler->setMethod(HTTP_PUT);
    _server.addHandler(setWifiHandler);

    // 2b. GET /api/v1/wifi/scan (Live 2.4GHz network scan - fast active probe)
    _server.on("/api/v1/wifi/scan", HTTP_GET, [](AsyncWebServerRequest* request) {
        int16_t n = WiFi.scanNetworks(false, false, false, 80);
        esp_wifi_set_ps(WIFI_PS_NONE);
        JsonDocument doc;
        JsonArray arr = doc.to<JsonArray>();
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                JsonObject obj = arr.add<JsonObject>();
                obj["ssid"] = WiFi.SSID(i);
                obj["rssi"] = WiFi.RSSI(i);
                obj["secure"] = (WiFi.encryptionType(i) != WIFI_AUTH_OPEN);
            }
        }
        WiFi.scanDelete();
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    // 3. GET & PUT /api/v1/config/system
    _server.on("/api/v1/config/system", HTTP_GET, [this](AsyncWebServerRequest* request) {
        JsonDocument doc;
        doc["sim"] = _io->isSimMode();
        doc["duelingMode"] = ConfigManager::instance().config().duelingMode;
        doc["hallDebounceMs"] = _io->getHallDebounceMs();
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setSysHandler = new AsyncCallbackJsonWebHandler("/api/v1/config/system", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (!json.is<JsonObject>()) {
            request->send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
            return;
        }
        JsonObject obj = json.as<JsonObject>();
        if (obj["sim"].is<bool>()) {
            bool sim = obj["sim"].as<bool>();
            _io->setSimMode(sim);
            ConfigManager::instance().config().simMode = sim;
            logEvent("system", sim ? "Simulator enabled" : "Hardware mode active");
        }
        if (obj["duelingMode"].is<bool>()) {
            bool dm = obj["duelingMode"].as<bool>();
            ConfigManager::instance().config().duelingMode = dm;
            RunLoopEngine::instanceA().reload();
            RunLoopEngine::instanceB().reload();
            logEvent("system", dm ? "Dueling Coaster Mode enabled" : "Single Coaster Mode enabled");
        }
        if (obj["hallDebounceMs"].is<uint32_t>() || obj["hallDebounceMs"].is<int>()) {
            uint32_t deb = obj["hallDebounceMs"].as<uint32_t>();
            if (deb >= 100 && deb <= 10000) {
                _io->setHallDebounceMs(deb);
                ConfigManager::instance().config().hallDebounceMs = deb;
                logEvent("system", "Hall train debounce set to " + String(deb) + " ms");
            }
        }
        ConfigManager::instance().save();
        request->send(200, "application/json", "{\"ok\":true}");
    });
    setSysHandler->setMethod(HTTP_PUT);
    _server.addHandler(setSysHandler);

    // 4. POST /api/v1/cmd
    AsyncCallbackJsonWebHandler* cmdHandler = new AsyncCallbackJsonWebHandler("/api/v1/cmd", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json.is<JsonObject>()) {
            handleCommand(json.as<JsonVariantConst>());
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid command\"}");
        }
    });
    cmdHandler->setMethod(HTTP_POST);
    _server.addHandler(cmdHandler);

    // 5. POST /api/v1/reboot
    _server.on("/api/v1/reboot", HTTP_POST, [this](AsyncWebServerRequest* request) {
        request->send(200, "application/json", "{\"ok\":true}");
        logEvent("system", "Reboot requested by user.");
        _scheduledReboot = millis() + 300;
    });

    // --- Run Loop REST Endpoints ---
    _server.on("/api/v1/runloop", HTTP_GET, [](AsyncWebServerRequest* request) {
        JsonDocument doc;
        RunLoopEngine::instanceA().serializeConfig(doc);
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setRunLoopHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json.is<JsonObject>()) {
            JsonDocument doc;
            doc.set(json);
            RunLoopEngine::instanceA().deserializeConfig(doc);
            logEvent("system", "Run loop program saved");
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        }
    });
    setRunLoopHandler->setMethod(HTTP_PUT);
    _server.addHandler(setRunLoopHandler);

    _server.on("/api/v1/runloop/start", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().startEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().startEngine();
        logEvent("system", "Run loop sequencer started");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/stop", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().stopEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().stopEngine();
        logEvent("system", "Run loop sequencer stopped");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().resetEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().resetEngine();
        logEvent("system", "Run loop sequencer reset");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/dispatch", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().dispatch();
        if (ConfigManager::instance().config().duelingMode) {
            RunLoopEngine::instanceB().dispatch();
            logEvent("system", "DUEL DISPATCH triggered by web operator");
        } else {
            logEvent("system", "Dispatch triggered by web operator");
        }
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/dispatch-both", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().dispatch();
        RunLoopEngine::instanceB().dispatch();
        logEvent("system", "DUEL DISPATCH: Both coasters launched simultaneously!");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/template", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().loadDefaultTemplate();
        RunLoopEngine::instanceA().saveConfig();
        logEvent("system", "Default run loop template loaded");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    AsyncCallbackJsonWebHandler* testHallHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop/test-hall", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        uint8_t h = json["hallId"].is<int>() ? (uint8_t)json["hallId"].as<int>() : 1;
        if (ConfigManager::instance().config().duelingMode) {
            if (h <= 6) {
                RunLoopEngine::instanceA().testFireHall(h);
            } else {
                RunLoopEngine::instanceB().testFireHall(h - 6);
            }
        } else {
            RunLoopEngine::instanceA().testFireHall(h);
        }
        logEvent("hall", h == 0 ? "Dispatch test triggered" : ("Hall " + String(h) + " test triggered"));
        request->send(200, "application/json", "{\"ok\":true}");
    });
    testHallHandler->setMethod(HTTP_POST);
    _server.addHandler(testHallHandler);

    // --- Coaster A Run Loop Endpoints ---
    _server.on("/api/v1/runloop/a", HTTP_GET, [](AsyncWebServerRequest* request) {
        JsonDocument doc;
        RunLoopEngine::instanceA().serializeConfig(doc);
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setRunLoopAHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop/a", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json.is<JsonObject>()) {
            JsonDocument doc;
            doc.set(json);
            RunLoopEngine::instanceA().deserializeConfig(doc);
            logEvent("system", "Coaster A program saved");
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        }
    });
    setRunLoopAHandler->setMethod(HTTP_PUT);
    _server.addHandler(setRunLoopAHandler);

    _server.on("/api/v1/runloop/a/start", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().startEngine();
        logEvent("system", "Coaster A sequencer started");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/a/stop", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().stopEngine();
        logEvent("system", "Coaster A sequencer stopped");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/a/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().resetEngine();
        logEvent("system", "Coaster A sequencer reset");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/a/dispatch", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().dispatch();
        logEvent("system", "Coaster A dispatch triggered");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/a/template", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceA().loadDefaultTemplate();
        RunLoopEngine::instanceA().saveConfig();
        logEvent("system", "Coaster A template loaded");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    AsyncCallbackJsonWebHandler* testHallAHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop/a/test-hall", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        uint8_t h = json["hallId"] | 1;
        RunLoopEngine::instanceA().testFireHall(h);
        logEvent("hall", "Coaster A Hall " + String(h) + " test triggered");
        request->send(200, "application/json", "{\"ok\":true}");
    });
    testHallAHandler->setMethod(HTTP_POST);
    _server.addHandler(testHallAHandler);

    // --- Coaster B Run Loop Endpoints ---
    _server.on("/api/v1/runloop/b", HTTP_GET, [](AsyncWebServerRequest* request) {
        JsonDocument doc;
        RunLoopEngine::instanceB().serializeConfig(doc);
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setRunLoopBHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop/b", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json.is<JsonObject>()) {
            JsonDocument doc;
            doc.set(json);
            RunLoopEngine::instanceB().deserializeConfig(doc);
            logEvent("system", "Coaster B program saved");
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        }
    });
    setRunLoopBHandler->setMethod(HTTP_PUT);
    _server.addHandler(setRunLoopBHandler);

    _server.on("/api/v1/runloop/b/start", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceB().startEngine();
        logEvent("system", "Coaster B sequencer started");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/b/stop", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceB().stopEngine();
        logEvent("system", "Coaster B sequencer stopped");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/b/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceB().resetEngine();
        logEvent("system", "Coaster B sequencer reset");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/b/dispatch", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceB().dispatch();
        logEvent("system", "Coaster B dispatch triggered");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    _server.on("/api/v1/runloop/b/template", HTTP_POST, [this](AsyncWebServerRequest* request) {
        RunLoopEngine::instanceB().loadDefaultTemplate();
        RunLoopEngine::instanceB().saveConfig();
        logEvent("system", "Coaster B template loaded");
        request->send(200, "application/json", "{\"ok\":true}");
    });

    AsyncCallbackJsonWebHandler* testHallBHandler = new AsyncCallbackJsonWebHandler("/api/v1/runloop/b/test-hall", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        uint8_t h = json["hallId"] | 1;
        RunLoopEngine::instanceB().testFireHall(h);
        logEvent("hall", "Coaster B Hall " + String(h) + " test triggered");
        request->send(200, "application/json", "{\"ok\":true}");
    });
    testHallBHandler->setMethod(HTTP_POST);
    _server.addHandler(testHallBHandler);

    // --- WLED REST Endpoints ---
    _server.on("/api/v1/wled", HTTP_GET, [](AsyncWebServerRequest* request) {
        JsonDocument doc;
        JsonArray arr = doc["devices"].to<JsonArray>();
        for (const auto& dev : WledManager::instance().getDevices()) {
            JsonObject o = arr.add<JsonObject>();
            o["id"] = dev.id;
            o["name"] = dev.name;
            o["ip"] = dev.ip;
            o["enabled"] = dev.enabled;
        }
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setWledHandler = new AsyncCallbackJsonWebHandler("/api/v1/wled", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json["devices"].is<JsonArray>()) {
            std::vector<WledDevice> devs;
            for (JsonObject o : json["devices"].as<JsonArray>()) {
                WledDevice d;
                d.id = o["id"] | "";
                d.name = o["name"] | "";
                d.ip = o["ip"] | "";
                d.enabled = o["enabled"] | true;
                devs.push_back(d);
            }
            WledManager::instance().setDevices(devs);
            logEvent("system", "WLED device list updated");
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid format\"}");
        }
    });
    setWledHandler->setMethod(HTTP_PUT);
    _server.addHandler(setWledHandler);

    AsyncCallbackJsonWebHandler* trigWledHandler = new AsyncCallbackJsonWebHandler("/api/v1/wled/trigger", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        String target = json["target"] | "all";
        int preset = json["preset"] | 1;
        if (target == "all") {
            WledManager::instance().triggerAll(preset);
        } else {
            WledManager::instance().triggerDevice(target, preset);
        }
        logEvent("system", "WLED preset " + String(preset) + " triggered (" + target + ")");
        request->send(200, "application/json", "{\"ok\":true}");
    });
    trigWledHandler->setMethod(HTTP_POST);
    _server.addHandler(trigWledHandler);

    // --- Control Panel REST Endpoints ---
    _server.on("/api/v1/panel", HTTP_GET, [](AsyncWebServerRequest* request) {
        JsonDocument doc;
        JsonObject obj = doc.to<JsonObject>();
        PanelManager::instance().serializeStatus(obj);
        String res;
        serializeJson(doc, res);
        request->send(200, "application/json", res);
    });

    AsyncCallbackJsonWebHandler* setPanelHandler = new AsyncCallbackJsonWebHandler("/api/v1/panel", [this](AsyncWebServerRequest* request, JsonVariant& json) {
        if (json["pins"].is<JsonArray>()) {
            for (JsonObject p : json["pins"].as<JsonArray>()) {
                uint8_t pin = p["pin"] | 255;
                String act = p["action"] | "none";
                String defaultLabel = "Pin " + String(pin + 1);
                String label = p["label"].is<String>() ? p["label"].as<String>() : defaultLabel;
                if (pin < 16) {
                    PanelManager::instance().setPinConfig(pin, act, label);
                }
            }
            logEvent("system", "Control panel mappings updated");
            request->send(200, "application/json", "{\"ok\":true}");
        } else {
            request->send(400, "application/json", "{\"error\":\"Invalid format\"}");
        }
    });
    setPanelHandler->setMethod(HTTP_PUT);
    _server.addHandler(setPanelHandler);

    // 6. POST /api/v1/update (OTA Handler)
    _server.on("/api/v1/update", HTTP_POST, [this](AsyncWebServerRequest* request) {
        bool hasError = Update.hasError();
        AsyncWebServerResponse* response = request->beginResponse(hasError ? 500 : 200, "text/plain", hasError ? "Update Failed" : "Update Succeeded. Restarting...");
        response->addHeader("Connection", "close");
        request->send(response);
        if (!hasError) {
            _scheduledReboot = millis() + 500;
        }
    }, [](AsyncWebServerRequest* request, String filename, size_t index, uint8_t* data, size_t len, bool final) {
        if (!index) {
            String target = request->hasParam("target") ? request->getParam("target")->value() : "firmware";
            int cmd = (target == "fs") ? U_SPIFFS : U_FLASH;
            Update.begin(UPDATE_SIZE_UNKNOWN, cmd);
        }

        if (!Update.hasError()) {
            Update.write(data, len);
        }

        if (final) {
            Update.end(true);
        }
    });

    // 7. Static UI Files from LittleFS (automatically handles .gz)
    _server.serveStatic("/", LittleFS, "/").setDefaultFile("index.html").setCacheControl("max-age=600");
}

void WebServerManager::handleWsMessage(AsyncWebSocketClient* client, void* arg, uint8_t* data, size_t len) {
    AwsFrameInfo* info = (AwsFrameInfo*)arg;
    if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
        JsonDocument doc;
        DeserializationError err = deserializeJson(doc, data, len);
        if (!err) {
            handleCommand(doc.as<JsonVariantConst>());
        }
    }
}

void WebServerManager::handleCommand(JsonVariantConst doc) {
    if (!doc["c"].is<String>()) return;
    String cmd = doc["c"].as<String>();

    if (cmd == "motor") {
        uint8_t id = doc["id"] | 1;
        int pwm = doc["pwm"] | 0;
        String dirStr = doc["dir"] | "fwd";
        MotorDir dir = (dirStr == "rev") ? MotorDir::REV : MotorDir::FWD;
        int ramp = doc["rampMs"] | 0;
        _io->setMotor(id, pwm, dir, ramp);
        logEvent("motor", "Motor " + String(id) + " set to " + String(pwm) + "% (" + dirStr + ")");
    } else if (cmd == "motorStop") {
        uint8_t id = doc["id"] | 1;
        _io->stopMotor(id);
        logEvent("motor", "Motor " + String(id) + " stopped");
    } else if (cmd == "allStop") {
        _io->stopAllMotors();
        logEvent("motor", "All motors stopped");
    } else if (cmd == "servo") {
        uint8_t id = doc["id"] | 1;
        int angle = doc["angle"] | 0;
        int speed = doc["speed"] | 0;
        _io->setServo(id, angle, speed);
        logEvent("servo", "Servo " + String(id) + " angle set to " + String(angle) + " deg");
    } else if (cmd == "simHall") {
        uint8_t id = doc["id"] | 1;
        _io->simulateHall(id);
        logEvent("hall", "Hall " + String(id) + " simulated trigger");
    } else if (cmd == "estop") {
        _io->setEstop(true);
        RunLoopEngine::instanceA().stopEngine();
        RunLoopEngine::instanceB().stopEngine();
        logEvent("error", "EMERGENCY STOP ACTIVATED");
    } else if (cmd == "reset") {
        _io->setEstop(false);
        logEvent("system", "Emergency Stop reset. System active.");
    } else if (cmd == "resetCounts") {
        _io->resetHallCounts();
        logEvent("hall", "Hall sensor trigger counters reset");
    } else if (cmd == "dispatchBoth") {
        RunLoopEngine::instanceA().dispatch();
        RunLoopEngine::instanceB().dispatch();
        logEvent("system", "DUEL DISPATCH: Both coasters launched simultaneously!");
    } else if (cmd == "dispatchA") {
        RunLoopEngine::instanceA().dispatch();
        logEvent("system", "Coaster A dispatch triggered");
    } else if (cmd == "dispatchB") {
        RunLoopEngine::instanceB().dispatch();
        logEvent("system", "Coaster B dispatch triggered");
    } else if (cmd == "dispatch") {
        RunLoopEngine::instanceA().dispatch();
        if (ConfigManager::instance().config().duelingMode) {
            RunLoopEngine::instanceB().dispatch();
            logEvent("system", "DUEL DISPATCH: Both coasters launched simultaneously!");
        } else {
            logEvent("system", "Manual dispatch triggered");
        }
    } else if (cmd == "startLoopA") {
        RunLoopEngine::instanceA().startEngine();
        logEvent("system", "Coaster A sequencer started");
    } else if (cmd == "stopLoopA") {
        RunLoopEngine::instanceA().stopEngine();
        logEvent("system", "Coaster A sequencer stopped");
    } else if (cmd == "resetLoopA") {
        RunLoopEngine::instanceA().resetEngine();
        logEvent("system", "Coaster A sequencer reset");
    } else if (cmd == "testHallA") {
        uint8_t id = doc["id"].is<int>() ? (uint8_t)doc["id"].as<int>() : 1;
        RunLoopEngine::instanceA().testFireHall(id);
        logEvent("hall", id == 0 ? "Test-fired Coaster A Dispatch" : ("Test-fired Coaster A Hall " + String(id)));
    } else if (cmd == "startLoopB") {
        RunLoopEngine::instanceB().startEngine();
        logEvent("system", "Coaster B sequencer started");
    } else if (cmd == "stopLoopB") {
        RunLoopEngine::instanceB().stopEngine();
        logEvent("system", "Coaster B sequencer stopped");
    } else if (cmd == "resetLoopB") {
        RunLoopEngine::instanceB().resetEngine();
        logEvent("system", "Coaster B sequencer reset");
    } else if (cmd == "testHallB") {
        uint8_t id = doc["id"].is<int>() ? (uint8_t)doc["id"].as<int>() : 1;
        RunLoopEngine::instanceB().testFireHall(id);
        logEvent("hall", id == 0 ? "Test-fired Coaster B Dispatch" : ("Test-fired Coaster B Hall " + String(id)));
    } else if (cmd == "startLoop") {
        RunLoopEngine::instanceA().startEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().startEngine();
        logEvent("system", "Run loop sequencer started");
    } else if (cmd == "stopLoop") {
        RunLoopEngine::instanceA().stopEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().stopEngine();
        logEvent("system", "Run loop sequencer stopped");
    } else if (cmd == "resetLoop") {
        RunLoopEngine::instanceA().resetEngine();
        if (ConfigManager::instance().config().duelingMode) RunLoopEngine::instanceB().resetEngine();
        logEvent("system", "Run loop sequencer reset");
    } else if (cmd == "testHall") {
        uint8_t id = doc["id"].is<int>() ? (uint8_t)doc["id"].as<int>() : 1;
        if (ConfigManager::instance().config().duelingMode) {
            if (id <= 6) {
                RunLoopEngine::instanceA().testFireHall(id);
                logEvent("hall", id == 0 ? "Test-fired Coaster A Dispatch" : ("Test-fired Coaster A Hall " + String(id)));
            } else {
                RunLoopEngine::instanceB().testFireHall(id - 6);
                logEvent("hall", "Test-fired Coaster B Hall " + String(id - 6));
            }
        } else {
            RunLoopEngine::instanceA().testFireHall(id);
            logEvent("hall", id == 0 ? "Test-fired Dispatch" : ("Test-fired Hall " + String(id)));
        }
    } else if (cmd == "triggerWled") {
        String target = doc["target"] | "all";
        int preset = doc["preset"] | 1;
        if (target == "all") {
            WledManager::instance().triggerAll(preset);
        } else {
            WledManager::instance().triggerDevice(target, preset);
        }
        logEvent("system", "WLED preset " + String(preset) + " triggered (" + target + ")");
    }

    _stateDirty = true;
}

void WebServerManager::logEvent(const String& kind, const String& msg) {
    uint32_t id = ++_nextEventId;
    uint32_t now = millis();

    Serial.printf("[EVENT:%s] %s\r\n", kind.c_str(), msg.c_str());

    if (_logCount < MAX_LOGS) {
        _logs[_logCount++] = {id, now, kind, msg};
    } else {
        for (size_t i = 0; i < MAX_LOGS - 1; i++) {
            _logs[i] = _logs[i + 1];
        }
        _logs[MAX_LOGS - 1] = {id, now, kind, msg};
    }

    // Push event to WebSocket clients whose queues are ready
    if (_ws.count() > 0) {
        JsonDocument doc;
        doc["t"] = "event";
        JsonObject d = doc["d"].to<JsonObject>();
        d["id"] = id;
        d["ms"] = now;
        d["kind"] = kind;
        d["msg"] = msg;

        String out;
        serializeJson(doc, out);
        _ws.textAll(out);
    }
}

void WebServerManager::broadcastState() {
    if (_ws.count() == 0) return;

    JsonDocument doc;
    doc["t"] = "state";
    JsonObject d = doc["d"].to<JsonObject>();
    d["ms"] = millis();
    d["estop"] = _io->isEstop();
    d["sim"] = _io->isSimMode();

    bool dueling = ConfigManager::instance().config().duelingMode;
    d["duelingMode"] = dueling;

    JsonArray halls = d["halls"].to<JsonArray>();
    JsonArray hallCounts = d["hallCounts"].to<JsonArray>();
    for (int i = 1; i <= NUM_HALLS; i++) {
        halls.add(_io->getHallActive(i));
        hallCounts.add(_io->getHallCount(i));
    }

    JsonArray motors = d["motors"].to<JsonArray>();
    for (int i = 1; i <= NUM_MOTORS; i++) {
        MotorStatus ms = _io->getMotorStatus(i);
        JsonObject m = motors.add<JsonObject>();
        m["pwm"] = ms.pwm;
        m["target"] = ms.target;
        m["dir"] = (ms.dir == MotorDir::FWD) ? "fwd" : "rev";
    }

    JsonArray servos = d["servos"].to<JsonArray>();
    for (int i = 1; i <= NUM_SERVOS; i++) {
        ServoStatus ss = _io->getServoStatus(i);
        JsonObject s = servos.add<JsonObject>();
        s["angle"] = ss.angle;
        s["target"] = ss.target;
    }

    // Run Loop Status
    auto populateRunLoopJson = [](JsonObject& obj, const RunLoopStatus& rls) {
        obj["running"] = rls.enabled;
        obj["activeHall"] = rls.activeHall;
        obj["activeStep"] = rls.activeStep;
        obj["totalSteps"] = rls.totalSteps;
        obj["waitingDispatch"] = rls.waitingDispatch;
        obj["stepDurationMs"] = rls.stepDurationMs;
        obj["elapsedStepMs"] = rls.elapsedStepMs;
        obj["trainCount"] = rls.trainCount;
        JsonArray trainsArr = obj["trains"].to<JsonArray>();
        for (uint8_t t = 0U; t < rls.trainCount && t < RUNLOOP_MAX_TRAINS; t++) {
            JsonObject tObj = trainsArr.add<JsonObject>();
            tObj["id"] = rls.trains[t].id;
            tObj["currentHall"] = rls.trains[t].currentHall;
            tObj["nextHall"] = rls.trains[t].nextHall;
            tObj["held"] = rls.trains[t].held;
        }
    };

    JsonObject rl = d["runloop"].to<JsonObject>();
    RunLoopStatus rlsA = RunLoopEngine::instanceA().getStatus();
    populateRunLoopJson(rl, rlsA);

    if (dueling) {
        JsonObject rlA = d["runloopA"].to<JsonObject>();
        populateRunLoopJson(rlA, rlsA);

        JsonObject rlB = d["runloopB"].to<JsonObject>();
        RunLoopStatus rlsB = RunLoopEngine::instanceB().getStatus();
        populateRunLoopJson(rlB, rlsB);
    }

    // Panel Status
    JsonObject pnl = d["panel"].to<JsonObject>();
    pnl["detected"] = PanelManager::instance().isDetected();
    pnl["raw"] = PanelManager::instance().getRawState();

    String out;
    serializeJson(doc, out);
    _ws.textAll(out);
}

void WebServerManager::update() {
    _ws.cleanupClients();

    if (_dnsActive) {
        _dnsServer.processNextRequest();
    }

    unsigned long now = millis();

    // 1. Check scheduled reboot (e.g. after manual reboot command)
    if (_scheduledReboot > 0 && now >= _scheduledReboot) {
        _scheduledReboot = 0;
        ESP.restart();
    }

    // 2. Wi-Fi Connection State Monitor & Background Auto-Recovery
    const AppConfig& cfg = ConfigManager::instance().config();
    if (cfg.wifiMode == "home" && cfg.wifiSsid.length() > 0) {
        if (WiFi.status() == WL_CONNECTED) {
            if (!_staConnected) {
                _staConnected = true;
                esp_wifi_set_ps(WIFI_PS_NONE);
                logEvent("system", "Home Wi-Fi connected: " + WiFi.SSID() + " (" + WiFi.localIP().toString() + ")");
                MDNS.end();
                if (MDNS.begin(cfg.hostname.c_str())) {
                    MDNS.addService("http", "tcp", 80);
                }
                // If user explicitly chose not to keep AP always on, deactivate it
                if (!cfg.apAlwaysOn && _apActive) {
                    stopAP();
                }
                _stateDirty = true;
            }
        } else {
            if (_staConnected) {
                _staConnected = false;
                logEvent("warn", "Lost connection to " + cfg.wifiSsid + ". Retrying in background...");
                _wifiConnectStart = now;
                _stateDirty = true;
            }

            // Always guarantee AP is running if disconnected
            if (!_apActive) {
                startAP();
            }

            // Periodically retry background connection every 12 seconds
            if (now - _lastStaRetry >= 12000) {
                _lastStaRetry = now;
                WiFi.begin(cfg.wifiSsid.c_str(), cfg.wifiPassword.c_str());
            }
        }
    }

    // 3. Broadcast state to WebSocket clients
    if ((_stateDirty && (now - _lastStateBroadcast >= 60)) || (now - _lastStateBroadcast >= 200)) {
        _stateDirty = false;
        _lastStateBroadcast = now;
        broadcastState();
    }
}
