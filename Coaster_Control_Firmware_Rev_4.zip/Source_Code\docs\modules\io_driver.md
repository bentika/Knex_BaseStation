# RealIO Hardware Driver Module (`docs/modules/io_driver.md`)

## Purpose

[`RealIO`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/RealIO.h) implements [`IOInterface`](file:///d:/Fiverr/order0012/rollor-coster-esp32-hall-effects-project-12/firmware/src/io/IOInterface.h) for the ESP32-S3-DevKitC-1 N16R8 Base Station PCB (Rev 3).

## Responsibilities

- **Motors 1 & 2 (DRV8833 H-Bridge)** and **Motors 3–6 (MOSFET)**:
  - Drives all 8 motor pins (`M1_IN1`, `M1_IN2`, `M2_IN1`, `M2_IN2`, `M3`–`M6`) at **20 kHz, 8-bit LEDC PWM**.
  - Enforces safe zero-crossing ramp-down before reversing direction on H-bridge channels.
- **Servos 1–6 (ESP32-S3 MCPWM Group 0)**:
  - Drives all 6 servos (`GPIO 4, 5, 6, 7, 43, 15`) via hardware **MCPWM Group 0** (`1 MHz` tick, `20,000 µs` = 50 Hz period, `500–2500 µs` pulse width) so zero LEDC channels are used by servos.
- **Hall Sensors 1–12 (A3144 Active LOW)**:
  - Captures falling edges via `IRAM_ATTR` hardware ISR (`hall_gpio_isr_handler`) and performs multi-magnet train debounce lockout (`_hallDebounceMs`, default `1500 ms`) in `RealIO::update()`.
- **Emergency Stop & Dry-Run Simulation**:
  - Immediately zeroes all motor outputs when `_estop` or `_simMode` is active.

## Data Flow

```text
hall_gpio_isr_handler (IRAM) ──► s_isrHallEdgeMask ──► RealIO::update() ──► _hallCallback(hallId)
RunLoopEngine / Manual UI   ──► RealIO::setMotor() ──► LEDC (20 kHz PWM)
RunLoopEngine / Manual UI   ──► RealIO::setServo() ──► MCPWM Group 0 (50 Hz)
```

