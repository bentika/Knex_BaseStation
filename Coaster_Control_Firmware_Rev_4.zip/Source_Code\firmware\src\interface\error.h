#ifndef INTERFACE_ERROR_H
#define INTERFACE_ERROR_H

#include <stdint.h>

/**
 * @brief Unified project-wide error codes for embedded drivers, interfaces, and modules.
 *
 * Names are deliberately prefixed (`fw_err_t`, `FW_*`): the plain names `error_t`, `ERR_OK`
 * and `ERR_TIMEOUT` already exist in newlib (`errno.h`) and lwIP (`err.h`) on ESP32 and clash.
 */
typedef enum {
    FW_OK = 0,
    FW_ERR_TIMEOUT,
    FW_ERR_BUSY,
    FW_ERR_INVALID_PARAM,
    FW_ERR_NOT_INITIALIZED,
    FW_ERR_NOT_READY,
    FW_ERR_COMMUNICATION,
    FW_ERR_OVERFLOW,
    FW_ERR_UNDERFLOW
} fw_err_t;

#endif /* INTERFACE_ERROR_H */

