import { useEffect, useState, useRef } from 'react'
import {
  Sparkles,
  Plus,
  Trash2,
  Send,
  Save,
  Palette,
  RefreshCw,
  Edit2,
  Check,
  X,
  Wifi,
} from 'lucide-react'
import { useBoard } from '../store/boardStore'
import { toast } from '../store/toastStore'
import type { WledDevice } from '../api/types'
import styles from './WledPage.module.css'

const PRESET_SCENES = [
  { preset: 1, name: 'Station Ambient', desc: 'Warm ambient glow' },
  { preset: 2, name: 'Dispatch Green', desc: 'Clearance launch wave' },
  { preset: 3, name: 'Lift Hill Chase', desc: 'Ascending strobe chase' },
  { preset: 4, name: 'Tunnel Strobes', desc: 'High-speed flashes' },
  { preset: 5, name: 'Crest Warning', desc: 'Apex warning pulse' },
  { preset: 6, name: 'Splashdown Blue', desc: 'Deep aqua cascade' },
  { preset: 7, name: 'Rainbow Show', desc: 'Full-spectrum animation' },
  { preset: 8, name: 'Emergency Red', desc: 'E-STOP / caution strobe' },
]

function normalizeIp(ip: string): string {
  return ip.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim()
}

function isValidIpOrHost(ip: string): boolean {
  if (!ip) return false
  const ipv4Pattern = /^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)\.?\b){4}$/
  const hostPattern = /^[a-zA-Z0-9][-a-zA-Z0-9_.]*[a-zA-Z0-9]$/
  return ipv4Pattern.test(ip) || hostPattern.test(ip)
}

export function WledPage() {
  const { link } = useBoard()

  const [devices, setDevices] = useState<WledDevice[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [sending, setSending] = useState(false)

  // Track initial clean state for dirty detection
  const initialDevicesJson = useRef<string>('')

  // Scene selection state (default scene 1 armed)
  const [selectedPreset, setSelectedPreset] = useState<number>(1)
  const [activeScene, setActiveScene] = useState<number | null>(1)

  // Send target: 'all' or IP address
  const [customTarget, setCustomTarget] = useState<string>('all')

  // Add Controller form inputs
  const [newName, setNewName] = useState('')
  const [newIp, setNewIp] = useState('')

  // In-place inline edit state
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [editIp, setEditIp] = useState('')

  // Simulated latency for device health display
  const [devicePings, setDevicePings] = useState<{ [id: string]: { ms: number; reachable: boolean } }>({})

  const isDirty =
    initialDevicesJson.current !== '' && JSON.stringify(devices) !== initialDevicesJson.current

  useEffect(() => {
    loadDevices()
  }, [])

  const loadDevices = async () => {
    try {
      setLoading(true)
      const data = await link.getWled()
      const loaded = data.devices || []
      setDevices(loaded)
      initialDevicesJson.current = JSON.stringify(loaded)

      // Initialize mock ping response times for each device
      const pings: { [id: string]: { ms: number; reachable: boolean } } = {}
      loaded.forEach((d, idx) => {
        pings[d.id] = {
          ms: 14 + idx * 8,
          reachable: d.enabled,
        }
      })
      setDevicePings(pings)
    } catch {
      toast.error('Failed to load WLED controllers from board')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    try {
      setSaving(true)
      await link.saveWled({ devices })
      initialDevicesJson.current = JSON.stringify(devices)
      toast.success('WLED Configuration Saved', 'Controllers stored in ESP32 LittleFS flash memory.')
    } catch {
      toast.error('Save Failed', 'Unable to write WLED device list to board.')
    } finally {
      setSaving(false)
    }
  }

  const handleAddDevice = () => {
    const cleanName = newName.trim()
    const cleanIp = normalizeIp(newIp)

    if (!cleanName || !cleanIp) {
      toast.warn('Missing Fields', 'Please provide both a controller name and IP address.')
      return
    }

    if (!isValidIpOrHost(cleanIp)) {
      toast.error('Invalid IP Address', 'Please enter a valid IPv4 address (e.g. 192.168.0.132) or local hostname.')
      return
    }

    if (devices.some((d) => d.ip.toLowerCase() === cleanIp.toLowerCase())) {
      toast.error('Duplicate Controller', `A controller with IP ${cleanIp} is already registered.`)
      return
    }

    const newDevice: WledDevice = {
      id: 'dev_' + Date.now(),
      name: cleanName,
      ip: cleanIp,
      enabled: true,
    }

    setDevices((prev) => [...prev, newDevice] as WledDevice[])
    setDevicePings((prev) => ({
      ...prev,
      [newDevice.id]: { ms: 16, reachable: true },
    }))

    setNewName('')
    setNewIp('')
    toast.success('Controller Added', `Added "${cleanName}" (${cleanIp}). Click Save to Board to persist.`)
  }

  const handleDeleteDevice = (id: string) => {
    const target = devices.find((d) => d.id === id)
    if (!target) return
    const index = devices.indexOf(target)

    setDevices((prev) => prev.filter((d) => d.id !== id))

    toast.info(`Deleted controller "${target.name}"`, undefined, {
      label: 'Undo',
      onClick: () => {
        setDevices((prev) => {
          const restored = [...prev]
          restored.splice(index, 0, target)
          return restored
        })
        toast.success(`Restored "${target.name}"`)
      },
    })
  }

  const handleToggleDevice = (id: string) => {
    setDevices((prev) =>
      prev.map((d) => (d.id === id ? { ...d, enabled: !d.enabled } : d))
    )
  }

  const startInlineEdit = (dev: WledDevice) => {
    setEditingId(dev.id)
    setEditName(dev.name)
    setEditIp(dev.ip)
  }

  const saveInlineEdit = (id: string) => {
    const cleanName = editName.trim()
    const cleanIp = normalizeIp(editIp)

    if (!cleanName || !cleanIp) {
      toast.warn('Missing Fields', 'Controller name and IP address cannot be empty.')
      return
    }

    if (!isValidIpOrHost(cleanIp)) {
      toast.error('Invalid IP Address', 'Please enter a valid IPv4 address or hostname.')
      return
    }

    if (devices.some((d) => d.id !== id && d.ip.toLowerCase() === cleanIp.toLowerCase())) {
      toast.error('Duplicate IP', `Another controller is already using ${cleanIp}.`)
      return
    }

    setDevices((prev) =>
      prev.map((d) => (d.id === id ? { ...d, name: cleanName, ip: cleanIp } : d))
    )
    setEditingId(null)
    toast.success('Controller Updated', `Saved new details for "${cleanName}".`)
  }

  const cancelInlineEdit = () => {
    setEditingId(null)
  }

  const handleSelectScene = (preset: number) => {
    setSelectedPreset(preset)
  }

  const handleTriggerPreset = async (preset: number, target: string = customTarget) => {
    const scene = PRESET_SCENES.find((s) => s.preset === preset)
    const sceneName = scene ? scene.name : `Preset #${preset}`
    const activeControllers = devices.filter((d) => d.enabled)

    if (target === 'all' && activeControllers.length === 0) {
      toast.warn('No Active Controllers', 'All controllers are currently muted. Enable at least one to receive commands.')
      return
    }

    setSending(true)
    try {
      await link.triggerWled(target, preset)
      setActiveScene(preset)
      setSelectedPreset(preset)

      if (target === 'all') {
        toast.success(
          'Scene Broadcast Sent',
          `Preset #${preset} (${sceneName}) delivered to ${activeControllers.length} active controller${activeControllers.length === 1 ? '' : 's'}.`
        )
      } else {
        const dev = devices.find((d) => d.ip === target)
        toast.success(
          'Command Delivered',
          `Preset #${preset} (${sceneName}) sent to ${dev ? dev.name : target}.`
        )
      }
    } catch {
      toast.error('Delivery Failed', `Target at ${target} failed to acknowledge WLED command. Check LAN connectivity.`)
    } finally {
      setSending(false)
    }
  }

  const selectedSceneObj = PRESET_SCENES.find((s) => s.preset === selectedPreset) || PRESET_SCENES[0]

  return (
    <div className={styles.page}>
      {/* 1. Command Center Hero Strip */}
      <div className={styles.headerCard}>
        <div className={styles.headerContent}>
          <div className={styles.headerTitleGroup}>
            <div className={styles.headerIcon}>
              <Palette size={24} />
            </div>
            <div>
              <h1 className={styles.title}>WLED RGB Controller Integration</h1>
              <p className={styles.subtitle}>
                Trigger dynamic train & track lighting sequences automatically on hall effect sensor hits or manual command.
              </p>
            </div>
          </div>
          <div className={styles.headerActions}>
            {isDirty && (
              <span className={styles.unsavedBadge}>
                <span className={styles.unsavedDot} /> Unsaved changes
              </span>
            )}
            <button
              type="button"
              className={styles.toolbarBtn}
              onClick={loadDevices}
              title="Reload controllers from ESP32 memory"
            >
              <RefreshCw size={15} />
              <span>Reload</span>
            </button>
            <button
              type="button"
              className={`${styles.toolbarBtn} ${isDirty ? styles.saveBtnActive : styles.saveBtnDisabled}`}
              onClick={handleSave}
              disabled={!isDirty || saving}
              title={isDirty ? 'Save changes to ESP32 flash memory' : 'No changes to save'}
            >
              <Save size={15} />
              <span>{saving ? 'Saving...' : isDirty ? 'Save to Board' : 'No changes to save'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Interactive Lighting Scenes Section (Full Width, 4-col Desktop / 2-col Mobile) */}
      <div className={styles.sectionCard}>
        <div className={styles.sectionHead}>
          <div className={styles.sectionTitleGroup}>
            <Sparkles size={18} className={styles.sectionIcon} />
            <h2 className={styles.sectionTitle}>Interactive Lighting Scenes</h2>
          </div>
          <span className={styles.sectionSub}>
            Click a scene card to arm it, then send to all or target controller
          </span>
        </div>

        {/* 4-Column Scene Cards Grid */}
        <div className={styles.sceneGrid}>
          {PRESET_SCENES.map((scene) => {
            const isSelected = selectedPreset === scene.preset
            const isActive = activeScene === scene.preset
            const isEmergency = scene.preset === 8

            return (
              <button
                key={scene.preset}
                type="button"
                className={`${styles.sceneCard} ${isSelected ? styles.sceneCardSelected : ''} ${
                  isEmergency ? styles.sceneCardDanger : ''
                }`}
                onClick={() => handleSelectScene(scene.preset)}
                onDoubleClick={() => handleTriggerPreset(scene.preset, customTarget)}
              >
                <div className={styles.sceneCardTop}>
                  <span className={styles.sceneNum}>#{scene.preset}</span>
                  {isActive && (
                    <span className={styles.sceneActiveBadge}>
                      <span className={styles.sceneActiveDot} /> Active
                    </span>
                  )}
                </div>
                <div className={styles.sceneDetails}>
                  <span className={styles.sceneName}>{scene.name}</span>
                  <span className={styles.sceneDesc}>{scene.desc}</span>
                </div>
              </button>
            )
          })}
        </div>

        {/* Unified Send Scene Command Bar (Sticky above bottom nav on mobile) */}
        <div className={styles.sendBar}>
          <div className={styles.sendBarLeft}>
            <div className={styles.targetSelectWrap}>
              <label htmlFor="wledTargetSelect" className={styles.fieldLabel}>
                Target Controller
              </label>
              <select
                id="wledTargetSelect"
                className={styles.selectInput}
                value={customTarget}
                onChange={(e) => setCustomTarget(e.target.value)}
              >
                <option value="all">Broadcast to All Controllers ({devices.filter((d) => d.enabled).length} active)</option>
                {devices.map((d) => (
                  <option key={d.id} value={d.ip}>
                    {d.name} ({d.ip}) {d.enabled ? '' : '[Muted]'}
                  </option>
                ))}
              </select>
            </div>

            <div className={styles.selectedSceneDisplay}>
              <span className={styles.fieldLabel}>Selected Scene</span>
              <div className={styles.selectedScenePill}>
                <span className={styles.selectedSceneTag}>#{selectedSceneObj.preset}</span>
                <span>{selectedSceneObj.name}</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            className={styles.sendBtn}
            disabled={sending}
            onClick={() => handleTriggerPreset(selectedPreset, customTarget)}
          >
            <Send size={15} />
            <span>{sending ? 'Transmitting...' : 'Send Scene to Target'}</span>
          </button>
        </div>
      </div>

      {/* 3. Hardware Controllers & Transmitters Management */}
      <div className={styles.sectionCard}>
        <div className={styles.sectionHead}>
          <div className={styles.sectionTitleGroup}>
            <Wifi size={18} className={styles.sectionIcon} />
            <h2 className={styles.sectionTitle}>Controllers & Transmitters</h2>
          </div>
          <span className={styles.sectionSub}>
            WLED ESP8266 / ESP32 network nodes on local subnet
          </span>
        </div>

        <div className={styles.controllersLayout}>
          {/* Controllers List */}
          <div className={styles.deviceList}>
            {loading ? (
              <div className={styles.emptyDevices}>Loading configured controllers...</div>
            ) : devices.length === 0 ? (
              <div className={styles.emptyDevices}>
                No WLED controllers registered yet. Use the form on the right to register a controller IP.
              </div>
            ) : (
              devices.map((dev) => {
                const isEditing = editingId === dev.id
                const ping = devicePings[dev.id] || { ms: 16, reachable: dev.enabled }

                return (
                  <div
                    key={dev.id}
                    className={`${styles.deviceCard} ${!dev.enabled ? styles.deviceCardMuted : ''}`}
                  >
                    <div className={styles.deviceLeft}>
                      <span
                        className={
                          !dev.enabled
                            ? styles.deviceStatusDotMuted
                            : ping.reachable
                            ? styles.deviceStatusDot
                            : styles.deviceStatusDotOffline
                        }
                        title={!dev.enabled ? 'Disabled / Muted' : ping.reachable ? `Reachable (${ping.ms}ms)` : 'Unreachable'}
                      />

                      {isEditing ? (
                        <div className={styles.inlineEditRow}>
                          <input
                            type="text"
                            className={styles.inlineEditInput}
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            placeholder="Controller Name"
                            autoFocus
                          />
                          <input
                            type="text"
                            className={styles.inlineEditInput}
                            value={editIp}
                            onChange={(e) => setEditIp(e.target.value)}
                            placeholder="IP (e.g. 192.168.0.132)"
                          />
                          <button
                            type="button"
                            className={`${styles.iconBtn} ${styles.iconBtnSave}`}
                            onClick={() => saveInlineEdit(dev.id)}
                            title="Save changes"
                          >
                            <Check size={14} />
                          </button>
                          <button
                            type="button"
                            className={styles.iconBtn}
                            onClick={cancelInlineEdit}
                            title="Cancel"
                          >
                            <X size={14} />
                          </button>
                        </div>
                      ) : (
                        <div className={styles.deviceDetails}>
                          <span className={styles.deviceName}>{dev.name}</span>
                          <div className={styles.deviceMetaRow}>
                            <span className={styles.deviceIp}>http://{dev.ip}</span>
                            {dev.enabled ? (
                              <span className={ping.reachable ? styles.deviceStatusMeta : styles.deviceStatusMetaOffline}>
                                • {ping.reachable ? `${ping.ms}ms · Reachable` : 'Unreachable'}
                              </span>
                            ) : (
                              <span className={styles.deviceStatusMetaMuted}>• Muted</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {!isEditing && (
                      <div className={styles.deviceActions}>
                        <button
                          type="button"
                          className={`${styles.toggleBtn} ${dev.enabled ? styles.toggleBtnActive : ''}`}
                          onClick={() => handleToggleDevice(dev.id)}
                          title={dev.enabled ? 'Click to Mute this controller' : 'Click to Enable this controller'}
                        >
                          {dev.enabled ? 'Active' : 'Muted'}
                        </button>
                        <button
                          type="button"
                          className={styles.iconBtn}
                          onClick={() => startInlineEdit(dev)}
                          title="Edit name and IP in place"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          type="button"
                          className={styles.deleteBtn}
                          onClick={() => handleDeleteDevice(dev.id)}
                          title="Delete controller (Undo available)"
                          aria-label={`Delete controller ${dev.name}`}
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                )
              })
            )}
          </div>

          {/* Add Controller Form */}
          <div className={styles.addFormCard}>
            <span className={styles.addFormTitle}>Add New WLED Controller</span>
            <div className={styles.formGrid2}>
              <div className={styles.formGroup}>
                <label className={styles.fieldLabel} htmlFor="newDevName">
                  Controller Name
                </label>
                <input
                  id="newDevName"
                  className={styles.textInput}
                  placeholder="e.g. Train #1, Tunnel Neon"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.fieldLabel} htmlFor="newDevIp">
                  IPv4 or Hostname
                </label>
                <input
                  id="newDevIp"
                  className={styles.textInput}
                  placeholder="e.g. 192.168.0.132"
                  value={newIp}
                  onChange={(e) => setNewIp(e.target.value)}
                />
              </div>
            </div>
            <button
              type="button"
              className={styles.addDeviceBtn}
              onClick={handleAddDevice}
            >
              <Plus size={16} />
              <span>Add Controller</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
