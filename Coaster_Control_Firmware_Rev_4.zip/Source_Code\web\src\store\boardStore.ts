import { create } from 'zustand'
import {
  createLink,
  HALL_COUNT,
  type BoardEvent,
  type BoardInfo,
  type BoardState,
  type Command,
  type Link,
  type LinkStatus,
  type ServerMessage,
} from '../api'

const MAX_EVENTS = 300

interface BoardStore {
  link: Link
  status: LinkStatus
  state: BoardState | null
  info: BoardInfo | null
  events: BoardEvent[]
  /** performance.now() of the last trigger per hall – drives the flash animation. */
  hallFlash: number[]
  /** True when a command was just sent and is awaiting acknowledgement or completion. */
  isProcessing: boolean

  start: () => void
  send: (cmd: Command) => void
  refreshInfo: () => Promise<void>
  clearEvents: () => void
}

export const useBoard = create<BoardStore>((set, get) => {
  const handleMessage = (msg: ServerMessage) => {
    switch (msg.t) {
      case 'state': {
        const prev = get().state
        const next = msg.d
        let hallFlash = get().hallFlash
        if (prev) {
          const now = performance.now()
          next.hallCounts.forEach((count, i) => {
            if (count > (prev.hallCounts[i] ?? 0)) {
              if (hallFlash === get().hallFlash) hallFlash = [...hallFlash]
              hallFlash[i] = now
            }
          })
        }
        set({ state: next, hallFlash, isProcessing: false })
        break
      }
      case 'event':
        set((s) => ({ events: [...s.events, msg.d].slice(-MAX_EVENTS) }))
        break
      case 'events':
        set({ events: msg.d.slice(-MAX_EVENTS) })
        break
    }
  }

  let procTimer: number | undefined

  return {
    link: createLink(),
    status: 'connecting',
    state: null,
    info: null,
    events: [],
    hallFlash: Array(HALL_COUNT).fill(0),
    isProcessing: false,

    start: () => {
      const { link } = get()
      link.connect({
        onStatus: (status) => {
          set({ status })
          if (status === 'online') void get().refreshInfo()
        },
        onMessage: handleMessage,
      })
    },

    send: (cmd) => {
      set({ isProcessing: true })
      window.clearTimeout(procTimer)
      procTimer = window.setTimeout(() => set({ isProcessing: false }), 500)
      get().link.send(cmd)
    },

    refreshInfo: async () => {
      try {
        set({ info: await get().link.getInfo() })
      } catch {
        /* board busy/offline – keep old info */
      }
    },

    clearEvents: () => set({ events: [] }),
  }
})
