import { BoardLink } from './boardLink'
import type { Link } from './link'
import { MockBoard } from './mockBoard'

/**
 * Picks the board connection:
 *  - `npm run dev`            → simulated board in the browser (no hardware)
 *  - `?mock` in the URL       → simulated board (handy for demos)
 *  - otherwise                → the real ESP32 that served this page
 */
export function createLink(): Link {
  const params = new URLSearchParams(location.search)
  const useMock = import.meta.env.VITE_MOCK === '1' || params.has('mock')
  return useMock ? new MockBoard() : new BoardLink()
}

export type { Link, LinkStatus, UploadTarget } from './link'
export * from './types'
